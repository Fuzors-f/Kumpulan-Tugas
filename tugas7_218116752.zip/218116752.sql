-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Nov 2020 pada 05.50
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `218116752`
--
CREATE DATABASE IF NOT EXISTS `218116752` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `218116752`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id_customer` varchar(8) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `password` varchar(255) NOT NULL,
  `saldo` int(11) NOT NULL,
  `status_customer` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`id_customer`, `nama`, `email`, `telepon`, `password`, `saldo`, `status_customer`) VALUES
('CU0', 'john Wick', 'a@gmail.com', '091309213', 'asdfASDF', 60200000, 2),
('CU1', 'jane', 'b@gmail.com', '12345678', 'hahaHAHA', 999800000, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotel`
--

DROP TABLE IF EXISTS `hotel`;
CREATE TABLE `hotel` (
  `id_hotel` varchar(8) NOT NULL,
  `nama_hotel` varchar(255) NOT NULL,
  `harga_hotel` int(11) NOT NULL,
  `url_gambar` varchar(255) NOT NULL,
  `alamat_hotel` varchar(255) NOT NULL,
  `status_hotel` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `hotel`
--

INSERT INTO `hotel` (`id_hotel`, `nama_hotel`, `harga_hotel`, `url_gambar`, `alamat_hotel`, `status_hotel`) VALUES
('HO0', 'Hotel Panorama', 2000000, 'https://cdn-2.tstatic.net/travel/foto/bank/images/whiz-prime-hotel-darmo-harapan-surabaya.jpg', 'jp Pasir putih', 1),
('HO1', 'Hotel Bening', 200000, 'https://cdn-2.tstatic.net/travel/foto/bank/images/whiz-prime-hotel-darmo-harapan-surabaya.jpg', 'jl Kura no 2', 1),
('HO2', 'Hotel Putih', 100000, 'https://pix10.agoda.net/hotelImages/124/1246280/1246280_16061017110043391702.jpg?s=1024x768', 'Jl Pasir putih', 1),
('HO3', 'hotel Kilimanjaro', 1200000, 'https://pix7.agoda.net/hotelImages/254981/-1/b17d67ff33c962d550b65296448135a6.jpg', 'jl pasir Putih no 2', 1),
('HO4', 'hotel Pudding', 2000000, 'https://pix10.agoda.net/hotelImages/124/1246280/1246280_16061017110043391702.jpg?s=1024x768', 'jl Laut no 2', 1),
('HO5', 'yow', 200000000, 'https://www.qontak.com/blog/wp-content/uploads/2020/05/hotel.jpg', 'aa', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_on`
--

DROP TABLE IF EXISTS `tabel_on`;
CREATE TABLE `tabel_on` (
  `id` int(11) NOT NULL,
  `id_customer` varchar(8) NOT NULL,
  `status_on` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tabel_on`
--

INSERT INTO `tabel_on` (`id`, `id_customer`, `status_on`) VALUES
(1, 'CU1', 0),
(2, 'CU0', 0),
(3, 'CU0', 0),
(4, 'CU1', 0),
(5, 'CU0', 0),
(6, 'CU1', 0),
(7, 'CU0', 0),
(8, 'CU0', 0),
(9, 'CU1', 0),
(10, 'CU0', 0),
(11, 'CU0', 0),
(12, 'CU0', 0),
(13, 'CU0', 0),
(14, 'CU0', 0),
(15, 'CU0', 0),
(16, 'CU0', 1),
(17, 'CU0', 1),
(18, 'CU0', 1),
(19, 'CU0', 1),
(20, 'CU0', 1),
(21, 'CU0', 1),
(22, 'CU0', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE `transaksi` (
  `id_transaksi` varchar(8) NOT NULL,
  `id_hotel` varchar(8) NOT NULL,
  `id_customer` varchar(8) NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime NOT NULL,
  `jumlah_hari` int(11) NOT NULL,
  `total_bayar` int(20) NOT NULL,
  `tanggal_transaksi` datetime NOT NULL,
  `harga_malam` int(11) NOT NULL,
  `keterangan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_hotel`, `id_customer`, `check_in`, `check_out`, `jumlah_hari`, `total_bayar`, `tanggal_transaksi`, `harga_malam`, `keterangan`) VALUES
('TR0', 'HO1', 'CU0', '2020-10-21 00:00:00', '2020-10-23 00:00:00', 2, 400000, '2020-10-27 00:00:00', 200000, ''),
('TR1', 'HO1', 'CU1', '2020-10-15 00:00:00', '2020-10-17 00:00:00', 2, 400000, '2020-10-28 00:00:00', 200000, ''),
('TR2', 'HO1', 'CU0', '2020-10-28 14:01:00', '2020-10-31 14:01:00', 3, 600000, '2020-10-28 00:00:00', 200000, ''),
('TR3', 'HO1', 'CU0', '2020-10-16 14:02:00', '2020-10-28 14:02:00', 12, 2400000, '2020-10-28 07:03:03', 200000, ''),
('TR4', 'HO0', 'CU0', '2020-10-16 14:17:00', '2020-10-28 14:17:00', 12, 24000000, '2020-10-28 02:17:28', 2000000, ''),
('TR5', 'HO1', 'CU0', '2020-10-29 14:21:00', '2020-10-31 14:21:00', 2, 400000, '2020-10-28 02:21:38', 200000, ''),
('TR6', 'HO0', 'CU0', '2020-10-15 21:29:00', '2020-10-16 21:29:00', 1, 1800000, '2020-10-28 09:29:39', 2000000, 'Menggunakan kode voucher : KO001 Sebesar : Rp.200000'),
('TR7', 'HO1', 'CU0', '2020-10-30 21:32:00', '2020-10-31 21:32:00', 1, 200000, '2020-10-28 09:32:34', 200000, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `voucher`
--

DROP TABLE IF EXISTS `voucher`;
CREATE TABLE `voucher` (
  `kode_voucher` varchar(8) NOT NULL,
  `potongan` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `voucher`
--

INSERT INTO `voucher` (`kode_voucher`, `potongan`, `created_at`, `updated_at`, `deleted_at`) VALUES
('KO000', 10, '2020-10-28 12:54:14', '2020-10-28 13:27:45', '2020-10-28 13:27:45'),
('KO001', 10, '2020-10-28 14:13:05', '2020-11-17 13:53:49', '2020-11-17 13:53:49');

-- --------------------------------------------------------

--
-- Struktur dari tabel `voucher_hotel`
--

DROP TABLE IF EXISTS `voucher_hotel`;
CREATE TABLE `voucher_hotel` (
  `id_hotel` varchar(8) NOT NULL,
  `kode_voucher` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `voucher_hotel`
--

INSERT INTO `voucher_hotel` (`id_hotel`, `kode_voucher`) VALUES
('HO0', 'KO000'),
('HO1', 'KO000'),
('HO2', 'KO000'),
('HO0', 'KO001'),
('HO1', 'KO001');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id_customer`);

--
-- Indeks untuk tabel `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`id_hotel`);

--
-- Indeks untuk tabel `tabel_on`
--
ALTER TABLE `tabel_on`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indeks untuk tabel `voucher`
--
ALTER TABLE `voucher`
  ADD PRIMARY KEY (`kode_voucher`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tabel_on`
--
ALTER TABLE `tabel_on`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
