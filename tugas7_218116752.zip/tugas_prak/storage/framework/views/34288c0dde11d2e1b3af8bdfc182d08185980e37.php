<?php $__env->startSection('content'); ?>
<?php
    $page = "hotel";
?>
<div  style="background:black; color:white">
    <div class="transbox">
       <!-- Main jumbotron for a primary marketing message or call to action -->
    <?php if(isset($nama_hotel)): ?>


    <section style="background-image:url('<?php echo e($url_gambar); ?>');background-position: center; /* Center the image */
       background-repeat: no-repeat; /* Do not repeat the image */
       background-size: cover; ">
           <div class="jumbotron transbox2">
               <div class="container" style="padding-top:10vh">
               <h2 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold; font-size:30pt"><?php echo e($nama_hotel); ?></h2>
               <form action="<?php echo e(url('/addHotelList')); ?>" style="float:right" method="POST">
                   <?php echo csrf_field(); ?>
                   <input type="hidden" name="idHotel_list" value =<?php echo e($id_hotel); ?>>
                   <input type="submit" class="btn btn-primary wow fadeInDown" data-wow-duration="2s" value="Add to Wishlist">
                    <?php if(isset($pesan)): ?>
                        <div class="invalid-feedback" style="display:block; margin:bottom:2vh">
                            <center><h6><?php echo e($pesan); ?></h6></center>
                        </div>
                    <?php endif; ?>
                </form>
               <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;"><?php echo e($alamat_hotel); ?></p>
                   <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">Rate : 3.8</p>
                   <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">Rp.<?php echo e($harga_hotel); ?>,00/malam</p>
                   <p class="card-text">
                    Contact Person : Grace - 0823172838123<br>
                    Berliburlah di hotel kami. Menyajikan pemandangan pasir putih, dapat melih sunset dengan jelas. Power by : pasPUT.com
                  </p>

               </div>
           </div>
       </section>
       <?php endif; ?>
       <!-- section -->

       <section >
           <div class="container">
               <div class="row">
                   <div class="col-md-12 mb-3">
                      <h3>Reservasi Kamar</h3>
                   </div>

               </div>
               <hr style="border: 1px solid white">
               <form action="<?php echo e(url('/prosesBook')); ?>" method ="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row" >

                    
                    <input type="hidden" name="idHotel" value =<?php echo e($id_hotel); ?>>
                    <input type="hidden" name="hargaHotel" value = "<?php echo e($harga_hotel); ?>">


                    

                    <div class="col-md-5 mb-3">
                        <label for="address">Tanggal Check In</label>
                        <input type="datetime-local" class="form-control" id="chin" name="chin"  required>

                    </div>

                    <div class="col-md-5 mb-3">
                        <label for="address">Tanggal Check Out</label>
                        <input type="datetime-local" class="form-control" id="chout" name="chout"  required>

                    </div>

                    <div class="col-md-2 mb-3" >
                        

                    </div>

                    <div class="col-12">
                        <?php if(isset($pesan_error)): ?>
                            <div class="invalid-feedback" style="display:block; margin:bottom:2vh">
                               <center><h4><?php echo e($pesan_error); ?></h4></center>
                            </div>
                         <?php endif; ?>
                    </div>


                    <div class="col-md-12 mb-3">
                        <label for="country">Voucher (dipotong dari total jumlah hari menginap)</label>
                        <select class="custom-select d-block w-100" id="vocuhers" name="vouchers">
                            <option value="">Tidak Pakai</option>
                            <?php if(isset($data_hotel)): ?>
                               <?php $__currentLoopData = $data_hotel->Vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_voucher); ?>"><?php echo e($item->kode_voucher. " - Besar Potongan:".$item->potongan."%"); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </select>
                    </div>

                    

                    <div class="col-md-12 mb-3 form-control" style="background:orangered;color:white; border:none; padding:5%">
                    <h2>Price : Rp. <?php echo e($harga_hotel); ?>/malam</h2>
                    </div>

                    

                    <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh; margin-bottom:4vh" type="submit" name="submit"  value="Submit">

                  </div>
                </form>

           </div>
       </section>
   </div>
</div>
<!-- end section -->
<script>
    // function cart(){
    //     document.location.href  = "<?php echo e(url('/cart')); ?>"
    // }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak\resources\views/contents/bookKamar.blade.php ENDPATH**/ ?>