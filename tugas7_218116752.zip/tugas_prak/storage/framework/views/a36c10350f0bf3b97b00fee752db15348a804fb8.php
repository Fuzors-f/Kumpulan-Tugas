<?php $__env->startSection('content'); ?>
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax5" style="color:white">
    <div class="transbox">


        <section id="form"  style="margin-top: -4vh">
            <div class="container">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold; text-align:left">CART</h1>
                    <hr style="border:2px solid white">
                <div class="row">
                    <div class="col-md-12 wow fadeInDown " data-wow-duration="1.6s" >
                        <div class=" card mb-12 shadow-sm">
                            <div class="row">
                                <div class="col-4">
                                    <img class="bd-placeholder-img " width="100%" height="100%" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">

                                </div>
                                <div class="col-8">
                                    <div class="card-body" style="color:black;text-align :left">
                                        <h2>Hotel Panorama</h2>
                                        <p class="card-text">Jl. Pasir Putih no 2</p>
                                        <p class="card-text">
                                            Nama Pemesan : Fendy <br>
                                            Tipe Kamar : Tipe A <br>
                                            Deskripsi Kamar : kamar dengan extra king bed untuk 2 orang, fasilitas air panas dan wi-fi gratis <br>
                                            Tanggal Check in : Senin , 21 September 2020 <br>
                                            Tanggal Check Out : Rbau, 23 September 2020 <br>

                                        </p>
                                        <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh ; width:100px" type="submit" name="submit"  value="Batalkan">
                                        <input class="btn btn-primary btn-lg btn-block " style="background-color:green; border:none; font-size:12pt; margin-top:2vh ; width:100px" type="submit" name="submit"  value="Bayar">

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>



                </div>
            </div>
            </section>
         </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/contents/cart.blade.php ENDPATH**/ ?>