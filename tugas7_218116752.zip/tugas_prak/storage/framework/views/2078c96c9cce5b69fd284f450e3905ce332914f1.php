
  <?php if(\Session::has("pesan") ): ?>
  <?php if(session("pesan")=="na"): ?>
      <?php
          echo "<script>alert('Not authorized')</script>";
      ?>
  <?php endif; ?>
  <?php if(session("pesan")=="nb"): ?>
      <?php
          echo "<script>alert('Must Login First')</script>";
      ?>
  <?php endif; ?>
  <?php if(session("pesan")=="nc"): ?>
      <?php
          echo "<script>alert('User Banned')</script>";
      ?>
  <?php endif; ?>
  <?php if(session("pesan")=="nd"): ?>
      <?php
          echo "<script>alert('User not found')</script>";
      ?>
  <?php endif; ?>
<?php endif; ?>
<?php if(isset($logon)): ?>
  <?php if($logon == "admin"): ?>
  <nav class="navbar navbar-expand-sm fixed-top navbar-dark bg-tr"  id="nav" >
    <div class="container borderbtm" id="kotak">
    <a class="navbar-brand" href="<?php echo e(url('/218116752')); ?>" id="navbrand"> <strong><img src="img/iconz2.png" alt="" class="icontop"></strong></span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample03" >
      <ul class="navbar-nav ml-auto">
      <?php
          if($page =="home"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline '>";
          }
      ?>

          <a class="nav-link" href="<?php echo e(url('/218116752')); ?>">Home </a>
        </li>
        <?php
            if($page =="hotel"){
                echo "<li class='nav-item underline active'>";
            }else{
                echo "<li class='nav-item underline'>";
            }
        ?>
          <a class="nav-link" href="<?php echo e(url('/hotel')); ?>">Hotel</a>
        </li>
        <?php
          if($page =="cart"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline'>";
          }
        ?>
          <a class="nav-link" href="<?php echo e(url('/cart')); ?>">Cart</a>
        </li>


        <?php
            if($page == "login"){
                echo "<li class='nav-item active underline'>";

            }else{
                echo "<li class='nav-item dropdown underline' >";

            }
        ?>



        <a class="nav-link dropdown-toggle" href="<?php echo e(url('/logAdmin')); ?>" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hello,<?php echo e($logon); ?></a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
                <a class='dropdown-item' href='<?php echo e(url('/logAdmin')); ?>'>Add new Hotel</a>
                <a class='dropdown-item' href='<?php echo e(url('/voucher')); ?>'>Add new Voucher</a>
                <a class='dropdown-item' href='<?php echo e(url('/listuser')); ?>'>Management User</a>
                <a class='dropdown-item' href='<?php echo e(url('/LogOut')); ?>'>Log Out</a>
            </div>
        </li>
        <li class="delimiter">|</li>
        <?php
          if($page =="register"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline'>";
          }
        ?>
          <a class="nav-link" href="<?php echo e(url('/regis')); ?>">Register</a>
        </li>

      </ul>

    </div>
    </div>
  </nav>
  <?php elseif($logon != ""): ?>
  <nav class="navbar navbar-expand-sm fixed-top navbar-dark bg-tr"  id="nav" >
    <div class="container borderbtm" id="kotak">
    <a class="navbar-brand" href="<?php echo e(url('/218116752')); ?>" id="navbrand"> <strong><img src="img/iconz2.png" alt="" class="icontop"></strong></span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample03" >
      <ul class="navbar-nav ml-auto">
      <?php
          if($page =="home"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline '>";
          }
      ?>

          <a class="nav-link" href="<?php echo e(url('/218116752')); ?>">Home </a>
        </li>
        <?php
            if($page =="hotel"){
                echo "<li class='nav-item underline active'>";
            }else{
                echo "<li class='nav-item underline'>";
            }
        ?>
          <a class="nav-link" href="<?php echo e(url('/hotel')); ?>">Hotel</a>
        </li>
        <?php
          if($page =="cart"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline'>";
          }
        ?>
          <a class="nav-link" href="<?php echo e(url('/cart')); ?>">Cart</a>
        </li>


        <?php
            if($page == "login"){
                echo "<li class='nav-item active underline'>";

            }else{
                echo "<li class='nav-item dropdown underline' >";

            }
        ?>



        <a class="nav-link dropdown-toggle" href="" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hello,<?php echo e($logon); ?></a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
                    <a class='dropdown-item' href='<?php echo e(url('/profil')); ?>'>Your Profile</a>
                    <a class='dropdown-item' href='<?php echo e(url('/LogOut')); ?>'>Log Out</a>
            </div>
        </li>
        <li class="delimiter">|</li>
        <?php
          if($page =="register"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline'>";
          }
        ?>
          <a class="nav-link" href="<?php echo e(url('/regis')); ?>">Register</a>
        </li>

      </ul>

    </div>
    </div>
  </nav>
  <?php else: ?>
  <nav class="navbar navbar-expand-sm fixed-top navbar-dark bg-tr"  id="nav" >
    <div class="container borderbtm" id="kotak">
    <a class="navbar-brand" href="<?php echo e(url('/218116752')); ?>" id="navbrand"> <strong><img src="img/iconz2.png" alt="" class="icontop"></strong></span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample03" >
      <ul class="navbar-nav ml-auto">
      <?php
          if($page =="home"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline '>";
          }
      ?>

          <a class="nav-link" href="<?php echo e(url('/218116752')); ?>">Home </a>
        </li>
        <?php
            if($page =="hotel"){
                echo "<li class='nav-item underline active'>";
            }else{
                echo "<li class='nav-item underline'>";
            }
        ?>
          <a class="nav-link" href="<?php echo e(url('/hotel')); ?>">Hotel</a>
        </li>
        <?php
          if($page =="cart"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline'>";
          }
        ?>
          <a class="nav-link" href="<?php echo e(url('/cart')); ?>">Cart</a>
        </li>


        <?php
            if($page == "login"){
                echo "<li class='nav-item active underline'>";

            }else{
                echo "<li class='nav-item dropdown underline' >";

            }
        ?>
          <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
        </li>
        <li class="delimiter">|</li>
        
        <?php
          if($page =="register"){
              echo "<li class='nav-item underline active'>";
          }else{
              echo "<li class='nav-item underline'>";
          }
        ?>
          <a class="nav-link" href="<?php echo e(url('/regis')); ?>">Register</a>
        </li>

      </ul>

    </div>
    </div>
  </nav>

  <?php endif; ?>

<?php endif; ?>







<?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak\resources\views/components/header.blade.php ENDPATH**/ ?>