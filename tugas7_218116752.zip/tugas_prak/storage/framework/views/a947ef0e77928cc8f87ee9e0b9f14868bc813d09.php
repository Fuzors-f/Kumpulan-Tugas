<?php $__env->startSection('content'); ?>
 <div  id="parallax3" class="parallax">
     <div class="transbox">
        <!-- Main jumbotron for a primary marketing message or call to action -->

        <section >
            <div class="jumbotron transbox2">
                <div class="container" style="padding-top:10vh">
                    <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">HOTEL</h1>
                    <p class="wow fadeInUp" data-wow-duration="2.5s">Kami menawarkan hotel dari kelas bintang 3 sampai bintang 5 dengan harga terbaik dan termurah</p>
                </div>
            </div>
        </section>

        <!-- section -->

        <section >
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <input type="text" class="form-control" id="firstName" placeholder="Cari Sekarang" value="" name="nama" required>
                        <div class="invalid-feedback">
                            Nama Masih kosong!.
                        </div>
                    </div>
                </div>
                <div class="row">

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                </div>
            </div>
        </section>
    </div>
</div>
<!-- end section -->
<script>
    var anchors = document.getElementsByClassName('konten');
        for(var i = 0; i < anchors.length; i++) {
            var anchor = anchors[i];

                anchor.onclick = function() {
                   window.location.href = "<?php echo e(url('/bookKamar')); ?>";
                }

        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/contents/hotel.blade.php ENDPATH**/ ?>