<?php $__env->startSection('content'); ?>


    <style>
        .bd-placeholder-img {
          font-size: 1.125rem;
          text-anchor: middle;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
        }

        @media (min-width: 768px) {
          .bd-placeholder-img-lg {
            font-size: 3.5rem;
          }
        }
       .ktk_besar , .transbox{
          height: 100%;
          }
          .transbox{
            padding-top:15vh;
          padding-bottom: 15vh;
          }
         .ktk-besar {
          display: -ms-flexbox;
          display: flex;
          -ms-flex-align: center;
          align-items: center;


          color:white
          }

          .form-signin {
          width: 100%;
          max-width: 330px;
          padding: 15px;
          margin: auto;
          }
          .form-signin .checkbox {
          font-weight: 400;
          }
          .form-signin .form-control {
          position: relative;
          box-sizing: border-box;
          height: auto;
          padding: 10px;
          font-size: 16px;
          }
          .form-signin .form-control:focus {
          z-index: 2;
          }
          .form-signin input[type="email"] {
              margin-bottom: -1px;
              border-bottom-right-radius: 0;
              border-bottom-left-radius: 0;
          }
          .form-signin input[type="password"] {
              margin-bottom: 10px;
              border-top-left-radius: 0;
              border-top-right-radius: 0;
          }

          .axy{
              color:red;
          }
          .axy:hover{
              text-decoration:none;
              font-weight:bold;
              color:red;
          }
          .mb-4:hover{
              cursor:pointer;
          }
          .warning{
              color:white;
              background:red;
              border-radius:4%;
              font-weight:bold;
              transition:0.2s;
              display:none;
          }
      </style>
      <!-- Custom styles for this template -->
      <link href="signin.css" rel="stylesheet">
<div class="ktk-besar text-center parallax" id="parallax4" >
    <div class="transbox">
    <form class="form-signin" action="checklogin.php" method ="post" >
        <div class="warning" id="warning"><p>Email atau password salah !</p></div>
        <img class="mb-4" src="img/iconz.png" alt="" width="72" height="72" id="loginmaster">

        <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>

        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="email" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="pass" required>
        <div class="checkbox mb-3">
            <label>
                <input type="checkbox"  onclick="shows()"> Show password
            </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" style="background:orangered; border:none" name="sign" >Sign in</button>
        <a href="forgotpasw.php" style="font-size:16pt">Forgot Password</a>

    </form>

</div>
</div>
<script>
    function shows() {
		var x = document.getElementById("inputPassword");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/contents/login.blade.php ENDPATH**/ ?>