
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>PasPUT.com </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="img/iconz.png" rel="icon">
    <link href="img/iconz.png" rel="apple-touch-icon">

    <!-- css -->

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link rel="stylesheet" href="lib/lightgallery/lightgallery.min.css">


    <!-- Main CSS Files -->
    <link href="main/main.css" rel="stylesheet" type="text/css">

</head>
<style>
  #parallax1{
     /* The image used */
    background-image: url('img/parallax1.jpg');
  }

  #parallax2{
    background-image: url('img/parallax2.jpeg');
  }

  #parallax3{
    background-image: url('img/3.jpg');
  }

  #parallax4{
    background-image: url('img/4.jpg');
  }

  #parallax5{
    background-image: url('img/2.jpg');
  }


</style>
<body>
   <!-- header -->
   <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- -- -->


  <!-- PRE LOADER -->
  <section class="preloader">
    <div class="spinner">

         <span class="spinner-rotate"></span>

    </div>
  </section>
    <!-- section -->
   <?php echo $__env->yieldContent('content'); ?>

  <!-- section -->

  <!-- end section -->
  <!-- footer -->
   <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<!-- JavaScript Libraries -->
<script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/touchSwipe/jquery.touchSwipe.min.js"></script>
  <script src="main/main.js"></script>



<?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/layout.blade.php ENDPATH**/ ?>