<?php $__env->startSection('content'); ?>
<?php
    $page = "admin";
?>
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
      .accordion {
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: none;
        outline: none;
        transition: 0.4s;
        }

        .active, .accordion:hover {
             background-color: #ccc;
             color: black;
        }

        .panel {
        padding: 0 18px;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.2s ease-out;
        }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax4" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Admin </h1>
                  <div class="col-12" style='margin-top:2vh'>
                    <a href="<?php echo e(url('/logAdmin')); ?>"><button class=" btn btn-primary btn-lg" style="margin:2%">Go to Add Hotel</button></a>
                    <a href="<?php echo e(url('/listuser')); ?>"><button class=" btn btn-primary btn-lg" style="margin:2%">Go to Management User</button></a>

                    <h2 class="accordion">Add Voucher</h2>
                  <form class="needs-validation panel"  action="<?php echo e(url('/prosesAddVoucher')); ?>" method="post" enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                                <div class="row">
                                  <div class="col-md-12 mb-3">
                                      <label for="firstName">Kode Voucher</label>
                                  <input type="text" class="form-control"  id="kodeVoucher" value="<?php echo e($kodeHint); ?>"  name="kodeVoucher" >
                                      <?php $__errorArgs = ['kodeVoucher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback" style="display: block">
                                          <?php echo e($message); ?>

                                      </div>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                              </div>

                              <div class="mb-3">
                                  <label for="address">Nama Penginapan</label> <br>
                                 <?php if(isset($dataPenginapan)): ?>
                                        <?php $__currentLoopData = $dataPenginapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <input type="checkbox" style="margin:2%" name="hotel[]" value="<?php echo e($item->id_hotel); ?>"> <label><?php echo e($item->nama_hotel); ?></label>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>

                                 <?php $__errorArgs = ['hotel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <div class="invalid-feedback" style="display: block">
                                     <?php echo e($message); ?>

                                 </div>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>


                                  <div class="col-md-12 mb-3">
                                      <label for="cc-number">Potongan harga (dalam %)</label>
                                      <input type="number" class="form-control" id="potonganHarga" name="potonganHarga" placeholder="" >
                                      <?php $__errorArgs = ['potonganHarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback" style="display: block">
                                          <?php echo e($message); ?>

                                      </div>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>


                                  <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="Add Voucher">

                              </div>

                          </form>
                  </div>

                  
                  <div class="row" style="margin-top:8vh; margin-bottom : 2vh;color:white">
                    <div class="col-12">
                        <h2 class="accordion">List Voucher</h2>
                          <div class="panel">
                            <table class="table table-dark">
                                <thead>
                                      <tr>
                                          <th>Kode Voucher</th>
                                          <th>Besar Potongan (dalam%)</th>
                                          <th>Hotel</th>
                                          <th>Action</th>
                                      </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($dataVoucher)): ?>
                                      <?php $__currentLoopData = $dataVoucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                              <td><?php echo e($item->kode_voucher); ?></td>
                                              <td><?php echo e($item->potongan); ?></td>
                                              <td>
                                                  <?php


                                                   $tmp = "";
                                                   $data = $item->Hotels;
                                                  for ($i = 0; $i < count($data)-1; $i++){

                                                      $tmp = $tmp.$data[$i]->nama_hotel.",";


                                              }
                                              $tmp = $tmp.$data[count($data)-1]->nama_hotel;
                                              echo $tmp;
                                              ?>
                                              </td>
                                              <td class="btnSubs">
                                               <form action="<?php echo e(url('/deleteVoucher')); ?>" class="buttonSub" method = "POST">
                                                   <?php echo csrf_field(); ?>
                                                   <input type="hidden" name="kdvoucher" value= "<?php echo e($item->kode_voucher); ?>">
                                                  <?php if($item->deleted_at != null): ?>
                                                     <input type="submit" value="Deleted" class = "btn btn-warning click "  style="background:red" onClick=" return false;" disabled>
                                                  <?php else: ?>
                                                      <input type="submit" value="Delete" class = "btn btn-warning click "  onClick=" return false;">
                                                  <?php endif; ?>
                                               </form>
                                              </td>
                                          </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>
                                </tbody>
                            </table>
                          </div>
                    </div>
                </div>
              </div>

          </div>
        </section>
         </div>
    </div>

    <script>
         var anchors = document.getElementsByClassName('btnSubs');
        for(var i = 0; i < anchors.length; i++) {
            //dapetin element form nya
            anchors[i].onclick = function() {
                var form =this.getElementsByClassName('buttonSub')[0];
                if (confirm('Are you sure you want to delete this thing from the database?')) {
                    form.submit();
                }
            }
        }


        var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px";
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak\resources\views/contents/voucher.blade.php ENDPATH**/ ?>