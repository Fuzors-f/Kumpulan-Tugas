

<nav class="navbar navbar-expand-sm fixed-top navbar-dark bg-tr"  id="nav" >
  <div class="container borderbtm" id="kotak">
  <a class="navbar-brand" href="<?php echo e(url('/218116752')); ?>" id="navbrand"> <strong><img src="img/iconz2.png" alt="" class="icontop"></strong></span></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarsExample03" >
    <ul class="navbar-nav ml-auto">
     <li class='nav-item underline active'>
     <a class="nav-link" href="<?php echo e(url('/218116752')); ?>">Home </a>
      </li>
     <li class='nav-item underline'>
        <a class="nav-link" href="<?php echo e(url('/hotel')); ?>">Hotel</a>
      </li>
      <li class='nav-item underline'>
        <a class="nav-link" href="<?php echo e(url('/cart')); ?>">Cart</a>
      </li>
     <li class='nav-item underline'>
        <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
      </li>
      <li class="delimiter">|</li>
      
      <li class='nav-item underline'>
        <a class="nav-link" href="<?php echo e(url('/regis')); ?>">Register</a>
      </li>

    </ul>

  </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/components/header.blade.php ENDPATH**/ ?>