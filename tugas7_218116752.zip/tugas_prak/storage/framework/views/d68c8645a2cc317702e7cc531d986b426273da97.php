<?php $__env->startSection('content'); ?>
<div  style="background:black; color:white">
    <div class="transbox">
       <!-- Main jumbotron for a primary marketing message or call to action -->

       <section style="background-image:url('img/hotel.jpeg');background-position: center; /* Center the image */
       background-repeat: no-repeat; /* Do not repeat the image */
       background-size: cover; ">
           <div class="jumbotron transbox2">
               <div class="container" style="padding-top:10vh">
                   <h2 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold; font-size:30pt">Hotel Panorama</h2>
                   <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">Jl. Pasir PUtih no 2</p>
                   <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">Rate : 3.8</p>
                   <p class="card-text">
                    Contact Person : Grace - 0823172838123<br>
                    Berliburlah di hotel kami. Menyajikan pemandangan pasir putih, dapat melih sunset dengan jelas. Power by : pasPUT.com
                  </p>

               </div>
           </div>
       </section>

       <!-- section -->

       <section >
           <div class="container">
               <div class="row">
                   <div class="col-md-12 mb-3">
                      <h3>Reservasi Kamar</h3>
                   </div>

               </div>
               <hr style="border: 1px solid white">
               <div class="row">

                    <div class="col-md-12 mb-3">
                        <label for="address">Nama Pemesan</label>
                        <input type="text" class="form-control" id="namaPemesan" name="namaPemesan"  required>
                        <div class="invalid-feedback">
                        Nama Masih Kosong!
                        </div>

                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="address">No KTP</label>
                        <input type="number" class="form-control" id="ktp" name="ktp"  required>
                        <div class="invalid-feedback">
                        No Ktp masih kosong
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="address">No telepon</label>
                        <input type="number" class="form-control" id="tlp" name="tlp"  required>
                        <div class="invalid-feedback">
                        No telepon masih kosong
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="address">Gender</label><br>
                        <input type="radio" name="gender" value="male" checked> Male<br>
                        <input type="radio" name="gender" value="female"> Female<br>

                    </div>

                    <div class="col-md-5 mb-3">
                        <label for="address">Tanggal Check In</label>
                        <input type="date" class="form-control" id="chin" name="chin"  required>
                        <div class="invalid-feedback">
                          Masih Kosong
                        </div>
                    </div>

                    <div class="col-md-5 mb-3">
                        <label for="address">Tanggal Check Out</label>
                        <input type="date" class="form-control" id="chout" name="chout"  required>
                        <div class="invalid-feedback">
                       Masih Kosong
                        </div>
                    </div>

                    <div class="col-md-2 mb-3" >
                        <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh" type="submit" name="sub" value="Check Availability">

                    </div>



                    <div class="col-md-12 mb-3">
                        <label for="address">Fasilitas Tambahan</label>
                        <select class="form-control">
                            <option value="A">Tipe Kamar A</option>

                        </select>
                        <p>Keterangan : kamar dengan extra king bed untuk 2 orang, fasilitas air panas dan wi-fi gratis</p>
                    </div>

                    <div class="col-md-12 mb-3 form-control" style="background:orangered;color:white; border:none; padding:5%">
                        <h2>Price : Rp. 389.000/malam</h2>
                    </div>

                    

                    <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh" type="submit" name="submit" onclick="cart()" value="Submit">


                  </div>

           </div>
       </section>
   </div>
</div>
<!-- end section -->
<script>
    function cart(){
        document.location.href  = "<?php echo e(url('/cart')); ?>"
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/contents/bookKamar.blade.php ENDPATH**/ ?>