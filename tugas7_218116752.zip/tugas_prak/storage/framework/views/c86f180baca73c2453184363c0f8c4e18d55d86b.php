<?php $__env->startSection('content'); ?>
<style>
.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.panel {
  padding: 0 18px;
  background-color: white;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}
</style>
<div  id="parallax3" class="parallax">
    <div class="transbox">
       <!-- Main jumbotron for a primary marketing message or call to action -->
       <?php
           $page = "";
       ?>
       
       <section >
           <div class="jumbotron transbox2">
               <div class="container" style="padding-top:10vh">
                   <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">YOUR PROFILE</h1>

               </div>
           </div>
       </section>

       <!-- section -->
       <section >
           <div class="container">
               <div class="row wow fadeInDown" data-wow-duration="2s">
                   <div class="col-12">
                       <div class="row">
                           <div class="col-4 text-center">
                                <svg class="bd-placeholder-img rounded-circle" width="150" height="150" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140" style="border:1px solid white"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
                           </div>
                           <?php if(isset($data)): ?>
                            <div class="col-4 text-left" style='color:white'>
                                    <h3>Nama  : <?php echo e($data[0]->nama); ?></h3>
                                    <hr>
                                    <h3>Phone : <?php echo e($data[0]->telepon); ?></h3>
                                    <hr>
                                    <h3>Email : <?php echo e($data[0]->email); ?></h3>
                                    <hr>
                                    <h3>Saldo : Rp. <?php echo e($data[0]->saldo); ?>,-</h3>
                                    <hr>
                            </div>
                           <?php endif; ?>

                           <div class="col-4 " style="border:2px solid red;color:white; border-radius:8%">
                                <center><h1>Top UP</h1></center>
                                <form action="<?php echo e(url('/topUp')); ?>" method="post">
                                    <p>Masukan nominal sebanyak kelipatan Rp.100.000,-</p>
                                    <input type="number" class="form-control" id="firstName" placeholder="100000" value="" name="saldo" >
                                    <?php $__errorArgs = ['saldo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback" style="display: block">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="submit" class="btn btn-lg btn-primary btn-block"  value="Top Up" style="margin-top:2vh" required>
                                    <?php echo csrf_field(); ?>
                                </form>
                           </div>

                       </div>
                       <div class="container">
                            <div class="row" style="margin-top:5vh; margin-bottom:5vh; color:white;padding:3%;
                            border:2px solid red; border-radius:15px">

                                            <div class="col-12"><h1 style="margin-top:2vh; margin-bottom:2vh">History</h1></div>
                                            <?php if(isset($dataTrans)): ?>
                                                <?php $__currentLoopData = $dataTrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-3 wow fadeInDown konten" data-wow-duration="1.6s" >
                                                    <form action="<?php echo e(url('/bookKamar')); ?>" method="post" class="form_id">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="card mb-4 shadow-sm">
                                                            <img class="bd-placeholder-img card-img-top isiKonten" width="125" height="125" src="<?php echo e($item->url_gambar); ?>" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                                            <div class="card-body accordion" style="color:black">

                                                                    <h5><?php echo e($item->nama_hotel); ?></h5>
                                                                    <h6>Rp. <?php echo e($item->harga_malam); ?>/malam</h6>
                                                                    <p>Click Here to more Info</p>
                                                            <input type="hidden" name="idHotel" value="<?php echo e($item->id_hotel); ?>">
                                                            </div>
                                                            <div class="card-body panel" style="color:black">
                                                            <p>Tanggal Transaksi : <?php echo e($item->tanggal_transaksi); ?></p>
                                                                <p>Check In : <?php echo e($item->check_in); ?></p>
                                                                <p>Check Out : <?php echo e($item->check_out); ?></p>
                                                                <p>Total Menginap : <?php echo e($item->jumlah_hari); ?> hari</p>
                                                                <p style="color:red"><?php echo e($item->keterangan); ?></p>
                                                                <p>Total Bayar: Rp. <?php echo e($item->total_bayar); ?></p>

                                                            </div>
                                                            <input type="submit" value="Cek Penginapan sekarang" class="btn  btn-primary btn-block">
                                                        </div>
                                                    </form>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>

                            </div>


                            <div class="container">
                                <div class="row" style="margin-top:5vh; margin-bottom:5vh; color:white;padding:3%;
                                border:2px solid red; border-radius:15px">

                                                <div class="col-12"><h1 style="margin-top:2vh; margin-bottom:2vh">Wish List</h1></div>
                                                <?php if(isset($dataList)): ?>
                                                    <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-3 wow fadeInDown konten" data-wow-duration="1.6s" >
                                                        <form action="<?php echo e(url('/bookKamar')); ?>" method="post" class="form_id">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="card mb-4 shadow-sm">
                                                                <img class="bd-placeholder-img card-img-top isiKonten" width="125" height="125" src="<?php echo e($item->url_gambar); ?>" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                                                <div class="card-body accordion" style="color:black">

                                                                        <h5><?php echo e($item->nama_hotel); ?></h5>
                                                                        <h6>Rp. <?php echo e($item->harga_hotel); ?>/malam</h6>
                                                                <input type="hidden" name="idHotel" value="<?php echo e($item->id_hotel); ?>">
                                                                </div>

                                                                <input type="submit" value="Cek Penginapan sekarang" class="btn  btn-primary btn-block">

                                                        </form>
                                                                <form action="<?php echo e(url('/delHotelList')); ?>" method="post" class="form_id">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="idHotel" value="<?php echo e($item->id_hotel); ?>">
                                                                    <input type="submit" value="Hapus dari List" class="btn  btn-warning btn-block btndel" onsubmit="return false;">
                                                                </form>
                                                             </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endif; ?>

                                </div>
                            </div>

                        </div>
                   </div>
               </div>
           </div>
       </section>
   </div>
</div>

<script>



var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}


var anchors = document.getElementsByClassName('btndel');
        for(var i = 0; i < anchors.length; i++) {
            //dapetin element form nya
            anchors[i].onclick = function() {
                var r = confirm("Are you Sure ?");
                if (r == true) {
                    var form =document.getElementsByClassName('form_id')[0];
                    form.submit();
                }

             }
        }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak\resources\views/contents/profil.blade.php ENDPATH**/ ?>