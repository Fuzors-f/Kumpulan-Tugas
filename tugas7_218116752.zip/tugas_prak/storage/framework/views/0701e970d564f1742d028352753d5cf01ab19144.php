<?php $__env->startSection('content'); ?>
<?php
   $page = "register";
?>
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax5" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Register </h1>
                  <div class="col-12" style='margin-top:2vh'>
                          <hr>
                      <?php if(isset($warning)): ?>
                          <h3 style="color:red;font-weight:bold"><?php echo e($warning); ?></h3>
                      <?php endif; ?>
                  <form class="needs-validation"  action="<?php echo e(url('/prosesRegister')); ?>" method="post" enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                                <div class="row">
                                  <div class="col-md-12 mb-3">
                                      <label for="firstName">Name</label>
                                      <input type="text" class="form-control" placeholder="John Wick" id="firstName" placeholder=""  name="nama" >
                                      <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback" style="display: block">
                                          <?php echo e($message); ?>

                                      </div>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                              </div>

                              <div class="mb-3">
                                  <label for="address">Email</label>
                                  <input type="text" class="form-control" id="email" placeholder="1234@gmail.com" name="email">
                                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feedback" style="display: block">
                                      <?php echo e($message); ?>

                                  </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>



                              <div class="row">
                                  <div class="col-md-5 mb-3">
                                      <label for="address">Password</label>
                                      <input type="password" class="form-control" id="passw" name="pass"  >
                                      
                                  </div>

                                  <div class="col-md-7 mb-3">
                                  <label for="address">Confirm Password</label>
                                      <input type="password" class="form-control" id="passw_confirmation" name="pass_confirmation"  >
                                      
                                  </div>
                                  <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feedback" style="display: block">
                                      <?php echo e($message); ?>

                                  </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  

                                  <div class="col-md-12 mb-3">
                                      <label for="cc-number">Phone</label>
                                      <input type="text" class="form-control" id="phone" name="phone" placeholder="0892137123" >
                                      

                                      <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback" style="display: block">
                                          <?php echo e($message); ?>

                                      </div>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>

                                  

                              </div>

                              <div class="row">
                                  <div class="col-md-5 mb-3">
                                      <?php if(isset($captcha)): ?>
                                      <h2 style="font-size: 18pt"><label for="address">Masukan Captcha : <?php echo e($captcha); ?></label></h2>
                                      <?php endif; ?>
                                  </div>

                                  <div class="col-md-7 mb-3">
                                     <input type="text" class="form-control" id="captch" name="captch"  >
                                     <?php $__errorArgs = ['captch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback" style="display: block">
                                          <?php echo e($message); ?>

                                      </div>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                              </div>





                              <hr class="mb-4">
                              <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                          </form>
                  </div>
              </div>
          </div>
        </section>
         </div>
    </div>

    <script>
        // $('#passw, #passw_confirmation').on('keyup', function () {
        //     if ($('#passw').val() == $('#passw_confirmation').val()) {
        //         $('#warning1').html('Matching').css('color', 'green');
        //     } else
        //         $('#warning1').html('Not Matching').css('color', 'red');
        // });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak\resources\views/contents/register.blade.php ENDPATH**/ ?>