<?php $__env->startSection('content'); ?>
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax5" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Register </h1>
                  <div class="col-12" style='margin-top:2vh'>
                          <hr>
                          <form class="needs-validation" novalidate action="insertdbpengajar.php" method="post" enctype="multipart/form-data">
                              <div class="row">
                                  <div class="col-md-12 mb-3">
                                      <label for="firstName">Name</label>
                                      <input type="text" class="form-control" id="firstName" placeholder="" value="" name="nama" required>
                                      <div class="invalid-feedback">
                                          Nama Masih kosong!.
                                      </div>
                                  </div>
                              </div>

                              <div class="mb-3">
                                  <label for="address">Email</label>
                                  <input type="email" class="form-control" id="email" placeholder="1234@gmail.com" name="email" required>
                                  <div class="invalid-feedback">
                                     Email masih kosong.
                                  </div>
                              </div>



                              <div class="row">
                                  <div class="col-md-5 mb-3">
                                      <label for="address">Password</label>
                                      <input type="password" class="form-control" id="passw" name="pass"  required>
                                      <div class="invalid-feedback">
                                      Password Masih kosong !.
                                      </div>
                                  </div>

                                  <div class="col-md-7 mb-3">
                                  <label for="address">Confirm Password</label>
                                      <input type="password" class="form-control" id="cpassw" name="cpass"  required>
                                      <div class="invalid-feedback">
                                      Konfirm Password Masih kosong !.
                                      </div>
                                  </div>
                                  <div class="col-md-12 mb-3">
                                      <label for="cc-number">Phone</label>
                                      <input type="number" class="form-control" id="phone" name="phone" placeholder="0892137123" required>
                                      <div class="invalid-feedback">
                                          Mohon di isi Teleponnya !
                                      </div>
                                  </div>

                                  <div class="col-md-12 mb-3">
                                    <label for="cc-number">No KTP</label>
                                    <input type="number" class="form-control" id="ktp" name="phone" placeholder="0892137123" required>
                                    <div class="invalid-feedback">
                                        Mohon di isi Teleponnya !
                                    </div>
                                </div>

                              </div>





                              <hr class="mb-4">
                              <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                          </form>
                  </div>
              </div>
          </div>
        </section>
         </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FAI_prak\tugas_prak1\resources\views/contents/register.blade.php ENDPATH**/ ?>