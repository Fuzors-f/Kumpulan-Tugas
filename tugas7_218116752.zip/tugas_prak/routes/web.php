<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/218116752', 'controllerUtama@Home');



Route::get('/login','controllerUtama@Login');
Route::get('/regis','controllerUtama@Register');


Route::post('/bookKamar','controllerUtama@booking');

Route::get('/LogOut','controllerUtama@Logout');


Route::post('/prosesRegister','controllerUtama@prosesRegister');
Route::post('/prosesLogin','controllerUtama@prosesLogin');

Route::group(['middleware' => 'cekLogin'], function() {
    Route::get('/hotel','controllerUtama@cariHotel');
});

Route::group(['middleware' => 'cekUser-login-and-ban'], function() {

    Route::get('/profil','controllerUtama@profil');
    Route::post('/topUp','controllerUtama@topUp');
    Route::post('/addHotelList','controllerUtama@AddWishList');
    Route::post('/delHotelList','controllerUtama@deleteList');
    Route::post('/prosesBook','controllerUtama@prosesBooking');
    Route::get('/cart', 'controllerUtama@Cart');


});

Route::group(['middleware' => 'cekAdmin'], function() {
    Route::get('/logAdmin','controllerUtama@Admin');
    Route::post('/prosesAddVoucher','controllerUtama@prosesAddVoucher');
    Route::post('/deleteVoucher','controllerUtama@deleteVoucher');
    Route::post('/tambahHotel','controllerUtama@addHotel');
    Route::post('/ActivateAndNonActivate','controllerUtama@deActivateHotel');
    Route::post('/banUser','controllerUtama@banUser');
    Route::get('/listuser','controllerUtama@listUser');
    Route::get('/voucher','controllerUtama@voucher');



});








