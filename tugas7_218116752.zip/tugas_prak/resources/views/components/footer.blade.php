<footer class="footer  drk" id="#footer" style="padding-top:2vh;padding-bottom:4vh">
    <div class="container">
      <div class="row">
        <div class="col-6" >
              <a ><strong>CONTACT US</strong></a>
              <hr style="border:0.9px solid red">
              <p>
                    Surabaya, Jawa Timur<br>
                    <strong>Phone:</strong>085334742388 / 081357639963<br>
                    <strong>Email:</strong>pasPut@gmail.com<br>
              </p>

              <div class="social-links">
                    <a href="" target="_blank"c lass="instagram"><i class="fa fa-instagram"></i></a>
              </div>
        </div>
        <div class="col-6 footer-contact">
            <a ><strong>ANOTHER LINK</strong></a>
            <hr style="border:0.9px solid red">
            <ul class="footer-link">
                <li><i class="ion-ios-arrow-right"></i> <a href="{{url('/218116752')}}">Home</a></li>
                <li><i class="ion-ios-arrow-right"></i> <a href="{{url('/hotel')}}">Hotel</a></li>
                <li><i class="ion-ios-arrow-right"></i> <a href="{{url('/login')}}">Login</a></li>
                <li><i class="ion-ios-arrow-right"></i> <a href="{{url('/regis')}}">Register</a></li>
                <li><i class="ion-ios-arrow-right"></i> <a href="{{url('/cart')}}">Cart</a></li>

              </ul>
        </div>
      </div>

    </div>
  </footer>
  <section style="background:#000000">
    <div class="container" >
    <div class="row " style="color:white;padding-top:1.2vh;padding-bottom:1vh;font-size:12pt">
          <div class="col-12 text-center"><p><strong>© Copyright PasPUT.com</strong></p></div>
          <div class="col-12 text-center"><p><strong>"Liburan dapat membuat anda melupakan masalah hidup anda!"</strong></p></div>
        </div>
    </div>
  </section>
