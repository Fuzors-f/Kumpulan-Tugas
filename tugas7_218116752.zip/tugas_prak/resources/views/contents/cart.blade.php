@extends('layout')
@section('content')
@php
    $page = "cart";
@endphp
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax5" style="color:white">
    <div class="transbox">


        <section id="form"  style="margin-top: -4vh">
            <div class="container">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold; text-align:left">CART</h1>
                    <hr style="border:2px solid white">
                <div class="row">
                    <div class="col-md-12 wow fadeInDown " data-wow-duration="1.6s" >
                        @isset($data)
                            @foreach ($data as $item)
                            {{-- <form action=""> --}}
                            <div class=" card mb-12 shadow-sm konten">
                                <div class="row">
                                    <div class="col-4">
                                    <img class="bd-placeholder-img " width="100%" height="100%" src="{{$item->url_gambar}}" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">

                                    </div>
                                    <div class="col-8">
                                        <div class="card-body" style="color:black;text-align :left">
                                            <h2>{{$item->nama_hotel}}</h2>
                                            <p class="card-text">Rp. {{$item->harga_malam}}/malam</p>
                                            <p class="card-text">
                                                Tanggal Transaksi : {{$item->tanggal_transaksi}} <br>
                                                Tanggal Check in : {{$item->check_in}}<br>
                                                Tanggal Check Out :{{$item->check_out}} <br>
                                                Total pembayaran :{{$item->total_bayar}} <br>


                                            </p>
                                            <p ><h5 style="color:red">{{$item->keterangan}}</h5></p>
                                            <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh ; width:100px" type="submit" name="submit"  value="Batalkan">
                                            <input class="btn btn-primary btn-lg btn-block " style="background-color:green; border:none; font-size:12pt; margin-top:2vh ; width:100px" type="submit" name="submit"  value="Bayar">

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <input type="hidden" name="idHotel" value="{{$item->id_hotel}}">
                            {{-- @csrf
                            </form> --}}
                            @endforeach


                        @endisset
                    </div>



                </div>
            </div>
            </section>
         </div>
    </div>
    {{-- <script>
        var anchors = document.getElementsByClassName('konten');
            for(var i = 0; i < anchors.length; i++) {
                var anchor = anchors[i];

                    anchor.onclick = function() {

                    //     var id_hotel = document.getElementById('idHotel').value;
                    //     var url = '{{url('/bookKamar',"id")}}';
                    //     url = url.replace('id', id_hotel);
                    //    window.location.href = url;

                    var form = anchor.getElementsByClassName('form_id')[0];
                        form.submit();
                    }

            }
    </script> --}}
@endsection
