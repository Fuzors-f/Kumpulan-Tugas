@extends('layout')
@section('content')
@php
    $page = "hotel";
@endphp
<div  style="background:black; color:white">
    <div class="transbox">
       <!-- Main jumbotron for a primary marketing message or call to action -->
    @isset($nama_hotel)


    <section style="background-image:url('{{$url_gambar}}');background-position: center; /* Center the image */
       background-repeat: no-repeat; /* Do not repeat the image */
       background-size: cover; ">
           <div class="jumbotron transbox2">
               <div class="container" style="padding-top:10vh">
               <h2 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold; font-size:30pt">{{$nama_hotel}}</h2>
               <form action="{{url('/addHotelList')}}" style="float:right" method="POST">
                   @csrf
                   <input type="hidden" name="idHotel_list" value ={{$id_hotel}}>
                   <input type="submit" class="btn btn-primary wow fadeInDown" data-wow-duration="2s" value="Add to Wishlist">
                    @isset($pesan)
                        <div class="invalid-feedback" style="display:block; margin:bottom:2vh">
                            <center><h6>{{$pesan}}</h6></center>
                        </div>
                    @endisset
                </form>
               <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">{{$alamat_hotel}}</p>
                   <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">Rate : 3.8</p>
                   <p class="wow fadeInUp" data-wow-duration="2.5s" style="font-weight:bold;">Rp.{{$harga_hotel}},00/malam</p>
                   <p class="card-text">
                    Contact Person : Grace - 0823172838123<br>
                    Berliburlah di hotel kami. Menyajikan pemandangan pasir putih, dapat melih sunset dengan jelas. Power by : pasPUT.com
                  </p>

               </div>
           </div>
       </section>
       @endisset
       <!-- section -->

       <section >
           <div class="container">
               <div class="row">
                   <div class="col-md-12 mb-3">
                      <h3>Reservasi Kamar</h3>
                   </div>

               </div>
               <hr style="border: 1px solid white">
               <form action="{{url('/prosesBook')}}" method ="POST">
                    @csrf
                    <div class="row" >

                    {{-- <div class="col-md-12 mb-3">
                        <label for="address">Nama Pemesan</label>
                        <input type="text" class="form-control" id="namaPemesan" name="namaPemesan"  required>
                        <div class="invalid-feedback">
                        Nama Masih Kosong!
                        </div>

                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="address">Email</label>
                        <input type="email" class="form-control" id="ktp" name="emailPemesan"  required>
                        <div class="invalid-feedback">
                        No Ktp masih kosong
                        </div>
                    </div>



                    <div class="col-md-12 mb-3">
                        <label for="address">No telepon</label>
                        <input type="number" class="form-control" id="tlp" name="tlp"  required>
                        <div class="invalid-feedback">
                        No telepon masih kosong
                        </div>
                    </div> --}}
                    <input type="hidden" name="idHotel" value ={{$id_hotel}}>
                    <input type="hidden" name="hargaHotel" value = "{{$harga_hotel}}">


                    {{-- <div class="col-md-12 mb-3">
                        <label for="address">Gender</label><br>
                        <input type="radio" name="gender" value="male" checked> Male<br>
                        <input type="radio" name="gender" value="female"> Female<br>

                    </div> --}}

                    <div class="col-md-5 mb-3">
                        <label for="address">Tanggal Check In</label>
                        <input type="datetime-local" class="form-control" id="chin" name="chin"  required>

                    </div>

                    <div class="col-md-5 mb-3">
                        <label for="address">Tanggal Check Out</label>
                        <input type="datetime-local" class="form-control" id="chout" name="chout"  required>

                    </div>

                    <div class="col-md-2 mb-3" >
                        {{-- <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh" type="submit" name="sub" value="Check Availability"> --}}

                    </div>

                    <div class="col-12">
                        @isset($pesan_error)
                            <div class="invalid-feedback" style="display:block; margin:bottom:2vh">
                               <center><h4>{{$pesan_error}}</h4></center>
                            </div>
                         @endisset
                    </div>


                    <div class="col-md-12 mb-3">
                        <label for="country">Voucher (dipotong dari total jumlah hari menginap)</label>
                        <select class="custom-select d-block w-100" id="vocuhers" name="vouchers">
                            <option value="">Tidak Pakai</option>
                            @isset($data_hotel)
                               @foreach ($data_hotel->Vouchers as $item)
                                <option value="{{$item->kode_voucher}}">{{$item->kode_voucher. " - Besar Potongan:".$item->potongan."%"}}</option>
                               @endforeach
                            @endisset

                        </select>
                    </div>

                    {{-- <div class="col-md-12 mb-3">
                        <label for="address">Fasilitas Tambahan</label>
                        <select class="form-control">
                            <option value="A">Tipe Kamar A</option>

                        </select>
                        <p>Keterangan : kamar dengan extra king bed untuk 2 orang, fasilitas air panas dan wi-fi gratis</p>
                    </div> --}}

                    <div class="col-md-12 mb-3 form-control" style="background:orangered;color:white; border:none; padding:5%">
                    <h2>Price : Rp. {{$harga_hotel}}/malam</h2>
                    </div>

                    {{-- <div class="col-md-12 mb-3">
                        <label for="address">Fasilitas Tambahan</label><br>
                        <input type="radio" name="gender" value="male" checked> Extra Bed<br>
                        <input type="radio" name="gender" value="female"> <br>

                    </div> --}}

                    <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none; font-size:12pt; margin-top:2vh; margin-bottom:4vh" type="submit" name="submit"  value="Submit">

                  </div>
                </form>

           </div>
       </section>
   </div>
</div>
<!-- end section -->
<script>
    // function cart(){
    //     document.location.href  = "{{url('/cart')}}"
    // }
</script>
@endsection
