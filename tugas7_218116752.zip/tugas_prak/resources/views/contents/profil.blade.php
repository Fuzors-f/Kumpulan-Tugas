@extends('layout')
@section('content')
<style>
.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.panel {
  padding: 0 18px;
  background-color: white;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}
</style>
<div  id="parallax3" class="parallax">
    <div class="transbox">
       <!-- Main jumbotron for a primary marketing message or call to action -->
       @php
           $page = "";
       @endphp
       {{-- @isset($pesanList)
       @php
            if(\Session::has("pesan") && sesssion("pesanList") != ""){
                $pesanList = sesssion("pesanList");
                echo "<script>alert($pesanList)</script>";
            }
       @endphp
       @endisset --}}
       <section >
           <div class="jumbotron transbox2">
               <div class="container" style="padding-top:10vh">
                   <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">YOUR PROFILE</h1>

               </div>
           </div>
       </section>

       <!-- section -->
       <section >
           <div class="container">
               <div class="row wow fadeInDown" data-wow-duration="2s">
                   <div class="col-12">
                       <div class="row">
                           <div class="col-4 text-center">
                                <svg class="bd-placeholder-img rounded-circle" width="150" height="150" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140" style="border:1px solid white"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
                           </div>
                           @isset($data)
                            <div class="col-4 text-left" style='color:white'>
                                    <h3>Nama  : {{$data[0]->nama}}</h3>
                                    <hr>
                                    <h3>Phone : {{$data[0]->telepon}}</h3>
                                    <hr>
                                    <h3>Email : {{$data[0]->email}}</h3>
                                    <hr>
                                    <h3>Saldo : Rp. {{$data[0]->saldo}},-</h3>
                                    <hr>
                            </div>
                           @endisset

                           <div class="col-4 " style="border:2px solid red;color:white; border-radius:8%">
                                <center><h1>Top UP</h1></center>
                                <form action="{{url('/topUp')}}" method="post">
                                    <p>Masukan nominal sebanyak kelipatan Rp.100.000,-</p>
                                    <input type="number" class="form-control" id="firstName" placeholder="100000" value="" name="saldo" >
                                    @error('saldo')
                                        <div class="invalid-feedback" style="display: block">
                                            {{$message}}
                                        </div>
                                    @enderror
                                    <input type="submit" class="btn btn-lg btn-primary btn-block"  value="Top Up" style="margin-top:2vh" required>
                                    @csrf
                                </form>
                           </div>

                       </div>
                       <div class="container">
                            <div class="row" style="margin-top:5vh; margin-bottom:5vh; color:white;padding:3%;
                            border:2px solid red; border-radius:15px">

                                            <div class="col-12"><h1 style="margin-top:2vh; margin-bottom:2vh">History</h1></div>
                                            @isset($dataTrans)
                                                @foreach ($dataTrans as $item)
                                                <div class="col-md-3 wow fadeInDown konten" data-wow-duration="1.6s" >
                                                    <form action="{{url('/bookKamar')}}" method="post" class="form_id">
                                                        @csrf
                                                        <div class="card mb-4 shadow-sm">
                                                            <img class="bd-placeholder-img card-img-top isiKonten" width="125" height="125" src="{{$item->url_gambar}}" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                                            <div class="card-body accordion" style="color:black">

                                                                    <h5>{{$item->nama_hotel}}</h5>
                                                                    <h6>Rp. {{$item->harga_malam}}/malam</h6>
                                                                    <p>Click Here to more Info</p>
                                                            <input type="hidden" name="idHotel" value="{{$item->id_hotel}}">
                                                            </div>
                                                            <div class="card-body panel" style="color:black">
                                                            <p>Tanggal Transaksi : {{$item->tanggal_transaksi}}</p>
                                                                <p>Check In : {{$item->check_in}}</p>
                                                                <p>Check Out : {{$item->check_out}}</p>
                                                                <p>Total Menginap : {{$item->jumlah_hari}} hari</p>
                                                                <p style="color:red">{{$item->keterangan}}</p>
                                                                <p>Total Bayar: Rp. {{$item->total_bayar}}</p>

                                                            </div>
                                                            <input type="submit" value="Cek Penginapan sekarang" class="btn  btn-primary btn-block">
                                                        </div>
                                                    </form>
                                                </div>
                                                @endforeach

                                            @endisset

                            </div>


                            <div class="container">
                                <div class="row" style="margin-top:5vh; margin-bottom:5vh; color:white;padding:3%;
                                border:2px solid red; border-radius:15px">

                                                <div class="col-12"><h1 style="margin-top:2vh; margin-bottom:2vh">Wish List</h1></div>
                                                @isset($dataList)
                                                    @foreach ($dataList as $item)
                                                    <div class="col-md-3 wow fadeInDown konten" data-wow-duration="1.6s" >
                                                        <form action="{{url('/bookKamar')}}" method="post" class="form_id">
                                                            @csrf
                                                            <div class="card mb-4 shadow-sm">
                                                                <img class="bd-placeholder-img card-img-top isiKonten" width="125" height="125" src="{{$item->url_gambar}}" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                                                <div class="card-body accordion" style="color:black">

                                                                        <h5>{{$item->nama_hotel}}</h5>
                                                                        <h6>Rp. {{$item->harga_hotel}}/malam</h6>
                                                                <input type="hidden" name="idHotel" value="{{$item->id_hotel}}">
                                                                </div>

                                                                <input type="submit" value="Cek Penginapan sekarang" class="btn  btn-primary btn-block">

                                                        </form>
                                                                <form action="{{url('/delHotelList')}}" method="post" class="form_id">
                                                                    @csrf
                                                                    <input type="hidden" name="idHotel" value="{{$item->id_hotel}}">
                                                                    <input type="submit" value="Hapus dari List" class="btn  btn-warning btn-block btndel" onsubmit="return false;">
                                                                </form>
                                                             </div>
                                                    </div>
                                                    @endforeach

                                                @endisset

                                </div>
                            </div>

                        </div>
                   </div>
               </div>
           </div>
       </section>
   </div>
</div>

<script>



var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}


var anchors = document.getElementsByClassName('btndel');
        for(var i = 0; i < anchors.length; i++) {
            //dapetin element form nya
            anchors[i].onclick = function() {
                var r = confirm("Are you Sure ?");
                if (r == true) {
                    var form =document.getElementsByClassName('form_id')[0];
                    form.submit();
                }

             }
        }
</script>

@endsection
