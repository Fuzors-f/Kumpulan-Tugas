@extends('layout')
@section('content')
 <div  id="parallax3" class="parallax">
     <div class="transbox">
        <!-- Main jumbotron for a primary marketing message or call to action -->
        @php
            $page = "hotel";
        @endphp
        <section >
            <div class="jumbotron transbox2">
                <div class="container" style="padding-top:10vh">
                    <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">HOTEL</h1>
                    <p class="wow fadeInUp" data-wow-duration="2.5s">Kami menawarkan hotel dari kelas bintang 3 sampai bintang 5 dengan harga terbaik dan termurah</p>
                    <p class="wow fadeInUp" data-wow-duration="2.5s">Click Hotel untuk melakukan booking dan  menampilkan info lebih lanjut </p>

                </div>
            </div>
        </section>

        <!-- section -->
        <section >
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <input type="text" class="form-control" id="firstName" placeholder="Cari Sekarang" value="" name="nama" required>
                        <div class="invalid-feedback">
                            Nama Masih kosong!.
                        </div>
                    </div>
                </div>
                <div class="row">

                        @isset($hotel)

                            @foreach ($hotel as $item)
                                @if ($item->status_hotel == 1)


                                <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                                <form action="{{url('/bookKamar')}}" method="post" class="form_id">
                                    @csrf
                                    <div class="card mb-4 shadow-sm">
                                        <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="{{$item->url_gambar}}" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                        <div class="card-body">
                                            <h2>{{$item->nama_hotel}}</h2>
                                            <input type="hidden" name="idHotel" value="{{$item->id_hotel}}" class="idHotel">
                                            <p class="card-text" >{{$item->alamat_hotel}}</p>
                                            <p class="card-text"style="font-weight:bold">Rate : 3.8</p>
                                            <p class="card-text" style="padding-top:-1vh">Mulai dari harga Rp. {{$item->harga_hotel}} -,</p>
                                        </div>

                                    </div>
                                </form>
                                </div>
                                @endif
                            @endforeach
                        @endisset

                        {{-- <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" >
                            <div class="card mb-4 shadow-sm">
                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="img/hotel.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                                <div class="card-body">
                                    <h2>Hotel Panorama</h2>
                                    <p class="card-text">Jl. Pasir Putih no 2</p>
                                    <p class="card-text">Rate : 3.8</p>
                                    <p class="card-text">Mulai dari harga Rp. 250.000.00 -,</p>
                                </div>
                            </div>
                        </div> --}}

                </div>
            </div>
        </section>
    </div>
</div>
<!-- end section -->
<script>
    var anchors = document.getElementsByClassName('konten');
        for(var i = 0; i < anchors.length; i++) {
            //dapetin element form nya
            anchors[i].onclick = function() {
                var form =this.getElementsByClassName('form_id')[0];
                    form.submit();
             }
        }
</script>
@endsection
