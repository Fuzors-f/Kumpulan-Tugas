@extends('layout')
@section('content')
@php
    $page = "admin";
@endphp
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }

      .accordion {
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: none;
        outline: none;
        transition: 0.4s;
        }

        .active, .accordion:hover {
             background-color: #ccc;
             color: black;
        }

        .panel {
        padding: 0 18px;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.2s ease-out;
        }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax5" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Admin </h1>


                  <div class="col-12" style='margin-top:2vh'>
                        <a href="{{url('/voucher')}}"><button class=" btn btn-primary btn-lg" style="margin:2%;">Go to Add Voucher</button></a>
                        <a href="{{url('/listuser')}}"><button class=" btn btn-primary btn-lg" style="margin:2%;">Go to Management User</button></a>
                    <h2 class="accordion">Add Hotel</h2>
                  <form class="needs-validation panel"  action="{{url('/tambahHotel')}}" method="post" enctype="multipart/form-data">
                              @csrf
                                <div class="row ">
                                  <div class="col-md-12 mb-3">
                                      <label for="firstName">Nama Hotel</label>
                                      <input type="text" class="form-control" placeholder="John Wick" id="namaHotel" placeholder="Nama Hotel"  name="namaHotel" >
                                      @error('namaHotel')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>
                              </div>

                              <div class="mb-3">
                                  <label for="address">Alamat Hotel</label>
                                  <input type="text" class="form-control" id="alamatHotel" placeholder="Jl Pasir Putih" name="alamatHotel">
                                  @error('alamatHotel')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                              </div>



                              <div class="row">
                                  <div class="col-md-7 mb-3">
                                      <label for="address">Url Photo</label>
                                      <div class="row">
                                        <input type="text" class="form-control" id="linkGambar" name="linkGambar"  >
                                        <button class="form-control" onclick="previewGambar();return false;" style='color:white;border:none; background:blue'>Show gambar</button>
                                      </div>
                                      @error('linkGambar')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>

                                  <div class="col-md-5 mb-3">
                                  <label for="address">Preview Gambar</label>
                                        <img src="" alt="" class="form-control" id="gambarHotel" style='height:200px;width:auto'>

                                  </div>


                                  <div class="col-md-12 mb-3">
                                      <label for="cc-number">Harga Hotel /malam</label>
                                      <input type="number" class="form-control" id="hargaHotel" name="hargaHotel" placeholder="200000" >
                                      @error('hargaHotel')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>

                                  {{-- <div class="col-md-12 mb-3">
                                    <label for="cc-number">No KTP</label>
                                    <input type="number" class="form-control" id="ktp" name="ktp" placeholder="0892137123" required>
                                    <div class="invalid-feedback">
                                        Mohon di isi No Ktp !
                                    </div>
                                </div> --}}

                              </div>





                              <hr class="mb-4">
                              <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                          </form>
                  </div>
              </div>


               {{-- nampilkan hotel --}}
               <div class="row " style="margin-top:8vh; margin-bottom : 2vh;color:white">
                <div class="col-12 ">
                    <h2 class="accordion">List Hotel</h2>
                    <div class="panel">
                        <table class="table table-dark panel">
                            <thead>
                                  <tr>
                                      <th>Nama Hotel</th>
                                      <th>Link Gambar Hotel</th>
                                      <th>Harga Per Malam</th>
                                      <th>Alamat Hotel</th>
                                      <th>Action</th>
                                  </tr>
                            </thead>
                            <tbody>
                                @isset($dataHotel)
                                  @foreach ($dataHotel as $item)
                                      <tr>
                                          <td>{{$item->nama_hotel}}</td>
                                          <td><a href="{{$item->url_gambar}}" target="_blank">{{$item->url_gambar}}</a></td>
                                          <td>
                                              Rp. {{$item->harga_hotel}}
                                          </td>
                                          <td>{{$item->alamat_hotel}}</td>
                                          <td class="btnSubs">
                                           <form action="{{url('/ActivateAndNonActivate')}}" class="buttonSub" method = "POST">
                                               @csrf
                                               <input type="hidden" name="kdHotel" value= "{{$item->id_hotel}}">
                                              @if ($item->status_hotel == 1)
                                                 <input type="submit" value="Non-Aktifkan" class = "btn btn-warning click "  style="background:red" >
                                              @else
                                                  <input type="submit" value="Aktifkan" class = "btn btn-primary click "  >
                                              @endif
                                           </form>
                                          </td>
                                      </tr>
                                  @endforeach

                                @endisset
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
          </div>
        </section>
         </div>
    </div>

    <script>
        function previewGambar(){
              var sourcs =  document.getElementById("linkGambar").value;
                document.getElementById('gambarHotel').src = sourcs;
        }


        var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px";
                }
            });
        }
    </script>

@endsection
