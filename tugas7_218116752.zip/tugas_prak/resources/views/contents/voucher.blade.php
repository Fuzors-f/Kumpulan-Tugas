@extends('layout')
@section('content')
@php
    $page = "admin";
@endphp
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
      .accordion {
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: none;
        outline: none;
        transition: 0.4s;
        }

        .active, .accordion:hover {
             background-color: #ccc;
             color: black;
        }

        .panel {
        padding: 0 18px;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.2s ease-out;
        }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax4" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Admin </h1>
                  <div class="col-12" style='margin-top:2vh'>
                    <a href="{{url('/logAdmin')}}"><button class=" btn btn-primary btn-lg" style="margin:2%">Go to Add Hotel</button></a>
                    <a href="{{url('/listuser')}}"><button class=" btn btn-primary btn-lg" style="margin:2%">Go to Management User</button></a>

                    <h2 class="accordion">Add Voucher</h2>
                  <form class="needs-validation panel"  action="{{url('/prosesAddVoucher')}}" method="post" enctype="multipart/form-data">
                              @csrf
                                <div class="row">
                                  <div class="col-md-12 mb-3">
                                      <label for="firstName">Kode Voucher</label>
                                  <input type="text" class="form-control"  id="kodeVoucher" value="{{$kodeHint}}"  name="kodeVoucher" >
                                      @error('kodeVoucher')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>
                              </div>

                              <div class="mb-3">
                                  <label for="address">Nama Penginapan</label> <br>
                                 @isset($dataPenginapan)
                                        @foreach ($dataPenginapan as $item)
                                             <input type="checkbox" style="margin:2%" name="hotel[]" value="{{$item->id_hotel}}"> <label>{{$item->nama_hotel}}</label>
                                         @endforeach
                                 @endisset

                                 @error('hotel')
                                 <div class="invalid-feedback" style="display: block">
                                     {{$message}}
                                 </div>
                                 @enderror
                              </div>


                                  <div class="col-md-12 mb-3">
                                      <label for="cc-number">Potongan harga (dalam %)</label>
                                      <input type="number" class="form-control" id="potonganHarga" name="potonganHarga" placeholder="" >
                                      @error('potonganHarga')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>


                                  <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="Add Voucher">

                              </div>

                          </form>
                  </div>

                  {{-- nampilkan voucher --}}
                  <div class="row" style="margin-top:8vh; margin-bottom : 2vh;color:white">
                    <div class="col-12">
                        <h2 class="accordion">List Voucher</h2>
                          <div class="panel">
                            <table class="table table-dark">
                                <thead>
                                      <tr>
                                          <th>Kode Voucher</th>
                                          <th>Besar Potongan (dalam%)</th>
                                          <th>Hotel</th>
                                          <th>Action</th>
                                      </tr>
                                </thead>
                                <tbody>
                                    @isset($dataVoucher)
                                      @foreach ($dataVoucher as $item)
                                          <tr>
                                              <td>{{$item->kode_voucher}}</td>
                                              <td>{{$item->potongan}}</td>
                                              <td>
                                                  @php


                                                   $tmp = "";
                                                   $data = $item->Hotels;
                                                  for ($i = 0; $i < count($data)-1; $i++){

                                                      $tmp = $tmp.$data[$i]->nama_hotel.",";


                                              }
                                              $tmp = $tmp.$data[count($data)-1]->nama_hotel;
                                              echo $tmp;
                                              @endphp
                                              </td>
                                              <td class="btnSubs">
                                               <form action="{{url('/deleteVoucher')}}" class="buttonSub" method = "POST">
                                                   @csrf
                                                   <input type="hidden" name="kdvoucher" value= "{{$item->kode_voucher}}">
                                                  @if ($item->deleted_at != null)
                                                     <input type="submit" value="Deleted" class = "btn btn-warning click "  style="background:red" onClick=" return false;" disabled>
                                                  @else
                                                      <input type="submit" value="Delete" class = "btn btn-warning click "  onClick=" return false;">
                                                  @endif
                                               </form>
                                              </td>
                                          </tr>
                                      @endforeach

                                    @endisset
                                </tbody>
                            </table>
                          </div>
                    </div>
                </div>
              </div>

          </div>
        </section>
         </div>
    </div>

    <script>
         var anchors = document.getElementsByClassName('btnSubs');
        for(var i = 0; i < anchors.length; i++) {
            //dapetin element form nya
            anchors[i].onclick = function() {
                var form =this.getElementsByClassName('buttonSub')[0];
                if (confirm('Are you sure you want to delete this thing from the database?')) {
                    form.submit();
                }
            }
        }


        var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px";
                }
            });
        }
    </script>

@endsection
