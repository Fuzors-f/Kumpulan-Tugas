@extends('layout')
@section('content')
@php
    $page = "admin";
@endphp
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
      /* .accordion {
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: none;
        outline: none;
        transition: 0.4s;
        }

        .active, .accordion:hover {
             background-color: #ccc;
             color: black;
        }

        .panel {
        padding: 0 18px;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.2s ease-out;
        } */
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax4" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Admin </h1>
                  <div class="col-12" style='margin-top:2vh'>
                    <a href="{{url('/logAdmin')}}"><button class=" btn btn-primary btn-lg" style="margin:2%">Go to Add Hotel</button></a>
                    <a href="{{url('/voucher')}}"><button class=" btn btn-primary btn-lg" style="margin:2%">Go to Add Voucher</button></a>



                  {{-- nampilkan user --}}
                  <div class="row" style="margin-top:8vh; margin-bottom : 2vh;color:white">
                    <div class="col-12">
                        <h2 class="accordion">List User</h2>
                          <div class="panel">
                            <table class="table table-dark">
                                <thead>
                                      <tr>
                                          <th>Nama</th>
                                          <th>Email</th>
                                          <th>Telepon</th>
                                          <th>Saldo</th>
                                          <th>Action</th>
                                      </tr>
                                </thead>
                                <tbody>
                                    @isset($dataCustomer)
                                      @foreach ($dataCustomer as $item)
                                          <tr>
                                              <td>{{$item->nama}}</td>
                                              <td>{{$item->email}}</td>
                                              <td>{{$item->telepon}}</td>
                                              <td>Rp. {{$item->saldo}}</td>

                                              <td class="btnSubs">
                                               <form action="{{url('/banUser')}}" class="buttonSub" method = "POST">
                                                   @csrf
                                                   <input type="hidden" name="kduser" value= "{{$item->id_customer}}">
                                                  @if ($item->status_customer == 1)
                                                     <input type="submit" value="Banned" class = "btn btn-warning click "  style="background:red" >
                                                  @else
                                                      <input type="submit" value="UnBanned" class = "btn btn-primary click " >
                                                  @endif
                                               </form>
                                              </td>
                                          </tr>
                                      @endforeach

                                    @endisset
                                </tbody>
                            </table>
                          </div>
                    </div>
                </div>
              </div>

          </div>
        </section>
         </div>
    </div>

    <script>
        //  var anchors = document.getElementsByClassName('btnSubs');
        // for(var i = 0; i < anchors.length; i++) {
        //     //dapetin element form nya
        //     anchors[i].onclick = function() {
        //         var form =this.getElementsByClassName('buttonSub')[0];
        //         if (confirm('Are you sure you want to delete this thing from the database?')) {
        //             form.submit();
        //         }
        //     }
        // }


        // var acc = document.getElementsByClassName("accordion");
        // var i;

        // for (i = 0; i < acc.length; i++) {
        //     acc[i].addEventListener("click", function() {
        //         this.classList.toggle("active");
        //         var panel = this.nextElementSibling;
        //         if (panel.style.maxHeight) {
        //             panel.style.maxHeight = null;
        //         } else {
        //             panel.style.maxHeight = panel.scrollHeight + "px";
        //         }
        //     });
        // }
    </script>

@endsection
