

@extends('layout')
@section('content')
@php
    $page = "home";
@endphp
<!-- carousel -->
 <section id="intro">
    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active">
            <div class="carousel-background"><img src="img/1.jpg"  style="width:100%" class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Ingin Berlibur Murah?</h2>
                <p>Ingin kepantai namun dengan harga murah ? Kami punya solusinya</p>
              <a href="{{url('/hotel')}}" class="btn-get-started scrollto">Cek Sekarang</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/2.jpg" style="width:100%" class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Tidak Perlu jauh jauh berlibur</h2>
                <p>Berlibur saja di pantai pasir putih Situbondo. Nikmati pemandangan Sunset dan hamparan pantai yang indah</p>
                <a href="{{url('/hotel')}}" class="btn-get-started scrollto">Cek Sekarang</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/3.jpg" class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Ingin Berlibur Murah?</h2>
                <p>Ingin kepantai namun dengan harga murah ? Kami punya solusinya</p>
                <a href="{{url('/hotel')}}" class="btn-get-started scrollto">Cek Sekarang</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/4.jpg"  class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Tidak Perlu jauh jauh berlibur</h2>
                <p>Berlibur saja di pantai pasir putih Situbondo. Nikmati pemandangan Sunset dan hamparan pantai yang indah</p>
                <a href="{{url('/hotel')}}" class="btn-get-started scrollto">Cek Sekarang</a>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#introCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon ion-chevron-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#introCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon ion-chevron-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>
  </section>
  <!-- end carousel -->
  <!-- section  -->
  <section id="featured-box">
    <div class="container center" >
      <div class="row ">
        <div class="col-sm-4 ">
            <i class="ion-ios-stopwatch-outline" style="color:red"></i>
            <h4>Lokasi mudah dijangkau</h4>
            <p>Perjalanan sekitar 4 jam dari kota Surabaya</p>
        </div>
        <div class="col-sm-4 " >
             <i class="ion-ios-heart-outline" style="color:red"></i>
            <h4>Tempat bagus untuk Rekreasi</h4>
            <p>Hilangkan jenuh dan penat anda di sini</p>
        </div>
        <div class="col-sm-4 " >
             <i class="ion-ios-analytics-outline" style="color:red"></i>
            <h4>Harga yang bersahabat</h4>
            <p>Tempat indah namun harga bersahabat</p>
        </div>
      </div>
    </div>
  </section>
  <!-- end section -->

  <!-- section -->
  <section id="parallax1" class="parallax">

    <div class="transbox">
      <div class="container" >
        <div class="row" style="margin-bottom:4vh;">
          <div class="col-12" style="text-align:center">
            <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
              <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;color:white">ABOUT US</h3>
                <hr style="border:2px solid red;width:15%; text-align:center">
            </header>
          </div>
        </div>

        <div class="row" style="margin-bottom:2vh; color:white">
            <div class="col-12 wow bounceInUp textabout" data-wow-duration="1.5s"id="textabout" >
              <p> pasPUT.com merupakan perusahaan di bidang travelling yang menjadikan Pantai Pasir Putih di Situbondo menjadi objek utama Wisata </p>
              <p> Kami dengan sepenuh hati melayani para customer kami, memberikan peayanan terbaik kami, mulai dari penyewaan hotel dan resort, serta wisata bahari Pasir Putih</p>
              <p> Tentu saja dengan harga yang pas di kantong, namun kami berikan pelayanan memuaskan </p>

            </div>
        </div>
        <br><br>

      </div>

    </div>
  </section>
  <!-- end   section -->

  <!-- section -->

  <section class="recent-posts" id="konten">
        <div class="container">
          <div class="row" style="margin-bottom:4vh;">
            <div class="col-12" style="text-align:center">
              <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
                <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;color:white;">OUR GALLERY</h3>
                <hr style="border:2px solid red;width:15%; text-align:center">
                </header>
            </div>
          </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">
                        <div class="post-content text-sm-right">
                            <h3>INi Liburan</a></h3>
                            <a class="post-btn" href="" ><i class="fa fa-arrow-right"></i></a>
                        </div>
                        <div class="post-thumb">
                            <img class="img-fluid" src="img/post1.jpg" style="width:273px;height:230px"alt="Post 1">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">
                        <div class="post-content text-sm-right">
                            <h3>INi Liburan</h3>
                            <a class="post-btn" href=""><i class="fa fa-arrow-right"></i></a>
                        </div>
                        <div class="post-thumb">
                            <img class="img-fluid" src="img/post2.jpg" style="width:273px;height:230px"alt="Post 1">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">
                        <div class="post-thumb">
                            <img class="img-fluid" src="img/post3.jpg" style="width:273px;height:230px"alt="Post 1">
                        </div>
                        <div class="post-content text-sm-right">
                            <h3>INi Liburan</h3>
                            <a class="post-btn" href=""><i class="fa fa-arrow-right"></i></a>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">

                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">
                        <div class="post-thumb">
                            <img class="img-fluid" src="img/post4.jpg" style="width:273px;height:230px"alt="Post 1">
                        </div>
                        <div class="post-content text-sm-right">
                            <h3>INi Liburan</h3>
                            <a class="post-btn" href=""><i class="fa fa-arrow-right"></i></a>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">

                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">

                        <div class="post-content text-sm-right">
                            <h3>INi Liburan</h3>
                            <a class="post-btn" href=""><i class="fa fa-arrow-right"></i></a>
                        </div>
                        <div class="post-thumb">
                            <img class="img-fluid" src="img/post5.png" style="width:273px;height:230px"alt="Post 1">
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">

                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">

                        <div class="post-content text-sm-right">
                            <h3>INi Liburan</h3>
                            <a class="post-btn" href=""><i class="fa fa-arrow-right"></i></a>
                        </div>
                        <div class="post-thumb">
                            <img class="img-fluid" src="img/post6.jpeg"style="width:273px;height:230px" alt="Post 1">
                        </div>

                    </div>
                </div>
            </div>

        </div>

    </section>
  <!-- end   section -->

  <!-- section -->

  <section id="parallax2" class="parallax" >
    <div class="transbox">
      <div class="container" style="color:white">
        <div class="row" style="margin-bottom:4vh;">
          <div class="col-12" style="text-align:center">
            <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
              <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;color:white">TESTIMONIAL</h3>
              <hr style="border:2px solid red;width:15%; text-align:center">
            </header>
          </div>
        </div>

        <div class="row wow flipInX center" data-wow-duration="1.5s " style="margin-top:4vh">
            <div class="col-12">
              <div id="myCarousel" class="carousel slide" data-ride="carousel" style="height:40vh">


                <div class="carousel-inner">

                 <div class='carousel-item active'>


                    <div class="container">
                      <div class="col-lg-12 text-left">
                        <h2 style="margin-top:1vh">Robert B Weidi</h2>
                        <p>"Pantainya bagus"</p>
                        <svg class="bd-placeholder-img rounded-circle" width="50" height="50" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140" style="border:1px solid white"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
                      </div>
                    </div>
                  </div>

                  <div class='carousel-item '>


                    <div class="container">
                      <div class="col-lg-12 text-left">
                        <h2 style="margin-top:1vh">Mila Chiron</h2>
                        <p>"Pasirnya benar benar putih, asik deh"</p>
                        <svg class="bd-placeholder-img rounded-circle" width="50" height="50" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140" style="border:1px solid white"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
                      </div>
                    </div>
                  </div>

                  <div class='carousel-item '>


                    <div class="container">
                      <div class="col-lg-12 text-left">
                        <h2 style="margin-top:1vh">Tigre Von Grant</h2>
                        <p>"Lumayan menyegarkan, pelayanan puas , mantab"</p>
                        <svg class="bd-placeholder-img rounded-circle" width="50" height="50" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140" style="border:1px solid white"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
                      </div>
                    </div>
                  </div>


                </div>

              </div>
            </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end section -->

  {{-- section --}}
  <section id="featured-box" style="padding-bottom:4vh">
    <div class="container center" >
        <div class="row">
            <div class="col-8">
                <div class="row">
                        <div class="col-12">
                            <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
                                <h3 style="font-size:20pt;font-weight:bold;margin-left:0.8vw;color:white">Sekilas Tentang Pasir Putih</h3>
                                  <hr style="border:2px solid red;width:15%; text-align:center">
                              </header>
                        </div>
                </div>
                <div class="row">
                    <div class="col-12 wow fadeInDown"  data-wow-duration="1.5s">
                        <p>Menyusuri Pantai Pasir Putih Situbondo membuat hati menjadi teduh. Pasirnya yang putih, airnya yang jernih dan gelombang ombak yang tidak terlalu besar membuat pantai ini menjadi sangat menyenangkan saat dikunjungi.</p>
                        <p>Wisata baharinya pun sangat memanjakan mata. Jika sudah puas berenang dan bermain di laut, maka di dekat pantai, banyak pedagang makanan kaki lima yang menyajikan makanan yang tak kalah menggiurkan</p>
                        <p>Jika sudah sore hari maka kita dapat melihat sunset dari tepi pantai. Tidak hanya itu Pantai pasir putih juga menyajikan wisata perahu yang juga tidak kalah menarik untuk di coba</p>
                        <p>Jadi tunggu apalagi ? segera berlibur di sini</p>


                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="col-12">
                    <div class="row wow fadeInDown"  data-wow-duration="1.5s">
                        <img src="img/img1.jpg" style="width:100%" alt="">
                    </div>
                    <div class="row wow fadeInDown"  data-wow-duration="1.5s">
                        <img src="img/img2.jpg" style="width:100%" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
  </section>

@endsection

