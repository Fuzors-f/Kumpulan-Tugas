@extends('layout')
@section('content')
@php
   $page = "register";
@endphp
<style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    /* html,
      body {
      height: 100%;
      }

      body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 40px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
      }

      .form-signin {
      width: 100%;
      max-width: 330px;
      padding: 15px;
      margin: auto;
      }
      .form-signin .checkbox {
      font-weight: 400;
      }
      .form-signin .form-control {
      position: relative;
      box-sizing: border-box;
      height: auto;
      padding: 10px;
      font-size: 16px;
      }
      .form-signin .form-control:focus {
      z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      } */
      #form{
          padding-top:20vh;
          padding-bottom: 5vh;
      }
      /* a{
          color:red;
      }
      a:hover{
          text-decoration:none;
          font-weight:bold;
          color:red;
      } */
      .mb-4:hover{
          cursor:pointer;
      }
      .warning{
          color:white;
          background:red;
          border-radius:4%;
          font-weight:bold;
          transition:0.2s;
          display:none;
      }
  </style>
  <!-- Custom styles for this template -->
  <link href="signin.css" rel="stylesheet">

<div class="text-center parallax" id="parallax5" style="color:white">
    <div class="transbox">

      <section id="form">
          <div class="container">
              <div class="row">
                  <h1>  Register </h1>
                  <div class="col-12" style='margin-top:2vh'>
                          <hr>
                      @isset($warning)
                          <h3 style="color:red;font-weight:bold">{{$warning}}</h3>
                      @endisset
                  <form class="needs-validation"  action="{{url('/prosesRegister')}}" method="post" enctype="multipart/form-data">
                              @csrf
                                <div class="row">
                                  <div class="col-md-12 mb-3">
                                      <label for="firstName">Name</label>
                                      <input type="text" class="form-control" placeholder="John Wick" id="firstName" placeholder=""  name="nama" >
                                      @error('nama')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>
                              </div>

                              <div class="mb-3">
                                  <label for="address">Email</label>
                                  <input type="text" class="form-control" id="email" placeholder="1234@gmail.com" name="email">
                                  @error('email')
                                  <div class="invalid-feedback" style="display: block">
                                      {{$message}}
                                  </div>
                                  @enderror
                              </div>



                              <div class="row">
                                  <div class="col-md-5 mb-3">
                                      <label for="address">Password</label>
                                      <input type="password" class="form-control" id="passw" name="pass"  >
                                      {{-- <div class="invalid-feedback">
                                      Password Masih kosong !.
                                      </div> --}}
                                  </div>

                                  <div class="col-md-7 mb-3">
                                  <label for="address">Confirm Password</label>
                                      <input type="password" class="form-control" id="passw_confirmation" name="pass_confirmation"  >
                                      {{-- <div class="invalid-feedback">
                                      Konfirm Password Masih kosong !.
                                      </div> --}}
                                  </div>
                                  @error('pass')
                                  <div class="invalid-feedback" style="display: block">
                                      {{$message}}
                                  </div>
                                  @enderror
                                  {{-- <div class="col-md-12 mb-3" id="warning1"></div> --}}

                                  <div class="col-md-12 mb-3">
                                      <label for="cc-number">Phone</label>
                                      <input type="text" class="form-control" id="phone" name="phone" placeholder="0892137123" >
                                      {{-- <div class="invalid-feedback">
                                          Mohon di isi Teleponnya !
                                      </div> --}}

                                      @error('phone')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                  </div>

                                  {{-- <div class="col-md-12 mb-3">
                                    <label for="cc-number">No KTP</label>
                                    <input type="number" class="form-control" id="ktp" name="ktp" placeholder="0892137123" required>
                                    <div class="invalid-feedback">
                                        Mohon di isi No Ktp !
                                    </div>
                                </div> --}}

                              </div>

                              <div class="row">
                                  <div class="col-md-5 mb-3">
                                      @isset($captcha)
                                      <h2 style="font-size: 18pt"><label for="address">Masukan Captcha : {{$captcha}}</label></h2>
                                      @endisset
                                  </div>

                                  <div class="col-md-7 mb-3">
                                     <input type="text" class="form-control" id="captch" name="captch"  >
                                     @error('captch')
                                      <div class="invalid-feedback" style="display: block">
                                          {{$message}}
                                      </div>
                                      @enderror
                                </div>
                              </div>





                              <hr class="mb-4">
                              <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                          </form>
                  </div>
              </div>
          </div>
        </section>
         </div>
    </div>

    <script>
        // $('#passw, #passw_confirmation').on('keyup', function () {
        //     if ($('#passw').val() == $('#passw_confirmation').val()) {
        //         $('#warning1').html('Matching').css('color', 'green');
        //     } else
        //         $('#warning1').html('Not Matching').css('color', 'red');
        // });
    </script>

@endsection
