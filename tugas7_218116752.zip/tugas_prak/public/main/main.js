(function ($) {
    "use strict";
    $(window).scroll(function() {
        if ($(this).scrollTop() > 80) {
            $('#nav').removeClass('bg-tr');
            $('#nav').addClass('bg-tx');
            $('#kotak').removeClass('container');
            $('#kotak').removeClass('borderbtm');
            $('#kotak').addClass('container-fluid');
        } else {
            $('#nav').removeClass('bg-tx');
            $('#nav').addClass('bg-tr');
            $('#kotak').addClass('container');
            $('#kotak').addClass('borderbtm');
            $('#kotak').removeClass('container-fluid');

        }
    });

   // Initiate the wowjs animation library
   new WOW().init();

    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
        $('.back-to-top').fadeIn('slow');
        } else {
        $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function(){
        $('html, body').animate({scrollTop : 0},1500, 'easeInOutExpo');
        return false;
    });

    // PRE LOADER
    $(window).load(function(){
        $('.preloader').fadeOut(3000); // set duration in brackets
    });

    // if (window.matchMedia("(max-width: 600px)").matches) {
    //     /* The viewport is less than, or equal to, 700 pixels wide */
    //     $(".icontop").attr("src","img/iconz3.png");
    //   }else{
    //     $(".icontop").attr("src","img/iconz2.png");
    //   }
})(jQuery);
