<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Hotel;
use App\Models\Tabel_on;
use App\Models\Transaksi;
use App\Models\Voucher;
use App\Rules\alpha_space;
use App\Rules\CaptchaRule;
use App\Rules\CekEmailCookie;
use App\Rules\CekKelipatanSaldo;
use App\Rules\CekKodeVoucher;
use App\Rules\CekPhoneCookie;
use App\Rules\CekPotonganVoucher;
use App\Rules\EmailRule;
use App\Rules\rulePass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\DB;

use function GuzzleHttp\json_decode;

class controllerUtama extends Controller
{


    //melempar ke halaman home

    function Home(){
        $captcha = [
            "MinUMjus",
            "dEsTroYER",
            "kueBULAN",
            "mAKanAyam",
            "CarRier",
            "coRONA",
            "LoreMipSUM",
            "COllonel",
            "WarSHIP",
            "BaTtLeShIp",
            "AIRCRAft",
            "GraYs",
            "PERsona",
            "TheFT",
            "HEarT",
            "gREEn",
            "NasIGOREng",
            "MEAts",
            "DomPET",
            "YaHALLO",
            "mOTheR"
        ];

        Cookie::queue('captcha',json_encode($captcha),60);


        $userlog = Cookie::get("logon");
       $yglog = "";
       if($userlog != null){
            $userlog = json_decode($userlog,true);
            $yglog = $userlog[0];
       }
       return view('contents.index',[
           "logon" => $yglog
       ]);
    }

    //melempar ke cart

    function Cart(){
        $userlog = Cookie::get("logon");
       $yglog = "";
       $idlog = Cookie::get('log_id');
       $datatmp = null;
       if($userlog != null){
            $userlog = json_decode($userlog,true);
            $yglog = $userlog[0];
            $idlog = json_decode($idlog,true);
            // $datatmp = DB::table('transaksi as trans')->select(["trans.total_bayar","htl.nama_hotel","htl.url_gambar","htl.alamat_hotel","trans.id_hotel","trans.check_in","trans.check_out","trans.jumlah_hari","htl.harga_hotel"])
            // ->where("trans.id_customer", $idlog[0])
            // ->join("hotel as htl","trans.id_hotel","htl.id_hotel")->get();
            $datatmp = Customer::find($idlog[0]);
            $datatmp =$datatmp->Transaksis()
            ->join('hotel','transaksi.id_hotel','hotel.id_hotel')->get();
       }
       return view('contents.cart',[
           "logon" =>$yglog,
           "data" =>$datatmp
       ]);
    }

    //mengarahkan ke tampilan cari hotel dan melemparkan data hotel
    function cariHotel(){
       $userlog = Cookie::get("logon");
       $yglog = "";
       if($userlog != null){
            $userlog = json_decode($userlog,true);
            $yglog = $userlog[0];
       }
        $hotel = Hotel::all();
        if($hotel==null){
            $hotel = [];
        }
        return view('contents.hotel',[
            "hotel" => $hotel,
            "logon" =>$yglog
        ]);
    }

    //mengarahkan ke tampilan login
    function Login(){
        $dataCaptcha = Cookie::get('captcha');
        if($dataCaptcha == null){
            $dataCaptcha = [];
        }else{
            $dataCaptcha = json_decode($dataCaptcha,true);
        }

        $dr = rand(0,count($dataCaptcha)-1);
        $captchaRegis = $dataCaptcha[$dr];
        $cpterpilih = array($captchaRegis);
        Cookie::queue('selecCaptcha',json_encode($cpterpilih),60);

        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
       return view('contents.login',[
           "logon" => $yglog,
           "captcha" =>$captchaRegis
       ]);
    }

    //memproses data dari form login
    function prosesLogin(Request $request){
        $rule = [
            "phoneRegis" => ['required', 'numeric'],
            "passRegis" => ['required'],
            "inputCaptcha" => ['required',new CaptchaRule]
        ];
        $error = [
            "required" => ":attribute harus di isi!",
            "numeric" => ":attribute harus berupa angka tidak boleh mengandung text",
        ];

        $this->validate($request,$rule,$error);

        if(intval($request->phoneRegis)== 888 && $request->passRegis =="888"){
            $cek = true;
            $users = array("admin");
            $userid =array("admin");
            Cookie::queue('log_id',json_encode($userid),60);
            Cookie::queue('logon',json_encode($users),60);
            return redirect('/logAdmin');
        }


        $tmpUser = Customer::where('telepon',$request->phoneRegis)->where('password',$request->passRegis)->get();

        if(count($tmpUser)>0){
            $cekLog = Tabel_on::where('id_customer',$tmpUser[0]->id_user)->where('status_on',1)->get();
            if(count($cekLog)==0){
                Cookie::queue('log_id',json_encode(array($tmpUser[0]->id_customer)),60);
                Cookie::queue('logon',json_encode(array($tmpUser[0]->nama)),60);
                $dataTabel = [
                    "id_customer" => $tmpUser[0]->id_customer,
                    "status_on" => 1,
                ];
                $dtable_on = new Tabel_on;
                $dtable_on->status_on = 1;
                $dtable_on->id_customer = $tmpUser[0]->id_customer;
                $dtable_on->save();
                return redirect('/hotel');

            }else {
                echo "<script>alert('user ini sudah melakukan login');</script>";
                //window.location.href=".url('218116752').";";
                $yglog = "";
                return view('contents.index',[
                    "logon" => $yglog
                ]);

            }

        }else{
            return redirect('/login');
        }
    }

    //menambahkan hotel
    function addHotel(Request $request){
        $rule = [
            "namaHotel" => ['required',new alpha_space,'max:20'],
            "alamatHotel" => ['required','max:50'],
            "linkGambar" =>['required'],
            "hargaHotel" => ['numeric','required']
        ];

        $error = [
            "required" => ':attribute harus di isi tidak boleh kosong',
            "max" => ':attribute terlalu panjang, panjang maksimal adalah :max karakter',
            "numeric" => ':attribute hanya boleh terdiri dari angka'
        ];

        $this ->validate($request,$rule,$error);

        $tmp = Hotel::all();
        $idhotel = "HO".count($tmp);
        $hargahotel = intval($request->hargaHotel);
        $hoteltmp = [
            "id_hotel" => $idhotel,
            "nama_hotel" =>$request->namaHotel,
            "harga_hotel" => $hargahotel,
            "url_gambar" => $request->linkGambar,
            "alamat_hotel" => $request->alamatHotel,
            "status_hotel" => 1,

        ];

       Hotel::create($hoteltmp);
       echo "<script>alert('hotel berhasil di tambahkan')</script>";
        return redirect('/logAdmin');
    }


    //mengarahkan ke tampilan admin
    function Admin()
    {
        $dataHotel = Hotel::all();
        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        return view('contents.admin',[
            "logon" =>$yglog,
            "dataHotel" =>$dataHotel
        ]);
    }


    //mengarahkan ke tampilan register
    function Register(){
        $dataCaptcha = Cookie::get('captcha');
        if($dataCaptcha == null){
            $dataCaptcha = [];
        }else{
            $dataCaptcha = json_decode($dataCaptcha,true);
        }

        $dr = rand(0,count($dataCaptcha)-1);
        $captchaRegis = $dataCaptcha[$dr];
        $cpterpilih = array($captchaRegis);
        Cookie::queue('selecCaptcha',json_encode($cpterpilih),60);
        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        return view('contents.register',[
            "logon" =>$yglog,
            "captcha" =>$captchaRegis
        ]);
    }

    //mengarahkan ke tampilan keterangan hotel beserta book Kamar
    function booking(Request $request){
        $id_hotel = $request->idHotel;
        $hotelData = Hotel::find($id_hotel);
        $hotelNama = "";
        $hotelHarga = 0;
        $hotelAlamat = "";
        $urGambar = "";

        if($hotelData != null){
                    $hotelNama =$hotelData->nama_hotel;
                    $hotelHarga = $hotelData->harga_hotel;
                    $hotelAlamat = $hotelData->alamat_hotel;
                    $urGambar =$hotelData->url_gambar;

        }
        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }else{
            return redirect('/login');
        }

        return view('contents.bookKamar',[
            "logon" => $yglog,
            "id_hotel" =>$id_hotel,
            "nama_hotel" =>$hotelNama,
            "harga_hotel" =>$hotelHarga,
            "url_gambar" =>$urGambar,
            "alamat_hotel" =>$hotelAlamat,
            "data_hotel" => $hotelData
        ]);
    }

    //fungsi untuk proses booking hotel
    function prosesBooking(Request $request){
        $id_hotel = $request->idHotel;
        $idlog = Cookie::get('log_id');
        $iduser ="";
        $tanggalchin = date_create($request->chin);
        $tanggalchout = date_create($request->chout);
        $harga_hotel = intval($request->hargaHotel);
        $saldouser = 0;
        $banyakhari = 0;
        $cek = true;
        $pesan_error ="";

        $rule =[
            "chout" => "required",
            "chin" => "required"
        ];

        $this ->validate($request,$rule);

        if($idlog!= null){
            $idlog = json_decode($idlog,true);
            $iduser = $idlog[0];
        }else{
            return redirect('/login');
        }

        $tmp = Customer::find($iduser);
        if($tmp != null){
            $saldouser = intval($tmp->saldo);
        }

        if($tanggalchout<= $tanggalchin){
            $cek =false;
            $pesan_error = "data tanggal tidak valid";
        }else{
            $banyakhari=intval(date_diff($tanggalchout,$tanggalchin)->days);
            $totalbayar = ($harga_hotel * $banyakhari) ;
            //proses penghitungan dan masukkan ke dbase
            $pt = Voucher::find($request->vouchers);//mencari potongan dari tabel voucher
            $potongan = 0;
            $keterangan ="";
            if($pt != null){
                $potongan = intval($pt->potongan);
                $keterangan = "Menggunakan kode voucher : ".$pt->kode_voucher." Sebesar : Rp.".(($totalbayar*$potongan)/100);
            }


           $totalbayar = $totalbayar - (($totalbayar*$potongan)/100);
            if($saldouser<$totalbayar){
                $cek = false;
                $pesan_error ="saldo tidak mencukupi";
            }else{
                $saldouser = $saldouser - $totalbayar;
                $tmpdb = Customer::find($iduser);
                $tmpdb->saldo = $saldouser;
                $tmpdb->save();
              //  DB::table('customer')->where('id_customer',$iduser)->update(["saldo"=>$saldouser]);
                //$idtmp = DB::table('transaksi')->select('*')->get();
                $idtmp = Transaksi::all();
                $id_transaksi = "TR".count($idtmp);

                date_default_timezone_set("Asia/Bangkok");
                $tanggal_transaksi =date("Y-m-d h:i:s");
                $data = [
                    "id_transaksi" =>$id_transaksi,
                    "id_hotel" => $id_hotel,
                    "id_customer" => $iduser,
                    "check_in" => $tanggalchin,
                    "check_out" => $tanggalchout,
                    "jumlah_hari"=> $banyakhari,
                    "total_bayar"=> $totalbayar,
                    "tanggal_transaksi"=>$tanggal_transaksi,
                    "harga_malam"=>$harga_hotel,
                    "keterangan"=>$keterangan
                ];

                Transaksi::create($data);

                return redirect('/hotel');
            }
        }

        //kalo gagal
        if($cek == false){
            $hotelData = Hotel::where('id_hotel',$id_hotel)->get();
            $hotelNama = "";
            $hotelHarga = 0;
            $hotelAlamat = "";
            $urGambar = "";

            if($hotelData != null){
                foreach($hotelData as $Item){
                        $hotelNama =$Item->nama_hotel;
                        $hotelHarga = $Item->harga_hotel;
                        $hotelAlamat = $Item->alamat_hotel;
                        $urGambar =$Item->url_gambar;
                }
            }
            $userlog = Cookie::get("logon");
            $yglog = "";
            if($userlog != null){
                 $userlog = json_decode($userlog,true);
                 $yglog = $userlog[0];
            }
            return view('contents.bookKamar',[
                "logon" => $yglog,
                "id_hotel" =>$id_hotel,
                "nama_hotel" =>$hotelNama,
                "harga_hotel" =>$hotelHarga,
                "url_gambar" =>$urGambar,
                "alamat_hotel" =>$hotelAlamat,
                "pesan_error"=> $pesan_error,
                "data_hotel" => $hotelData

            ]);
        }
    }


    //memproses form register ke tika di submit di check manual dan di masukkan ke cookie
    function prosesRegister(Request $request){

        $rules =[
            "nama"=> ['required','max:24'],
            "email" => ['required', new EmailRule, new CekEmailCookie],
            "phone" => ['required','numeric',new CekPhoneCookie],
            "pass" =>['confirmed','required','min:8','max:12', new rulePass],
            "captch" => [new CaptchaRule,'required']
        ];

        $error =[
            'required' => ':attribute harus diisi!',
            'numeric' => ':attribute harus angka',
            'max' => ':attribute melebihi panjang maksimal sebanyak :max',
            'confirmed' => 'Pass dan confirm tidak sama',
            'min' => ':attribute harus memiliki panjang minimal sebanyak :min karakter'
        ];

        $this->validate($request,$rules,$error);
        $id_customer = Customer::all();
        $id_cust ="CU". count($id_customer);
        $dt = [
            "id_customer" => $id_cust,
            "nama" => $request->input('nama'),
            "email" =>$request->input('email'),
            "telepon" =>$request->input('phone'),
            "password" =>$request->input('pass'),
            "saldo" => 0,
            "status_customer" => 1
        ];

        Customer::create($dt);
        echo "<script>alert('Berhasil Register')</script>";
       return redirect('/login');


    }


    function Logout(){
        $dt  =Cookie::get('logon');
        $dt = json_decode($dt,true);

        if($dt[0]  !="admin"){
            $dtid = Cookie::get('log_id');
            $dtid = json_decode($dtid,true);
            $tmp_table = Tabel_on::where('id_customer',$dtid[0])->where('status_on',1)->get();
            $logout = Tabel_on::find($tmp_table[0]->id);
            $logout->status_on = 0;
            $logout->save();
            $dtid[0] = "";
            Cookie::queue('log_id',json_encode($dtid),60);
        }


        $dt[0] = "";
        Cookie::queue('logon',json_encode($dt),60);
        return redirect('/218116752');
    }



    function profil(Request $request){
        $idlog =Cookie::get('log_id');
        $dataList = null;
        $nama ="";
        $phone = "";
        $saldo = 0;
        $email = "";
        $data = null;
        $datatmp = null;
        if($idlog != null){
            $idlog = json_decode($idlog,true);
            $data = Customer::where('id_customer',$idlog[0])->get();
            $datatmp = Customer::find($idlog[0]);
            $datatmp =$datatmp->Transaksis()
            ->join('hotel','transaksi.id_hotel','hotel.id_hotel')->get();
        }
        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        $namasession = $yglog."-listHotel";
        $dataList = $request->session()->get($namasession);
        return view('contents.profil',[
            "logon" => $yglog,
            "data" =>$data,
            "dataTrans" => $datatmp,
            "dataList" =>$dataList
        ]);
    }


    function topUp(Request $request){
        $rule = [
            "saldo" => ["required", "numeric", new CekKelipatanSaldo]
        ];
        $this->validate($request,$rule);
        $idlog =Cookie::get('log_id');
        $idlog = json_decode($idlog,true);
        $saldolama = Customer::where('id_customer',$idlog[0])->get();

        $saldo = intval($request->saldo) + intval($saldolama[0]->saldo);
        $update = Customer::find($idlog[0]);
        $update->saldo = $saldo ;
        $update->save();

        return redirect("/profil");
    }

    //mengarahkan ke halaman voucher
    function voucher(){
        $userlog = Cookie::get("logon");
        $dataPenginapan = Hotel::all();
        $voucher = Voucher::withTrashed()->get();
        $kode_Voucher ="";
        if(count($voucher)<10){
            $kode_voucher = "KO00".count($voucher);
        }else if(count($voucher)>9 && count($voucher)<100){
            $kode_voucher = "KO0".count($voucher);
        }else{
            $kode_voucher ="KO".count($voucher);
        }
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        return view('contents.voucher',[
            "logon" =>$yglog,
            "dataPenginapan" =>$dataPenginapan,
            "kodeHint"=>$kode_voucher,
            "dataVoucher" =>$voucher
        ]);
    }

    //proses nambah voucher
    function prosesAddVoucher(Request $request){
        $rule = [
            "hotel"=>["required"],
            "kodeVoucher"=> ["required",new CekKodeVoucher],
            "potonganHarga" =>["required","numeric",new CekPotonganVoucher]
        ];
        $this->validate($request,$rule);
        $data = new Voucher;
        $data->kode_voucher = $request->kodeVoucher;
        $data->potongan  = $request->potonganHarga;
        for($i =0; $i<count($request->hotel);$i++){
            $data ->Hotels()->attach($request->hotel[$i]);
        }
        $data->save();
        return redirect('/voucher');
    }

    //proses hapus voucher
    function deleteVoucher(Request $request){
        $data = Voucher::find($request->kdvoucher);
        $data->delete();

        return redirect('/voucher');
    }



    //add List Hotel
    function AddWishList(Request $request){

        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        $namaSession = $yglog."-listHotel";

        $hotelData = Hotel::find($request->idHotel_list);
        $hotelNama = "";
        $hotelHarga = 0;
        $hotelAlamat = "";
        $urGambar = "";

        if($hotelData != null){
                    $hotelNama =$hotelData->nama_hotel;
                    $hotelHarga = $hotelData->harga_hotel;
                    $hotelAlamat = $hotelData->alamat_hotel;
                    $urGambar =$hotelData->url_gambar;

        }
        $dataSession = $request->session()->get($namaSession);
        if($dataSession != null){
            $pesan = "";
            for($i =0; $i<count($dataSession);$i++){
                if($dataSession[$i]->id_hotel == $request->idHotel_list){
                    $pesan = "Hotel Sudah terdapat dalam list";
                }
            }

            if($pesan == ""){
                $request->session()->push($namaSession,$hotelData) ;
            }
            return view('contents.bookKamar',[
                "logon" => $yglog,
                "id_hotel" =>$request->idHotel_list,
                "nama_hotel" =>$hotelNama,
                "harga_hotel" =>$hotelHarga,
                "url_gambar" =>$urGambar,
                "alamat_hotel" =>$hotelAlamat,
                "data_hotel" => $hotelData,
                "pesan"=> $pesan
            ]);
        }else{
            $request->session()->push($namaSession,$hotelData) ;
            return view('contents.bookKamar',[
                "logon" => $yglog,
                "id_hotel" =>$request->idHotel_list,
                "nama_hotel" =>$hotelNama,
                "harga_hotel" =>$hotelHarga,
                "url_gambar" =>$urGambar,
                "alamat_hotel" =>$hotelAlamat,
                "data_hotel" => $hotelData,
            ]);
        }
    }


    //untuk hapus dari list
    public function deleteList(Request $request){
        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        $namaSession = $yglog."-listHotel";
        $idhoteldel = $request->idHotel;
        $index = -1;
        $namahotel = "";
        $dataSession = $request->session()->pull($namaSession);
        for($i=0; $i<count($dataSession); $i++){
            if($dataSession[$i]->id_hotel == $idhoteldel){
                $index = $i;
                $namahotel = $dataSession[$i]->nama_hotel;
            }
        }
        $pesan = "";
        if($index != -1){
            unset($dataSession[$index]);
            $dataArrbaru = array_values($dataSession);
            $request->session()->put($namaSession,$dataArrbaru) ;
            $pesan = "Hotel ".$namahotel." berhasil di hapus dari list";
        }

        return redirect("/profil")->with('pesanList',$pesan);
    }


    //fungsi untuk activate dan deactivate hotel
    public function deActivateHotel(Request $request){
        $hotel = Hotel::find($request->kdHotel);
        $db = $hotel->first();
        if($db->status_hotel == 1){
            $hotel = Hotel::find($request->kdHotel);
            $hotel->status_hotel = 2;
            $hotel->save();
        }else{
            $hotel = Hotel::find($request->kdHotel);
            $hotel->status_hotel = 1;
            $hotel->save();
        }
        return redirect('/logAdmin');
    }

    //fungsi ini untuk menampilkan halaman listuser pada admin
    public function listUser(){
        $dataCust = Customer::all();
        $userlog = Cookie::get("logon");
        $yglog = "";
        if($userlog != null){
             $userlog = json_decode($userlog,true);
             $yglog = $userlog[0];
        }
        return view('contents.listuser',[
            "logon" =>$yglog,
            "dataCustomer" =>$dataCust
        ]);
    }


    //fungsi bann unbann user
    public function banUser(Request $request){
        $cust = Customer::find($request->kduser);
        $db = $cust->first();
        if($db->status_customer == 1){
            $cust = Customer::find($request->kduser);
            $cust->status_customer = 2;
            $cust->save();
        }else{
            $cust = Customer::find($request->kduser);
            $cust->status_customer = 1;
            $cust->save();
        }
        return redirect('/listuser');
    }
}
