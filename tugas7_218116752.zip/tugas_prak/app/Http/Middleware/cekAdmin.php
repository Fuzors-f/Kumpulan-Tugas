<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Cookie;

class cekAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $data = Cookie::get('logon');

        if($data == null ){
            return redirect(url()->previous())->with('pesan',"na");
        }else{
            $dtArr = json_decode($data);
            if($dtArr[0] != "admin"){
                return redirect(url()->previous())->with('pesan',"na");
            }
        }

        return $next($request);
    }
}
