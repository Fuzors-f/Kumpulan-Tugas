<?php

namespace App\Http\Middleware;

use App\Models\Customer;
use App\Models\Tabel_on;
use Closure;
use Illuminate\Support\Facades\Cookie;

class chcekLogin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $idcust = Cookie::get('log_id');
        if($idcust != null){
            $idcustomer = json_decode($idcust);
            $data = Customer::find($idcustomer)->first();
            if($data != null && $data->status_customer == 2){
                $dt  =Cookie::get('logon');
                $dt = json_decode($dt,true);

                if($dt[0]  !="admin"){
                    $dtid = Cookie::get('log_id');
                    $dtid = json_decode($dtid,true);
                    $tmp_table = Tabel_on::where('id_customer',$dtid[0])->where('status_on',1)->get();
                    $logout = Tabel_on::find($tmp_table[0]->id);
                    $logout->status_on = 0;
                    $logout->save();
                    $dtid[0] = "";
                    Cookie::queue('log_id',json_encode($dtid),60);
                }


                $dt[0] = "";
                Cookie::queue('logon',json_encode($dt),60);

                return redirect(url()->previous())->with('pesan',"nc");
            }
        }
        return $next($request);
    }
}
