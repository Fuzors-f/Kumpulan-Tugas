<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hotel extends Model
{
    //
    protected $connection= 'mysql';
    protected $primaryKey = 'id_hotel';
    protected $table= 'hotel';
    public $timestamps = false;
    public $incrementing   = false; //apakah id auto increment

    protected $guarded = [
    ];

    public function Vouchers(){
        return $this->belongsToMany(Voucher::class, 'voucher_hotel','id_hotel','kode_voucher');
    }

    public function Transaksis(){
        return $this->belongsTo(Transaksi::class,"id_hotel","id_hotel");
    }
}
