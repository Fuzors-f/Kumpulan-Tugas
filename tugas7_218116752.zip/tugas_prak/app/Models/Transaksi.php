<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    //
    protected $connection= 'mysql';
    protected $primaryKey = 'id_transaksi';
    protected $table= 'transaksi';
    public $timestamps = false;
    public $incrementing   = false; //apakah id auto increment

    protected $guarded = [
    ];

    public function Customers(){
        return $this->belongsTo(Customer::class,"id_customer","id_customer");
    }
}
