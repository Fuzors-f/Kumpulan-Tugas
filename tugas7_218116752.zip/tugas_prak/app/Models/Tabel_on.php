<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tabel_on extends Model
{
    //
    protected $connection= 'mysql';
    protected $primaryKey = 'id';
    protected $table= 'tabel_on';
    public $timestamps = false;
    public $incrementing   = true; //apakah id auto increment

    protected $guarded = [
    ];


}
