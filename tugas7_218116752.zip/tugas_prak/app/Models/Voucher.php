<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Voucher extends Model
{
    //

    use SoftDeletes;

    protected $connection= 'mysql';
    protected $primaryKey = 'kode_voucher';
    protected $table= 'voucher';
    public $timestamps = true;
    public $incrementing   = false; //apakah id auto increment

    protected $guarded = [
    ];

    public function Hotels(){
        //dbase yg ditengah harus id_tabel satunya, baru id yg tabel ini
        //pola: class satunya, nama tabel di tengah, id tabel ini, id dari tabel class satunya
        return $this->belongsToMany(Hotel::class,'voucher_hotel','kode_voucher','id_hotel')
                    ->as('voucher_hotel');

    }
}
