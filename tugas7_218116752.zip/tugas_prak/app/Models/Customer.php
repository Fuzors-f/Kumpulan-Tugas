<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    //
    protected $connection= 'mysql';
    protected $primaryKey = 'id_customer';
    protected $table= 'customer';
    public $timestamps = false;
    public $incrementing   = false; //apakah id auto increment

    protected $guarded = [
    ];

    public function Transaksis(){
        return $this->hasMany(Transaksi::class,"id_customer","id_customer");
    }



}
