<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\Cookie;

class CaptchaRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $valid = true;
        $captcha = Cookie::get('selecCaptcha');
        $captcha =json_decode($captcha,true);
        $capthcaterpilih = str_split($captcha[0]);
        $isianCaptcha = str_split($value);
        $ctrfix = strlen($captcha[0]);
        $ctrfix2 =strlen($value);

        if($ctrfix == $ctrfix2){
            for($i=0;$i<$ctrfix;$i++){
                if($capthcaterpilih[$i]!= $isianCaptcha[$ctrfix2-1-$i]){
                    $valid =false;
                }
            }
        }else{
            $valid = false;
        }

        return $valid;


    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'Captcha salah tidak palindrom';
    }
}
