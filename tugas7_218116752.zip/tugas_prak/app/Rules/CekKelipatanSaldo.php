<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class CekKelipatanSaldo implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $valid = false;
        if(intval($value) % 100000 == 0) $valid = true;
        return $valid;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'Saldo yang anda inputkan buka kelipatan 100k';
    }
}
