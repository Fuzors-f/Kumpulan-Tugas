package com.example.sharkpedia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;

import java.util.ArrayList;

public class home extends AppCompatActivity {

    RecyclerView rv_sharks;
    ArrayList<Sharks> sharks;
    private String[] dataName;
    private String[] dataDescription;
    private String[] dataLokasi;
    private String[] dataPanjang;
    private String[] dataBerat;
    private TypedArray dataPhoto;
    private ListSharksAdapter listSharksAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        setContentView(R.layout.activity_home);
        rv_sharks = findViewById(R.id.rv_sharks);
        setResource();
        showRecyclerList();
    }

    public void setResource(){
        dataName = getResources().getStringArray(R.array.data_name);
        dataDescription = getResources().getStringArray(R.array.data_keterangan);
        dataPhoto = getResources().obtainTypedArray(R.array.data_photo);
        dataLokasi = getResources().getStringArray(R.array.data_lokasi);
        dataBerat = getResources().getStringArray(R.array.data_berat);
        dataPanjang = getResources().getStringArray(R.array.data_panjang);

        sharks = new ArrayList<>();

        //petakan ke arraylist

        for (int i = 0; i<dataName.length;i++){
            Sharks sh = new Sharks();
            sh.setNamahiu(dataName[i]);
            sh.setBeratHiu(dataBerat[i]);
            sh.setHabitatHiu(dataLokasi[i]);
            sh.setPanjagHiu(dataPanjang[i]);
            sh.setKeteranganHiu(dataDescription[i]);
            sh.setGambarHiu(dataPhoto.getResourceId(i,-1));
            sharks.add(sh);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menu_person){
            Intent i = new Intent(home.this,AboutMe.class);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    private void showRecyclerList(){
        rv_sharks.setLayoutManager(new LinearLayoutManager(this));
        listSharksAdapter = new ListSharksAdapter(sharks);
        rv_sharks.setAdapter(listSharksAdapter);
        listSharksAdapter.setOnItemClickCallback(new ListSharksAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Sharks data) {
                Intent i = new Intent(home.this,keteranganHiu.class);
                Sharks sp = data;
                i.putParcelableArrayListExtra("listshark", sharks);
                i.putExtra("shark",sp);
                startActivity(i);
            }

        });
    }
}