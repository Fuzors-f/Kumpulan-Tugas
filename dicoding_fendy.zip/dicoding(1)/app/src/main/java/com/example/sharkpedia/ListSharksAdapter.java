package com.example.sharkpedia;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListSharksAdapter extends  RecyclerView.Adapter<ListSharksAdapter.ListViewHolder>{
    ArrayList<Sharks> list;


    public ListSharksAdapter(ArrayList<Sharks> list) {
        this.list = list;
    }



    @NonNull
    @Override
    public ListSharksAdapter.ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_shark_list,parent,false);
        return new ListViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListSharksAdapter.ListViewHolder holder, int position) {
        Sharks  shark = list.get(position);

        holder.tvName.setText(shark.getNamahiu());
        holder.tvDesc.setText(shark.getKeteranganHiu());
        holder.imgPhoto.setImageResource(shark.getGambarHiu());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickCallback.onItemClicked(
                        list.get(holder.getAdapterPosition())
                );
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDesc;
        ImageView imgPhoto;
        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.textView_name);
            tvDesc = itemView.findViewById(R.id.textView_desc);
            imgPhoto = itemView.findViewById(R.id.imageView_photo);

        }
    }

    //diketik sendiri ini utk menbambahkan handling click
    public interface OnItemClickCallback{
        void onItemClicked(Sharks data);
    }

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }
}
