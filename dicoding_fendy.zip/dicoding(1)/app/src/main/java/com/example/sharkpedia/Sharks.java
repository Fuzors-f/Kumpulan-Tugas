package com.example.sharkpedia;

import android.os.Parcel;
import android.os.Parcelable;

public class Sharks implements Parcelable {
    String namahiu;
    String beratHiu;
    String panjagHiu;
    String HabitatHiu;
    String KeteranganHiu;
    int gambarHiu;


    protected Sharks(Parcel in) {
        namahiu = in.readString();
        beratHiu = in.readString();
        panjagHiu = in.readString();
        HabitatHiu = in.readString();
        KeteranganHiu = in.readString();
        gambarHiu = in.readInt();
    }

    public static final Creator<Sharks> CREATOR = new Creator<Sharks>() {
        @Override
        public Sharks createFromParcel(Parcel in) {
            return new Sharks(in);
        }

        @Override
        public Sharks[] newArray(int size) {
            return new Sharks[size];
        }
    };

    public int getGambarHiu() {
        return gambarHiu;
    }

    public void setGambarHiu(int gambarHiu) {
        this.gambarHiu = gambarHiu;
    }

    public String getNamahiu() {
        return namahiu;
    }

    public void setNamahiu(String namahiu) {
        this.namahiu = namahiu;
    }

    public String getBeratHiu() {
        return beratHiu;
    }

    public void setBeratHiu(String beratHiu) {
        this.beratHiu = beratHiu;
    }

    public String getPanjagHiu() {
        return panjagHiu;
    }

    public void setPanjagHiu(String panjagHiu) {
        this.panjagHiu = panjagHiu;
    }

    public String getHabitatHiu() {
        return HabitatHiu;
    }

    public void setHabitatHiu(String habitatHiu) {
        HabitatHiu = habitatHiu;
    }

    public String getKeteranganHiu() {
        return KeteranganHiu;
    }

    public void setKeteranganHiu(String keteranganHiu) {
        KeteranganHiu = keteranganHiu;
    }


    public Sharks(){}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(namahiu);
        parcel.writeString(beratHiu);
        parcel.writeString(panjagHiu);
        parcel.writeString(HabitatHiu);
        parcel.writeString(KeteranganHiu);
        parcel.writeInt(gambarHiu);
    }
}
