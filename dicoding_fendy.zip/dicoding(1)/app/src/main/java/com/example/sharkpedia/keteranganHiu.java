package com.example.sharkpedia;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

public class keteranganHiu extends AppCompatActivity {

    Sharks  hiu;
    TextView tvNamaHiu, tvLokasiHiu,tvBeratHiu, tvPanjangHiu, tvKeteranganHiu;
    ImageView gambar;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keterangan_hiu);
//        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
        tvNamaHiu = findViewById(R.id.text_nama_hiu);
        tvPanjangHiu =findViewById(R.id.text_panjang_hiu);
        tvBeratHiu = findViewById(R.id.text_bobot_hiu);
        tvLokasiHiu = findViewById(R.id.text_lokasi_hiu);
        tvKeteranganHiu = findViewById(R.id.text_info_hiu);
        tvPanjangHiu = findViewById(R.id.text_panjang_hiu);
        gambar = findViewById(R.id.imageView_photo_hiu);

        hiu = getIntent().getParcelableExtra("shark");



        tvNamaHiu.setText(hiu.getNamahiu());
        tvPanjangHiu.setText(hiu.getPanjagHiu());
        tvLokasiHiu.setText(hiu.getHabitatHiu());
        tvBeratHiu.setText(hiu.getBeratHiu());
        tvKeteranganHiu.setText(hiu.getKeteranganHiu());
        gambar.setImageResource(hiu.getGambarHiu());
    }
}