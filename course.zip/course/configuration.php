<?php 
    session_start();
    $host = "localhost";
    $user = "root";
    $password = "";
    $dbBase = "course";
    $conn = mysqli_connect($host,$user,$password,$dbBase);
?>