<?php
    require_once("../configuration.php");
    $title  = " - Login";
    $salah = "";
    if(isset($_GET['false'])){
        $salah = "salah";
    }
?>

<!doctype html>
<html lang="en">
  <head>
    <?php include("title.php")?>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      html,
        body {
        height: 100%;
        }

        body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
        }

        .form-signin {
        width: 100%;
        max-width: 330px;
        padding: 15px;
        margin: auto;
        }
        .form-signin .checkbox {
        font-weight: 400;
        }
        .form-signin .form-control {
        position: relative;
        box-sizing: border-box;
        height: auto;
        padding: 10px;
        font-size: 16px;
        }
        .form-signin .form-control:focus {
        z-index: 2;
        }
        .form-signin input[type="email"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }
        .form-signin input[type="password"] {
            margin-bottom: 10px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;    
        }

        a{
            color:red;
        }
        a:hover{
            text-decoration:none;
            font-weight:bold;
            color:red;
        }
        .mb-4:hover{
            cursor:pointer;
        }
        .warning{
            color:white;
            background:red;
            border-radius:4%;
            font-weight:bold;
            transition:0.2s;
            display:none;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>
  <body class="text-center">

    <nav class="navbar navbar-expand-md   fixed-top" >
        <button class="btn btn-warning btn-secondary my-2 my-sm-0" type="button" onclick="home()" style="margin-right:0.5vw">
            Home
        </button>
        <button class="btn btn-warning btn-secondary my-2 my-sm-0" type="button" onclick="register()">
            Register
        </button> 
        
    </nav>
    <form class="form-signin" action="checklogin.php" method ="post" >
        <div class="warning" id="warning"><p>Email atau password salah !</p></div>
        <img class="mb-4" src="img/iconz.png" alt="" width="72" height="72" id="loginmaster">

        <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
        
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="email" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="pass" required>
        <div class="checkbox mb-3">
            <label>
                <input type="checkbox"  onclick="shows()"> Show password
            </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" style="background:orangered; border:none" name="sign" >Sign in</button>
        <a href="forgotpasw.php" style="font-size:16pt">Forgot Password</a>

    </form>
</body>
</html>
<?php include("script.php");?>
<script>
   
    var cek = "<?=$salah?>";
    if(cek=="salah"){
        document.getElementById("warning").style.display="block";
    }

    $("#loginmaster").click(function(){
        window.location.href= "../Master";
    });

    function shows() {
		var x = document.getElementById("inputPassword");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}

    function home(){
        window.location.href="index.php";
    }

    function register(){
        window.location.href = "register.php";
    }

    // function getisi(){
    //     var email = document.getElementById("inputEmail").value;
    //     var pass = document.getElementById("inputPassword").value;
    //     if(email !="" && pass !=""){
    //         $.ajax({
    //         method: "post",
    //         url: "checklogin.php",
    //         data: {
    //             email: email,
    //             pass :pass
    //         },
    //         success: function (data) {
    //               if(data == "0"){
    //                 
    //               }
    //         });
    //     }
    // }
</script>

