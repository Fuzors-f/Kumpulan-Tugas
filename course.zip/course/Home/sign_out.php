<?php 

    require_once("../configuration.php");
    unset ($_SESSION['LOGIN']);
    unset ($_SESSION['email']);
    header("Location: index.php");

?>