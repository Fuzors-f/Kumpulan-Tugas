<?php 
    require_once("../configuration.php");
    $number = 0;
    $title = "";
    $flagkonten = 1;
    $flagtestimoni = 1;
    $flagteam = 1;

    $query1 = "SELECT * FROM KONTEN WHERE STATUS = 1";
    $res1 = mysqli_query($conn,$query1);
    if(mysqli_num_rows($res1) < 4) $flagkonten = 0;
    
    $query2 = "SELECT * FROM TESTIMONI WHERE STATUS = 1";
    $res2 = mysqli_query($conn,$query2);
    if(mysqli_num_rows($res2) < 3) $flagtestimoni = 0;

    $query3 = "SELECT * FROM PENGAJAR WHERE STATUS = 1";
    $res3 = mysqli_query($conn,$query3);
    if(mysqli_num_rows($res3) < 3) $flagteam = 0;


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <?php include("title.php"); ?>
 
</head>
<style>
  #parallax1{
     /* The image used */
    background-image: url('img/parallax.jpg');
  }

  #parallax2{
    background-image: url('img/parallax2.jpg');
  }

  #parallax3{
    background-image: url('img/parallax3.jpg');
  }
  
</style>
<body>
   <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  <!-- carousel -->
  <section id="intro">
    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active">
            <div class="carousel-background"><img src="img/1.jpg" class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>We are professional</h2>
                <p>Meski Kami masih muda, namun kami bekerja secara professional dan bertanggung jawab. Bergabunglah bersama kami menjadi tenaga pengajar kami</p>
                <a href="register.php" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/2.jpg"  class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Bimbingan belajar murah dan berkualitas</h2>
                <p>Ingin mencari tempat les-lesan yang murah namun berkualitas? Kami punya solusinya. Di sini kami menawarkan harga yang murah namun dengan kualitas yang terebaik. Guru guru muda yang berinofativ dan kreatif. Jadi tunggu apa lagi ??</p>
                <a href="joinUs.php" class="btn-get-started scrollto">Join Us</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/3.jpg" class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>We are proffesional</h2>
                <p>Meski Kami masih muda, namun kami bekerja secara professional dan bertanggung jawab. Bergabunglah bersama kami menjadi tenaga pengajar kami</p>
                <a href="register.php" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/4.jpg"  class="imgcarousel" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Bimbingan belajar murah dan berkualitas</h2>
                <p>Ingin mencari tempat les-lesan yang murah namun berkualitas? Kami punya solusinya. Di sini kami menawarkan harga yang murah namun dengan kualitas yang terebaik. Guru guru muda yang berinofativ dan kreatif. Jadi tunggu apa lagi ??</p>
                <a href="joinUs.php" class="btn-get-started scrollto">Join Us</a>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#introCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon ion-chevron-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#introCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon ion-chevron-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>
  </section>
  <!-- end carousel -->
  <!-- section  -->
  <section id="featured-box">
    <div class="container center" >
      <div class="row ">
        <div class="col-sm-4 ">
            <i class="ion-ios-stopwatch-outline" ></i>
            <h4>Pengajar Muda dan Berbakat</h4>
            <p> Kami di Orion Course, terdiri dari anak muda yang memiliki banyak ide kreatif dan memiliki daya juang yang tinggi </p>
        </div>
        <div class="col-sm-4 " >
             <i class="ion-ios-heart-outline" ></i>
            <h4>Kakak Kakak yang ramah dan siap membantu</h4>
            <p>Tidak hanya masih muda, namun kita juga ramah loh</p>
        </div>
        <div class="col-sm-4 " >
             <i class="ion-ios-analytics-outline" ></i>
            <h4>Harga yang bersahabat</h4>
            <p>Tidak hanya ramah, namun juga ramah di dompet</p>
        </div>
      </div>
    </div>
  </section>
  <!-- end section -->

  <!-- section -->
  <section id="parallax1" class="parallax">
    
    <div class="transbox">
      <div class="container" >
        <div class="row" style="margin-bottom:4vh;">   
          <div class="col-12" style="text-align:center">
            <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
              <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;color:white">ABOUT US</h3>
              <hr style="width:10vw; margin-top:-1vh;border:5px solid white">
            </header>
          </div>
        </div>

        <div class="row" style="margin-bottom:2vh; border:2px solid white;color:white">
            <div class="col-12 wow bounceInUp textabout" data-wow-duration="1.5s"id="textabout" >
              <p> Orion Course merupakan lembaga les les milenial yang menciptakan bimbingan belajar privat dan kelas. Terbentuk dari anak anak muda yang berbakat dan berpotensi dan bertanggung jawab  </p>
              <p> Tidak hanya mencari murid les , kami juga terbuka untuk merekrut tenaga pengajar untuk bergabung bersama kita </p>
            </div>
        </div>
        <br><br>
       
      </div>

    </div>
  </section>
  <!-- end   section -->
  
  <!-- section -->
  <?php 
      $querykonten = "SELECT * FROM KONTEN WHERE STATUS = 1 LIMIT 4";
      $resultkonten = mysqli_query($conn,$querykonten);
      $judulkonten = [];
      $idkonten = [];
      $gambarkonten = [];
      $pathkonten = [];
      $ctrkonten = 0;
      foreach($resultkonten as $key=>$data){
        $idkonten[$ctrkonten] = $data['ID_KONTEN'];
        $judulkonten[$ctrkonten] = $data['NAMA_KONTEN'];
        $gambarkonten[$ctrkonten] = $data['GAMBAR_KONTEN'];
        $pathkonten [$ctrkonten] = "conten_stuff.php?idkonten=".$data['ID_KONTEN'];
        $ctrkonten++;
      }
     
  ?>
  <section class="recent-posts" id="konten">
        <div class="container">
          <div class="row" style="margin-bottom:4vh;">   
            <div class="col-12" style="text-align:center">
              <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
                <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;color:white;">OUR CONTENT</h3>
                <hr style="width:10vw; margin-top:-1vh;border:5px solid red">
              </header>
            </div>
          </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.5s">
                        <div class="post-content text-sm-right">
                            <h3><a href="<?=$pathkonten[0]?>"><?=$judulkonten[0]?></a></h3>
                            <a class="post-btn" href="<?=$pathkonten[0]?>"><i class="fa fa-arrow-right"></i></a>
                        </div>
                        <div class="post-thumb">
                            <img class="img-fluid" src="<?=$gambarkonten[0]?>" alt="Post 1">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.7s">
                        <div class="post-thumb">
                            <img class="img-fluid" src="<?=$gambarkonten[1]?>" alt="Post 1">
                        </div>
                        <div class="post-content">
                            <h3><a href="<?=$pathkonten[1]?>"><?=$judulkonten[1]?></a></h3>
                            <a class="post-btn" href="<?=$pathkonten[1]?>"><i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="1.9s" >
                        <div class="post-content text-sm-right">
                            <h3><a href="<?=$pathkonten[2]?>"><?=$judulkonten[2]?></a></h3>
                            <a class="post-btn" href="<?=$pathkonten[2]?>"><i class="fa fa-arrow-right"></i></a>
                        </div>
                        <div class="post-thumb">
                            <img class="img-fluid" src="<?=$gambarkonten[2]?>" alt="Post 1">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-rpost d-sm-flex align-items-center wow lightSpeedIn" data-wow-duration="2.1s" >
                        <div class="post-thumb">
                            <img class="img-fluid" src="<?=$gambarkonten[3]?>" alt="Post 1">
                        </div>
                        <div class="post-content">
                            <h3 ><a href="<?=$pathkonten[3]?>"><?=$judulkonten[3]?></a></h3>
                            <a class="post-btn" href="<?=$pathkonten[3]?>"><i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center wow fadeInUp" data-wow-duration="3s">
                <a href="content.php" class="btn btn-primary yellow-btn">See More</a>
            </div>
        </div>
    </section>
  <!-- end   section -->
  <!-- section -->
  <?php 
      $querytestimoni = "SELECT * FROM TESTIMONI WHERE STATUS = 1";
      $resulttesti = mysqli_query($conn,$querytestimoni);
      $namatestimoni = [];
      $isitestimoni = [];
      $fototestimoni = [];
      $ctr = 0;
      foreach($resulttesti as $key=>$data){
        $namatestimoni[$ctr] = $data["NAMA_TESTIMONI"];
        $isitestimoni[$ctr] = $data["ISI_TESTIMONI"];
        $fototestimoni[$ctr] = $data["GAMBAR_TESTIMONI"];
        $ctr++;
      }
  ?>
  <section id="parallax2" class="parallax" >
    <div class="transbox">
      <div class="container" style="color:white">
        <div class="row" style="margin-bottom:4vh;">   
          <div class="col-12" style="text-align:center">
            <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
              <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;">TESTIMONIAL</h3>
              <hr style="width:10vw; margin-top:-1vh;border:5px solid white">
            </header>
          </div>
        </div>

        <div class="row wow flipInX center" data-wow-duration="1.5s " style="margin-top:4vh">
            <div class="col-12">
              <div id="myCarousel" class="carousel slide" data-ride="carousel" style="height:40vh">

                <ol class="carousel-indicators indi" >
                  <?php
                      for($i=0;$i<$ctr;$i++){
                        if($i==0){
                          echo "<li data-target='#myCarousel' data-slide-to='$i' class='active'></li>";
                        }else {
                          echo "<li data-target='#myCarousel' data-slide-to='$i'></li>";
                        }
                      }
                  ?>
                </ol>

                <div class="carousel-inner">

                 <?php
                    for($i=0;$i<$ctr;$i++){
                      if($i==0) echo "<div class='carousel-item active'>"; else echo "<div class='carousel-item'>";
                 ?>
                  
                    <div class="container">
                      <div class="col-lg-12 text-left">
                        <h2 style="margin-top:1vh"><?=$namatestimoni[$i]?></h2>
                        <p><?=$isitestimoni[$i]?></p>
                        <svg class="bd-placeholder-img rounded-circle" width="50" height="50" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140" style="border:1px solid white"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
                      </div>
                    </div>
                  </div>
                    <?php }?>

                </div>
              
              </div>
            </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end section -->
  <!-- section -->
  <?php
      $queryteam = "SELECT * FROM PENGAJAR WHERE STATUS = 1 LIMIT 3";
      $result = mysqli_query($conn,$queryteam);
      $nama = [];
      $motto = [];
      $line = [];
      $instagram = [];
      $imageprofil = [];
      $pathig = [];
      $ctrp = 0;

      foreach($result as $key=>$data){
        $nama[$ctrp] = $data['NAMA_PENGAJAR'];
        $motto[$ctrp] = $data['MOTTO'];
        $line[$ctrp] = $data['LINE'];
        $instagram[$ctrp] = $data['INSTAGRAM'];
        $pathig[$ctrp] = "https://www.instagram.com/".$data['INSTAGRAM'];
        $imageprofil[$ctrp] = "../Master/".$data['FOTO'];
        $ctrp++;
      }
  ?>
  <section id="aboutteam" data-stellar-background-ratio="0.5" style="color:white;background-color:black">
          <div class="container">
               <div class="row">

               <div class="col-12" style="text-align:center">
                  <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
                    <h3 style="font-size:25pt;font-weight:bold;margin-left:0.8vw;color:white">OUR TEAMS</h3>
                    <hr style="width:10vw; margin-top:-1vh;border:5px solid red">
                  </header>
                </div>
              </div>
              <div class="text-center wow fadeInUp" data-wow-duration="3s" style="margin-bottom:4vh;margin-top:3vh">
                  <a href="team.php" class="btn btn-primary yellow-btn">See Full Team</a>
              </div>
              <div class="row" style="margin-top:2vh;">
                    <div class="col-md-4 col-sm-4 wow rollIn" wow-data-duration="1.2s">
                         <div class="team-thumb">
                              <div class="team-info team-thumb-down">
                                   <hr style="border:2px solid red">
                                   <h2><?=$nama[0]?></h2>
                                   <p><i><?=$motto[0]?></i></p>
                                   <p><i class="fa fa-instagram"></i><a class="instahref" href="<?=$pathig[0]?>" target="_blank">@<?=$instagram[0]?></a></p>
                                   <p>Line : <a style="padding-left:0.4vw" ><?=$line[0]?></a></p>
                                   <hr style="border:2px solid red">
                              </div>
                              <img src="<?=$imageprofil[0]?>" class="img-responsive" alt="<?=$nama[0]?>" >
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4 wow rollIn" wow-data-duration="1.2s">
                         <div class="team-thumb">
                              <img src="<?=$imageprofil[1]?>" class="img-responsive" alt="<?=$nama[1]?>" >
                              <div class="team-info team-thumb-up">
                                  <hr style="border:2px solid red">
                                   <h2><?=$nama[1]?></h2>
                                   <p><i><?=$motto[1]?></i></p>
                                   <p><i class="fa fa-instagram"></i><a class="instahref"  href="<?=$pathig[1]?>" target="_blank">@<?=$instagram[1]?></a></p>
                                   <p>Line : <a style="padding-left:0.4vw" ><?=$line[1]?></a></p>
                                   <hr style="border:2px solid red">
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4 wow rollIn" wow-data-duration="1.2s">
                         <div class="team-thumb">
                              <div class="team-info team-thumb-down">
                                   <hr style="border:2px solid red">
                                   <h2><?=$nama[2]?></h2>
                                   <p><i><?=$motto[2]?></i></p>
                                   <p><i class="fa fa-instagram"></i><a class="instahref"  href="<?=$pathig[2]?>" target="_blank">@<?=$instagram[2]?></a></p>
                                   <p>Line : <a style="padding-left:0.4vw" ><?=$line[2]?></a></p>
                                   <hr style="border:2px solid red">
                              </div>
                              <img src="<?=$imageprofil[2]?>" class="img-responsive" alt="<?=$nama[2]?>" >
                         </div>
                    </div>
                    
                    
               </div>
          </div>
     </section>
  <!-- end section -->
  <!-- section -->
  <section id="parallax3" class="parallax" >
      <div class="transbox">
        <div class="container">
            <div class="row">
                <div class="col-12" style="text-align:center">
                  <header class="section-header wow fadeInDown"  data-wow-duration="1.5s" style="padding-top:6vh;color:black;">
                    <h3 style="font-size:30pt;font-weight:bold;margin-left:0.8vw;color:white">COME JOIN US</h3>
                  </header>
                </div>
            </div>
            <div class="row wow fadeInDown" data-wow-duration="1.5s" style="padding-bottom:3vh">
              <div class="col-12" style="text-align:center;font-weight:bold;color:white; font-size:18pt;margin-top:2vh;margin-bottom:4vh">
                  <p> Jadi tunggu apa lagi ?? ayo segera join bersama kami.. Kami menantikan anda join.. Klik button di bawah ini</p>
                  <button class="click-here" onclick="join()">Click Here </button>
              </div>
            </div>
        </div>
      </div>
  </section>
  

  <!-- end section -->
  <!-- footer -->
   <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
 <?php include("script.php");?>

<script>
  var flagkonten = parseInt("<?=$flagkonten?>");
  var flagtestimoni = parseInt("<?=$flagtestimoni?>");
  var flagteam = parseInt("<?=$flagteam?>");

  if(flagkonten != 1){
      $("#konten").hide();
  }

  if(flagtestimoni != 1){
    $("#parallax2").hide();
  }

  if(flagteam != 1){
    $("#aboutteam").hide();
  }

  function join(){
    window.location.href = "joinUs.php";
  }
</script>