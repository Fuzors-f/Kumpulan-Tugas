<?php 
    require_once("../configuration.php");
    $id=  $_SESSION['LOGIN'];

    $name = $_REQUEST['nama'];
    $pass = $_REQUEST['pass'];
    $phone = $_REQUEST['phone'];
    $motto = $_REQUEST['motto'];
    $line = $_REQUEST['line'];
    $insta = $_REQUEST['instagram'];
    $email = $_REQUEST['email'];
    $potolama =$_REQUEST['potolama'];


    $target_dir = "../Master/Image_pengajar/"; //<- ini folder tujuannya
    $target_file = $target_dir. basename($_FILES["photo"]["name"]); //murni mendapatkan namanya saja tanpa path nya 
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $imagefoto = "Image_pengajar/".basename($_FILES["photo"]["name"]);
    $flag = false;
    if(basename($_FILES["photo"]["name"]) != ""){
        if($file_type !="jpg" && $file_type !="png"){
            header("Location: edit_profile.php?false=2");
        } else if($_FILES["photo"]["size"] > 500000){
            header("Location: edit_profile.php?false=3");
        } else{
            if(move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)){

                $flag = true;
            }
        }
    }else{
        $imagefoto = $potolama;
        $flag = true;
    }

    if($flag==true){
        $queryes = "UPDATE `PENGAJAR` SET `NAMA_PENGAJAR`='$name',`EMAIL`='$email',`PASSWORD`='$pass',`TELEPON`='$phone',`LINE`='$line',`INSTAGRAM`='$insta',`FOTO`='$imagefoto',`MOTTO`='$motto' WHERE ID_PENGAJAR = '$id'";
        $res = mysqli_query($conn,$queryes);
        echo mysqli_error($conn);
        if($res == true){
            header("Location: edit_profile.php");
            
        }else echo mysqli_error($conn);
    }else echo $flag;


?>