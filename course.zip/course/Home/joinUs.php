<?php
    require_once("../configuration.php");
    $number = 3;
    $title = " - Join Us";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("title.php"); ?>
</head>
<body>
  <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  

    <!-- Main jumbotron for a primary marketing message or call to action -->
    
    <section style="background-image:url('img/4.jpg')">
        <div class="jumbotron transbox2">
            <div class="container" style="padding-top:10vh">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">JOIN US</h1>
            </div>
        </div>
    </section>
    <!-- section -->
    <section style="margin-bottom:8vh">
        <div class="container">
            <div class="col-md-12 order-md-1">
                <form class="needs-validation" novalidate action="insertdbmurid.php" method="post">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="firstName">Name</label>
                            <input type="text" class="form-control" id="firstName" placeholder="" value="" name="nama" required>
                            <div class="invalid-feedback">
                                Nama Masih kosong!.
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address" placeholder="1234 Main St" name="alamat" required>
                        <div class="invalid-feedback">
                            Alamat masih kosong!.
                        </div>
                    </div>

                    

                    <div class="row">
                        <div class="col-md-5 mb-3">
                            <label for="country">Level</label>
                            <select class="custom-select d-block w-100" id="jenjang" name="jenjang" required>
                            <option value="">Choose..</option>
                                <option value="SD">SD</option>
                                <option value="SMP">SMP</option>
                                <option value="SMP">SMA</option>

                            </select>
                            <div class="invalid-feedback">
                                Tolong pilih jenjang anda.
                            </div>
                        </div>

                        <div class="col-md-7 mb-3">
                            <label for="address">Phone</label>
                            <input type="number" class="form-control" id="phone" name="phone" placeholder="08293819219" required>
                            <div class="invalid-feedback">
                               Telepon Masih kosong !.
                            </div>
                        </div>

                    </div>
                    
                    <h4 class="mb-3">Type</h4>

                    <div class="d-block my-3">
                        <div class="custom-control custom-radio">
                            <input id="class"  type="radio" class="custom-control-input" name="tipe" value="K" checked required>
                            <label class="custom-control-label" for="class" >Class</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input id="private" type="radio" class="custom-control-input" name="tipe" value="P" required>
                            <label class="custom-control-label" for="private" >Private</label>
                        </div>
                    
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="cc-name">Hours</label>
                            <input type="text" class="form-control" id="hour" name="hour" placeholder="18:00,19:00" required>
                            <small class="text-muted"><i>(Gunakan tanda pemisah "," jika lebih dari satu hari ex : 18:00,19:00. Jika tidak maka dianggap jamnya sama. format 00:00)</i></small>
                            <div class="invalid-feedback">
                            Mohon di isi Jamnya!.
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="cc-number">Days</label>
                            <input type="text" class="form-control" id="day" name="day" placeholder="SENIN,SELASA" required>
                            <small class="text-muted"><i>(Gunakan tanda pemisah "," jika lebih dari satu hari ex : SENIN,SELASA. Jika tidak maka dianggap jamnya sama. format "SENIN", tulisan caps)</i></small>
                            <div class="invalid-feedback">
                            Mohon di isi harinya!.
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="cc-number">About (mata pelajaran, atau komen)</label>
                            <textarea name="comment" class="form-control" id="comment" name="comment" required></textarea>                          
                             <div class="invalid-feedback">
                                 Mohon di isi keterangan nya !
                            </div>
                        </div>
                    </div>
                    
                    <hr class="mb-4">
                    <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                </form>
            </div>
        </div>
    </section>
    <!-- end section -->


  <!-- footer -->
  <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<?php include("script.php");?>
<script src="main/form-validation.js"></script>