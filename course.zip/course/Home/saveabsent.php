<?php
    require_once("../configuration.php");
    date_default_timezone_set("Asia/Bangkok");
    $idmurid = $_POST['idmurid'];
    $jam =  date("H:i");
    $keterangan = $_POST['keterangan'];
    $idpengajar =$_POST['idpengajar'];
    $tanggal = date("Y-m-d H:i:s");
    $query = "INSERT INTO ABSEN VALUES('$idpengajar','$idmurid','$tanggal','$keterangan','$jam','-')";
    $res = mysqli_query($conn,$query);
    if($res==true){
        echo "berhasil";
    }


?>