<?php
    require_once("../configuration.php");
    $title  = " - Register";
    $salah = "";
    $error = "";
    if(isset($_GET['false'])){
        $salah = "salah";
        $fd = $_GET['false'];
        if($fd=="1"){
            $error = "Email sudah terdaftar";
        }else if($fd=="0"){
            $error = "Konfirm password dan password tidak sama";
        }else if($fd=="2"){
            $error = "Gambar hanya  jpg dan png saja";
        }else if($fd=="3"){
            $error = "Size gambar terlalu besar";
        }
    }
?>

<!doctype html>
<html lang="en">
  <head>
    <?php include("title.php")?>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      /* html,
        body {
        height: 100%;
        }

        body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
        }

        .form-signin {
        width: 100%;
        max-width: 330px;
        padding: 15px;
        margin: auto;
        }
        .form-signin .checkbox {
        font-weight: 400;
        }
        .form-signin .form-control {
        position: relative;
        box-sizing: border-box;
        height: auto;
        padding: 10px;
        font-size: 16px;
        }
        .form-signin .form-control:focus {
        z-index: 2;
        }
        .form-signin input[type="email"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }
        .form-signin input[type="password"] {
            margin-bottom: 10px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;    
        } */
        #form{
            margin-top:20vh;
            margin-bottom: 5vh;
        }
        a{
            color:red;
        }
        a:hover{
            text-decoration:none;
            font-weight:bold;
            color:red;
        }
        .mb-4:hover{
            cursor:pointer;
        }
        .warning{
            color:white;
            background:red;
            border-radius:4%;
            font-weight:bold;
            transition:0.2s;
            display:none;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>
  <body class="text-center">

    <nav class="navbar navbar-expand-md   fixed-top" >
        <button class="btn btn-warning btn-secondary my-2 my-sm-0" type="button" onclick="home()" style="margin-right:0.5vw">
            Home
        </button>
        <button class="btn btn-warning btn-secondary my-2 my-sm-0" type="button" onclick="login()">
            Login
        </button> 
        
    </nav>
        <section id="form">
            <div class="container">
                <div class="row">
                    <h1>  Register Teacher</h1>
                    <div class="col-12" style='margin-top:2vh'>
                            <hr>
                            <div class="warning" id="warning"><p><?=$error?></p></div>
                            <form class="needs-validation" novalidate action="insertdbpengajar.php" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="firstName">Name</label>
                                        <input type="text" class="form-control" id="firstName" placeholder="" value="" name="nama" required>
                                        <div class="invalid-feedback">
                                            Nama Masih kosong!.
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="address">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="1234@gmail.com" name="email" required>
                                    <div class="invalid-feedback">
                                       Email masih kosong.
                                    </div>
                                </div>

                                

                                <div class="row">
                                    <div class="col-md-5 mb-3">
                                        <label for="address">Password</label>
                                        <input type="password" class="form-control" id="passw" name="pass"  required>
                                        <div class="invalid-feedback">
                                        Password Masih kosong !.
                                        </div>
                                    </div>

                                    <div class="col-md-7 mb-3">
                                    <label for="address">Confirm Password</label>
                                        <input type="password" class="form-control" id="cpassw" name="cpass"  required>
                                        <div class="invalid-feedback">
                                        Konfirm Password Masih kosong !.
                                        </div>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="cc-number">Phone</label>
                                        <input type="number" class="form-control" id="phone" name="phone" placeholder="0892137123" required>
                                        <div class="invalid-feedback">
                                            Mohon di isi Teleponnya !
                                        </div>
                                    </div>

                                </div>
                                
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="cc-name">Instagram</label>
                                        <input type="text" class="form-control" id="instagram" name="instagram" placeholder="mantapu" >
                                        <small><i>(optional) jika di isi : isi tanpa tanda '@'</i></small>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="cc-number">Line</label>
                                        <input type="text" class="form-control" id="line" name="line" placeholder="mantapu" >
                                        <small><i>(optional)</i></small>
                                    </div>
                                   
                                    <div class="col-md-12 mb-3">
                                        <label for="cc-number">Photo</label>
                                        <input type="file" class="form-control" id="photo" name="photo" style='padding:5px' >
                                        <small><i>(optional)</i></small>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label for="cc-number">Motto</label>
                                        <textarea  class="form-control" id="motto" name="motto"></textarea>                          
                                        <small><i>(optional)</i></small>
                                    </div>
                                </div>
                                
                                <hr class="mb-4">
                                <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                            </form>
                    </div>
                </div>
            </div>
        </section>
</body>
</html>
<?php include("script.php");?>
<script src="main/form-validation.js"></script>
<script>
   
    var cek = "<?=$salah?>";
    if(cek=="salah"){
        document.getElementById("warning").style.display="block";
    }

    $("#loginmaster").click(function(){
        window.location.href= "../Master";
    });

    function shows() {
		var x = document.getElementById("inputPassword");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}

    function home(){
        window.location.href="index.php";
    }

    function login(){
        window.location.href = "login.php";
    }

    // function getisi(){
    //     var email = document.getElementById("inputEmail").value;
    //     var pass = document.getElementById("inputPassword").value;
    //     if(email !="" && pass !=""){
    //         $.ajax({
    //         method: "post",
    //         url: "checklogin.php",
    //         data: {
    //             email: email,
    //             pass :pass
    //         },
    //         success: function (data) {
    //               if(data == "0"){
    //                 
    //               }
    //         });
    //     }
    // }
</script>

