<?php
    require_once('../configuration.php');
    $tmp  = "";
    if(isset($_REQUEST["sub"])){
        $name = $_REQUEST['nama'];
        $alamat = $_REQUEST['alamat'];
        $phone = $_REQUEST['phone'];
        $tipe = $_REQUEST['tipe'];
        $jenjang = $_REQUEST['jenjang'];
        $jam = $_REQUEST['hour'];
        $days = $_REQUEST['day'];
        $about = $_REQUEST['comment'];
       
        date_default_timezone_set("Asia/Bangkok");
        $dt = new DateTime();
        
        $tanggal = $dt->format('Y-m-d H:i:s');
        $querys= "SELECT LPAD(COUNT(*)+1,3,0) AS JUMLAH FROM MURID";
        $res = mysqli_query($conn,$querys);
        foreach($res as $key=>$data){
          $tmp = "MU".$data['JUMLAH'];
        }
        $query = "INSERT INTO MURID VALUES ('$tmp','$name','$phone','$alamat','$about','$tipe','$tanggal','$days','$jam','$jenjang',2)";
        $res2 = mysqli_query($conn,$query);
        if($res2 == true){
            header("location:joinUs.php");
        }else{
            echo mysqli_error($conn);
        }
    }

?>