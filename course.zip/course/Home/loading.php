<?php 
    require_once("../configuration.php");
    
    $title = "";
    $id = $_GET['id'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <?php include("title.php"); ?>
 
</head>
<body>
   

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  
</body>
</html>
 <?php include("script.php");?>

<script>
var id="<?=$id?>";
  $.ajax({
	          async : false,
            method: "post",
            url: "email_confirm.php",
            data: {
                id:id,
               ctr:1
            },
            success: function (data) {
                  if(data == "berhasil"){
                    window.location.href = "confirmation.php?type=1";
                  }
            }
        });
</script>