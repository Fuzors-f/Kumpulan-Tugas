<?php
    require_once("../configuration.php");
    $jamsekarang = date("H:i");
    $idm = $_GET['idm'];
    $tp = $_GET['type'];
    $tmpid = substr($idm,0,2);
    $nama_m = "";
    $alamat_m = "";
    $phone_m = "";

    $qy = "";
    if($tmpid =="MU"){
        $qy = "SELECT * FROM MURID WHERE ID_MURID = '$idm'";
        $rs = mysqli_query($conn,$qy);
        foreach($rs as $key=>$data){
            $nama_m = $data['NAMA_MURID'];
            $alamat_m = $data['ALAMAT'];
            $phone_m = $data['TELEPON'];
        }
    }else{
        $qy = "SELECT * FROM KELAS WHERE ID_KELAS = '$idm'";
        $rs = mysqli_query($conn,$qy);
        foreach($rs as $key=>$data){
            $nama_m = "KELAS";
            $alamat_m = $data['ALAMAT_KELAS'];
            $phone_m = "-";
        }
    }

    if($tp=="M") echo "<div class='col-6 ' style='background-color:#0069D9;color:white; border-radius:2%;padding:5%'>
    "; else echo "<div class='col-6 ' style='background-color:#E0A800; color:black;border-radius:2%;padding:5%'>
    ";
?>

    <p>Name : <?=$nama_m?></p><br>
    <p>Address : <?=$alamat_m?></p><br>
    <p>Phone : <?=$phone_m?></p><br>
    <p>Absent Hour : <?=$jamsekarang?></p><br>
    <hr style="border:2px solid">
    <p>Masukan Keterangan : </p><input type="text" style="width:100%" name="" id="ket"><br>
    <button class="btn" style="background-color:#000080; color:white; margin-top:1vh;height:4vh; width:100%;font-size:13pt" onclick="absentsave()">Save</button>


</div>


<script>
    var idmurid = "<?=$idm?>";
    var idpengajar = "<?=$_SESSION['LOGIN']?>";

    function absentsave(){
        var keterangan = document.getElementById("ket").value;
        $.ajax({
            method:"post",
            url : "saveabsent.php",
            data: {
                idmurid :idmurid,
                idpengajar : idpengajar,
                keterangan :keterangan
            },
            success: function(data){
                if(data=="berhasil"){
                    closeabsent(idmurid);
                    alert("berhasil mengabsen");
                }
            }
        })
    }



</script>