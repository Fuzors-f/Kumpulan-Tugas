<?php
    require_once("../configuration.php");
   if(isset($_POST['sign'])){ //ini jika langsung dari login
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $query = "SELECT * FROM PENGAJAR WHERE STATUS <> 0";
    $rs = mysqli_query($conn,$query);
    foreach($rs as $key=>$data){
        if($data['PASSWORD'] == $pass && $data["EMAIL"]== $email){
            if($data['STATUS'] == 1){
                $_SESSION['LOGIN'] = $data['ID_PENGAJAR'];
                header("Location: index.php");
            }else{
                header("Location: pedning.php");
            }
        }else{
            header("Location: login.php?false");
        }
    }
   }

  
   if(isset($_POST['klogin'])){ //ini jika setelah forgot pasword 
       $pass = $_POST['cpass'];
       $konfirm = $_POST['pass'];
       $email = $_POST['email'];
       $status = -1;
       $id = "";
       $query1 ="SELECT * FROM PENGAJAR WHERE EMAIL = '$email' AND STATUS <> 0 ";
       $res1 = mysqli_query($conn,$query1);
       foreach($res1 as $key=>$data){
           $status = $data['STATUS'];
           $id = $data['ID_PENGAJAR'];
       }

       if($pass == $konfirm){
           $query2 = "UPDATE PENGAJAR SET PASSWORD = '$pass' WHERE ID_PENGAJAR = '$id'";
           $res2 = mysqli_query($conn,$query2);
           if($res2== true){
               if($status==1 ){
                    $_SESSION['LOGIN'] = $id;
                    header("Location: index.php");
               }else{
                    header("Location:pending.php");
               }    
           }
       }else{
            header("Location: changepasw.php?false");
       }
    }


    




?>