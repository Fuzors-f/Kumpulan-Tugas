<?php
    require_once("../configuration.php");
    $number = 2;
    $title = " - Content";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("title.php"); ?>
</head>
<body>
  <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  

    <!-- Main jumbotron for a primary marketing message or call to action -->
    
    <section style="background-image:url('img/3.jpg')">
        <div class="jumbotron transbox2">
            <div class="container" style="padding-top:10vh">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">CONTENT</h1>
                <p class="wow fadeInUp" data-wow-duration="2.5s">interesting and warmest content that we present to you</p>
            </div>
        </div>
    </section>
    
    <!-- section -->
    <section >
        <div class="container">
            <div class="row">
                <?php 
                    $query = "SELECT * FROM KONTEN WHERE STATUS = 1";
                    $res = mysqli_query($conn,$query);
                    foreach($res as $key=>$data){
                        $foto = "../Master/".$data['GAMBAR_KONTEN'];
                ?>
                    <div class="col-md-4 wow fadeInDown konten" data-wow-duration="1.6s" idkonten = "<?=$data['ID_KONTEN']?>">
                        <div class="card mb-4 shadow-sm">
                            <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="<?=$foto?>" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail">
                            <div class="card-body">
                                <h2><?=$data['NAMA_KONTEN']?></h2>
                                <p class="card-text"><?=$data['ISI_KONTEN']?></p>
                            </div>
                        </div>
                    </div>
                    <?php }?>
            </div>
        </div>
    </section>
    <!-- end section -->


  <!-- footer -->
  <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<?php include("script.php");?>
<script>
    var konten= document.getElementsByClassName("konten");
    for(i=0;i<konten.length;i++){
        konten[i].addEventListener("click", function (){
            var path = "conten_stuff.php?idkonten="+this.getAttribute('idkonten');
            window.location.href= path
        });
    }
</script>