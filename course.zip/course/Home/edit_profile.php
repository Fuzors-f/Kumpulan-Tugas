<?php
    require_once("../configuration.php");
    $number = 3;
    $title = " - Profile";
    $id = $_SESSION['LOGIN'];

    $salah = "";
    $error = "";
    if(isset($_GET['false'])){
        $salah = "salah";
        $fd = $_GET['false'];
        if($fd=="2"){
            $error = "Gambar hanya  jpg dan png saja";
        }else if($fd=="3"){
            $error = "Size gambar terlalu besar";
        }
    }

    $nama = "";
    $email = "";
    $phone = "";
    $line = "";
    $instagram = "";
    $foto = "";
    $motto = "";
    $pass = "";

    $query = "SELECT * FROM PENGAJAR WHERE ID_PENGAJAR = '$id'";
    $res = mysqli_query($conn,$query);
    foreach($res as $Key=>$data){
        $nama = $data['NAMA_PENGAJAR'];
        $email = $data['EMAIL'];
        $pass= $data['PASSWORD'];
        $phone = $data['TELEPON'];
        $line = $data['LINE'];
        $instagram = $data['INSTAGRAM'];
        $motto = $data['MOTTO'];
        $foto = $data['FOTO'];

    }
    $image = "";
    $potolama = "";
    if($foto != ""){
        $image = "../Master/".$foto;
        $potolama = $foto ;
    }else{
        $image = "img/avatar.png";
       $potolama = "";
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("title.php"); ?>
</head>
<style>
 #form{
            margin-top:20vh;
            margin-bottom: 5vh;
        }
        a{
            color:red;
        }
        a:hover{
            text-decoration:none;
            font-weight:bold;
            color:red;
        }
        .warning{
            color:white;
            background:red;
            border-radius:4%;
            font-weight:bold;
            transition:0.2s;
            display:none;
        }
</style>
<body>
  <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  

    <!-- Main jumbotron for a primary marketing message or call to action -->
    
    <section style="background-image:url('img/4.jpg')">
        <div class="jumbotron transbox2">
            <div class="container" style="padding-top:10vh">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">Edit Profil</h1>
            </div>
        </div>
    </section>
    <!-- section -->
    <section id="form">
            <div class="container">
                <div class="row">
                    <h1>  Edit Your Profile</h1>
                    <div class="col-12" style='margin-top:2vh'>
                            <hr>
                            <div class="warning" id="warning"><p><?=$error?></p></div>
                            <form class="needs-validation" novalidate action="updateprofilpengajar.php" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <input type="hidden" name="potolama" value="<?=$potolama?>" >
                                        <label for="cc-number">Photo</label><br>
                                        <img class="bd-placeholder-img rounded-circle" width="100" height="100" src="<?=$image?>">
                                        <input type="file"  id="photo" name="photo" style='margin-left:4vw;padding:5px' >
                                    </div>
                                    <hr>
                                    <div class="col-md-12 mb-3">
                                        <label for="firstName">Name</label>
                                        <input type="text" class="form-control" id="firstName" placeholder="" value="<?=$nama?>" name="nama" required>
                                        <div class="invalid-feedback">
                                            Nama Masih kosong!.
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="address">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="1234@gmail.com" name="email" value="<?=$email?>" required>
                                    <div class="invalid-feedback">
                                       Email masih kosong.
                                    </div>
                                </div>

                                

                                <div class="row">
                                    
                                    <div class="col-md-12 mb-3">
                                        <label for="cc-number">Phone</label>
                                        <input type="number" class="form-control" id="phone" name="phone" value="<?=$phone?>" placeholder="0892137123" required>
                                        <div class="invalid-feedback">
                                            Mohon di isi Teleponnya !
                                        </div>
                                    </div>

                                    <div class="col-md-10 mb-3">
                                        <label for="cc-number">Password</label>
                                        <input type="password" class="form-control" id="pass" name="pass"  value="<?=$pass?>" required>
                                        <div class="invalid-feedback">
                                            Mohon di isi Passwordnya !
                                        </div>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <div class="checkbox " style="margin-top:6vh">
                                            <label>
                                                <input type="checkbox"  onclick="shows()"> Show password
                                            </label>
                                        </div>
                                    </div>

                                </div>
                                
                                <hr>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="cc-name">Instagram</label>
                                        <input type="text" class="form-control" id="instagram" name="instagram" placeholder="mantapu" value="<?=$instagram?>">
                                        <small><i>(optional) jika di isi : isi tanpa tanda '@'</i></small>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="cc-number">Line</label>
                                        <input type="text" class="form-control" id="line" name="line" placeholder="mantapu" value="<?=$line?>">
                                        <small><i>(optional)</i></small>
                                    </div>
                                   
                                    

                                    <div class="col-md-12 mb-3">
                                        <label for="cc-number">Motto</label>
                                        <textarea  class="form-control" id="motto" name="motto" ><?=$motto?></textarea>                          
                                        <small><i>(optional)</i></small>
                                    </div>
                                </div>
                                
                                <hr class="mb-4">
                                <input class="btn btn-primary btn-lg btn-block " style="background-color:red; border:none" type="submit" name="sub" value="save">
                            </form>
                    </div>
                </div>
            </div>
    </section>
    <!-- end section -->


  <!-- footer -->
  <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<?php include("script.php");?>
<script src="main/form-validation.js"></script>
<script>
    function shows() {
		var x = document.getElementById("pass");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}

    var cek = "<?=$salah?>";
    if(cek=="salah"){
        document.getElementById("warning").style.display="block";
    }
</script>