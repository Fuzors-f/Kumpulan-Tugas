<?php
    require_once("../configuration.php");

    $emails = $_POST['emails'];
    $query = "UPDATE PENGAJAR SET STATUS = 2 WHERE EMAIL = '$emails'";
    $res = mysqli_query($conn,$query);
    if($res==true) echo "berhasil";
    else echo mysqli_query($conn);




?>