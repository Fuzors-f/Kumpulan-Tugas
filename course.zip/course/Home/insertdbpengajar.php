<?php
    require_once("../configuration.php");
    if(isset($_POST['sub'])){
        $nama = $_REQUEST['nama'];
        $email = $_REQUEST['email'];
        $pass = $_REQUEST['pass'];
        $cpass = $_REQUEST['cpass'];
        $phone = $_REQUEST['phone'];
        $line = "";
        $insta = "";
        $motto = "";
        $foto = "";
        $insta = $_REQUEST['instagram'];
        $line = $_REQUEST['line'];
        $motto = $_REQUEST['motto'];
        $imagefoto = "";

        if($pass == $cpass){
            $query = "SELECT * FROM PENGAJAR WHERE UPPER(EMAIL) = UPPER('$email') AND STATUS <>0";
            $res = mysqli_query($conn,$query);
            $total = mysqli_num_rows($res);
            if($total >0){
                header("Location: register.php?false=1");
            }else{
                $target_dir = "../Master/Image_pengajar/"; //<- ini folder tujuannya
                $target_file = $target_dir. basename($_FILES["photo"]["name"]); //murni mendapatkan namanya saja tanpa path nya 
                $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                $imagefoto = "Image_pengajar/".basename($_FILES["photo"]["name"]);
                $flag = false;
                if(basename($_FILES["photo"]["name"]) != ""){
                    if($file_type !="jpg" && $file_type !="png"){
                        header("Location: register.php?false=2");
                    } else if($_FILES["photo"]["size"] > 500000){
                        header("Location: register.php?false=3");
                    } else{
                        if(move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)){

                            $flag = true;
                        }
                    }
                }else{
                    $imagefoto = "";
                    $flag = true;
                }
                
                    if($flag==true){
                        $querys = "SELECT LPAD(COUNT(*)+1,3,0) AS JUMLAH FROM PENGAJAR";
                        $res = mysqli_query($conn,$querys);
                        $tmp  = "";
                        foreach($res as $key=>$data){
                             $tmp = "GR".$data['JUMLAH'];
                        }

                        $queryes = "INSERT INTO PENGAJAR VALUES ('$tmp', '$nama', '$email', '$pass', '$phone','$line','$insta','$imagefoto','$motto',-1)";
                        $res = mysqli_query($conn,$queryes);
                        if($res == true){
                            header("Location: loading.php?id=".$tmp);
                        }else echo mysqli_error($conn);
                    }else echo $flag;
                
            }
        }else{
            header("Location: register.php?false=0");
        }
    }



?>