
<!-- top nav -->
<section class="hdsection" style=" background-color:rgba(0,0,0,0.8); height:4vh;
  color:white;font-size:10pt;padding-top:0.5vh">
    <div class="container" >
      <div class="row">
          <div class="col-3">
            <p><i class="ion-ios-telephone-outline" style="padding-right:1vw"></i>085334742388 / 081357639963</p>
          </div>
          <div class="col-3">
            <p><i class="ion-ios-location-outline" style="padding-right:1vw"></i>Surabaya, Jawa Timur</p>
          </div>
          <div class="col-3">
            <p><i class="ion-ios-email-outline" style="padding-right:1vw"></i>course.orion@gmail.com</p>
          </div>
      </div>
    </div>
  </section>
  <!-- end top nav -->
 
<nav class="navbar navbar-expand-sm fixed-top navbar-dark bg-tr"  id="nav">
  <div class="container borderbtm" id="kotak">
  <a class="navbar-brand" href="index.php" id="navbrand"> <strong>ORION COURSE</strong></span></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarsExample03" >
    <ul class="navbar-nav ml-auto">
      <?php if($number ==0) echo "<li class='nav-item active underline'>"; else echo "<li class='nav-item underline'>"?>
        <a class="nav-link" href="index.php">Home </a>
      </li>
      <?php if($number ==1) echo "<li class='nav-item active underline'>"; else echo "<li class='nav-item underline'>"?>
        <a class="nav-link" href="team.php">Team</a>
      </li>
      <?php if($number ==2) echo "<li class='nav-item active underline'>"; else echo "<li class='nav-item underline'>"?>
        <a class="nav-link" href="content.php">Content</a>
      </li>
      <?php if($number ==3) echo "<li class='nav-item active underline'>"; else echo "<li class='nav-item underline'>"?>
        <a class="nav-link" href="joinUs.php">Join Us</a>
      </li>
      <li class="delimiter">|</li>
      <li class="nav-item dropdown underline" >
        <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Teacher</a>
        <div class="dropdown-menu" aria-labelledby="dropdown03">
          
          <?php 
              if(isset($_SESSION['LOGIN'])){
                $idguru = $_SESSION['LOGIN'];
                $queryguru = "SELECT * FROM PENGAJAR WHERE ID_PENGAJAR = '$idguru'";
                $hs = mysqli_query($conn,$queryguru);
                $nama = "";
                foreach($hs as $key=>$data){
                  $nama = $data['NAMA_PENGAJAR'];
                }
                echo "<a class='dropdown-item' href='dashboard_menu.php'>Hello, $nama</a>";
                echo "<a class='dropdown-item' href='edit_profile.php'>Your Profil</a>";
                echo "<a class='dropdown-item' href='sign_out.php'>Sign Out</a>";
              }else{
                echo "<a class='dropdown-item' href='login.php'>Sign In</a>";
                echo "<a class='dropdown-item' href='register.php'>Register</a>";
              }
          
          
          ?>
        </div>
      </li>
    </ul>
    
  </div>
  </div>
</nav>
