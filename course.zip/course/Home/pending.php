<?php
    require_once("../configuration.php");
    $title  = " - Login";
    
?>

<!doctype html>
<html lang="en">
  <head>
    <?php include("title.php")?>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      html,
        body {
        height: 100%;
        }

        body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
        }

        .form-signin {
        width: 100%;
        max-width: 330px;
        padding: 15px;
        margin: auto;
        }
        .form-signin .checkbox {
        font-weight: 400;
        }
        .form-signin .form-control {
        position: relative;
        box-sizing: border-box;
        height: auto;
        padding: 10px;
        font-size: 16px;
        }
        .form-signin .form-control:focus {
        z-index: 2;
        }
        .form-signin input[type="email"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }
        .form-signin input[type="password"] {
            margin-bottom: 10px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;    
        }

        a{
            color:red;
        }
        a:hover{
            text-decoration:none;
            font-weight:bold;
            color:red;
        }
        .mb-4:hover{
            cursor:pointer;
        }
        .warning{
            color:white;
            background:red;
            border-radius:4%;
            font-weight:bold;
            transition:0.2s;
            display:none;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>
  <body class="text-center">

    <nav class="navbar navbar-expand-md   fixed-top" >
        <button class="btn btn-warning btn-secondary my-2 my-sm-0" type="button" onclick="home()" style="margin-right:0.5vw">
            Home
        </button>
        <button class="btn btn-warning btn-secondary my-2 my-sm-0" type="button" onclick="register()">
            Register
        </button> 
        
    </nav>
    <div class="form-signin"  >
            <h1>Akun kamu sedang kami proses. Jika telah aktif kamu akan dikirimi email. Mohon bersabar ya :)</h1>
    </div>
</body>
</html>
<?php include("script.php");?>
<script>
   
   
    function home(){
        window.location.href="index.php";
    }

    function register(){
        window.location.href = "register.php";
    }


</script>

