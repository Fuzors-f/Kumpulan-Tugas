<?php
    require_once("../configuration.php");
    $number = 1;
    $title = " - Team";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("title.php"); ?>
</head>
<body>
  <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  

    <!-- Main jumbotron for a primary marketing message or call to action -->
    
    <section style="background-image:url('img/2.jpg')">
        <div class="jumbotron transbox2">
            <div class="container" style="padding-top:10vh">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">TEAM</h1>
                <p class="wow fadeInUp" data-wow-duration="2.5s">This is our information about our team</p>
            </div>
        </div>
    </section>
    
    <!-- section -->
    <section >
        <div class="container">
            <div class="row">
                <?php 
                    $query = "SELECT * FROM PENGAJAR WHERE STATUS = 1";
                    $res = mysqli_query($conn,$query);

                    foreach($res as $key=>$data){
                        $foto =  "../Master/".$data['FOTO'];
                        $pathig = "https://www.instagram.com/".$data['INSTAGRAM'];
                ?>

                    <div class="col-md-3 col-sm-4 pd wow rollIn" wow-data-duration="1.2s">
                        <div class="team-thumb2">
                            <img src="<?=$foto?>" class="img-responsive" alt="">

                            <div class="team-info team-thumb-up">
                                <hr style="border:2px solid red">
                                <h2><?=$data['NAMA_PENGAJAR']?></h2>
                                <p><i><?=$data['MOTTO']?></i></p>
                                <p><i class="fa fa-instagram"></i><a class="instahref" href="<?=$pathig?>" target="_blank">@<?=$data['INSTAGRAM']?></a></p>
                                <p>Line : <a style="padding-left:0.4vw" ><?=$data['LINE']?></a></p>
                                <hr style="border:2px solid red">
                            </div>
                        </div>
                    </div>

                    <?php }?>
                    
            </div>
        </div>
    </section>
    <!-- end section -->


  <!-- footer -->
  <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<?php include("script.php");?>