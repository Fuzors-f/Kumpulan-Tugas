<?php
    require_once("../configuration.php");
    $number = 3;
    $title = " - Your Dashboard";
    $id = $_SESSION['LOGIN'];

    date_default_timezone_set("Asia/Bangkok");
    $hari = array("SENIN", "SELASA", "RABU", "KAMIS", "JUMAT", "SABTU", "MINGGU");
    $hari2 = array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");
    $hariini = date("l");

    
    $inttmp = -1;
    for($i=0;$i<7;$i++){
        if($hariini == $hari2[$i]) $inttmp = $i;
    }
    


    $query = "SELECT * FROM JADWAL WHERE ID_PENGAJAR = '$id' AND STATUS = 1";
    $jam = [];
    $namamurid = [];
    $tipe = [];
    $alamat = [];
    $ctr = 0;
    $telepon = [];
    $idmurids = [];
    $res = mysqli_query($conn,$query);
    foreach($res as $Key=>$data){
        $idmurid =$data['ID_MURID'];
        if($hari[$inttmp] == $data['HARI'] && substr($idmurid,0,2)== "MU"){
            $jam[$ctr] = $data['JAM'];
            $idmurids[$ctr] = $data['ID_MURID'];
            $querys = "SELECT * FROM MURID WHERE ID_MURID = '$idmurid' AND STATUS = 1";
            $res2  = mysqli_query($conn,$querys);
            foreach($res2 as $ky=>$dt){
                $namamurid[$ctr]= $dt['NAMA_MURID'];
                $alamat[$ctr] = $dt['ALAMAT'];
                $telepon[$ctr] = $dt['TELEPON'];
                $tipe[$ctr] = "M";
            }
            $ctr++;
        }
    }
    $querykelas = "SELECT * FROM KELAS_PENGAJAR WHERE ID_PENGAJAR = '$id' AND STATUS = 1";
    $reskelas = mysqli_query($conn,$querykelas);
    foreach($reskelas as $key=>$data){
        $idkelas = $data['ID_KELAS'];
        $quer = "SELECT * FROM KELAS WHERE ID_KELAS = '$idkelas' AND STATUS =1 AND HARI = '$hari[$inttmp]'";
        $rr = mysqli_query($conn,$quer);
        foreach($rr as $ky=>$dt){
                $idmurids[$ctr] = $data['ID_KELAS'];
                $jam[$ctr] = $dt['JAM'];
                $namamurid[$ctr] = "KELAS";
                $telepon[$ctr] = "-";
                $alamat[$ctr] = $dt['ALAMAT_KELAS'];
                $tipe[$ctr] = "K";
                $ctr++;
           
        }
    }
   

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("title.php"); ?>
</head>
<style>
    #tbPenjadwalan {
        transition : 2s;
        display :none;
    }

    
    /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  padding-left:45%;
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}


/* Add Animation */
.modal{  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 20vh;
  right: 10vw;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal{
      padding-left:0;
  }
}
</style>
<body>
  <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  

    <!-- Main jumbotron for a primary marketing message or call to action -->
    
    <section style="background-image:url('img/4.jpg')">
        <div class="jumbotron transbox2">
            <div class="container" style="padding-top:10vh">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">Hello, <?=$nama?></h1>
            </div>
        </div>
    </section>
    <!-- section -->
    <section style="margin-bottom:2vh">
        <div class="container">
            <div class="row">
                    <div class="col-12">
                        <h1 style="color:gray">Your Schedule Today</h1>
                    </div>
            </div>
            <hr style="border: 0.5px solid gray">
            <div class="row">
                <div class="col-12">
                    
                    <?php
                    
                        for($i=0;$i<$ctr;$i++){
                            if($tipe[$i]=="M")echo "<button class='btn  btn-primary bta wow fadeInDown' idmurid='".$idmurids[$i]."' onclick='modalopen(\"$idmurids[$i]\",\"$tipe[$i]\")'  data-wow-duration='3s' style='font-size:16pt'>"; else echo "<button class='btn btn-warning bta wow fadeInDown' idmurid='".$idmurids[$i]."' onclick='modalopen(\"$idmurids[$i]\",\"$tipe[$i]\")'  data-wow-duration='3s' style='font-size:16pt'>"
                    ?>
                            
                                <div class="row">
                                    <div class="col-12 text-center"><p><h1><?=$namamurid[$i]?></h1><?=$jam[$i]?></p></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-12"><p><h1><?=$alamat[$i]."(".$telepon[$i].")"?></h1></p></div>
                                </div>
                            
                            </button>
                    <?php
                        }

                        if($ctr==0) echo "<p class='text-center'>Kamu belum memiliki jadwal </p>"
                    
                    ?>  
                        

                </div>
            </div>
        </div>
    </section>
    <!-- end section -->
     <!-- The Modal -->
     <div id="myModal" class="modal">
                <span class="close">&times;</span>
                <div class="container " style="padding-top:18vh;">
                    <div class="row " id="mdl">
                        
                    </div>
                </div>
                <div id="caption"></div>
    </div>

    <!-- section -->
    <section>
        <div class="container">
             <hr style="border: 0.5px solid gray">
            <div class="row">
                <div class="col-12 text-center">
                    <button class="btn btn-warning wow fadeInDown" data-wow-duration="2s" onclick="openpenjadwalan()" style="background:gray;width:100%;margin-bottom:3vh;height:10vh; font-size:20pt;border:none; color:white"><p><h1>See full schedule</h1></p></button>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div id="tbPenjadwalan"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- end section -->



  <!-- footer -->
  <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<?php include("script.php");?>
<script>
    var flag = false;

    function openpenjadwalan(){
        if(flag==false){
            flag = true;
            document.getElementById("tbPenjadwalan").style.display ="block";
        }else{
            flag = false;
            document.getElementById("tbPenjadwalan").style.display ="none";

        }
    }
    $("#tbPenjadwalan").load("tablejadwal.php");

    var modal = document.getElementById("myModal");

    // Get the image and insert it inside the modal 
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    
    function modalopen(a,b){
         var path = "modalabsent.php?idm="+a+"&type="+b;
        $("#mdl").load(path);
        modal.style.display = "block";
    }

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() { 
        modal.style.display = "none";
    } 

     // Get the <span> element that closes the modal
     var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() { 
        modal.style.display = "none";
    } 


    var bta = document.getElementsByClassName("bta");

    function closeabsent(a){
        for(i=0;i<bta.length;i++){
            var tmp= bta[i].getAttribute("idmurid");
            if(tmp == a){
                modal.style.display = "none";
                bta[i].style.display="none";
            }
        }
    }
</script>