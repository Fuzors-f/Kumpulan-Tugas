<?php
    require_once("../configuration.php");
    $number = 2;
    $title = " - Content";
    $idkonten = $_GET['idkonten'];
    $query = "SELECT * FROM KONTEN WHERE ID_KONTEN = '$idkonten'";  
    $res = mysqli_query($conn,$query);
    $judul = "";
    $gambar = "";
    $isi = "";

    foreach($res as $key=>$data){
        $gambar = $data['GAMBAR_KONTEN'];
    }
    $path ="";
    if($gambar != ""){
        $random = Intval(rand(0,3));
        if($random==0){
            $path = "kontens/stuff1.php?idkn=".$idkonten;
        }else if($random == 1){
            $path = "kontens/stuff2.php?idkn=".$idkonten;
        }else{
            $path = "kontens/stuff3.php?idkn=".$idkonten;
        }
       
    }else{
        $path = "kontens/no-image.php?idkn=".$idkonten;
    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("title.php"); ?>
</head>
<body>
  <!-- header -->
   <?php include("header.php"); ?> 
  <!-- -- -->

  <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
  

    <!-- Main jumbotron for a primary marketing message or call to action -->
    
    <section style="background-image:url('img/3.jpg')">
        <div class="jumbotron transbox2">
            <div class="container" style="padding-top:10vh">
                <h1 class="display-3 wow fadeInDown" data-wow-duration="2s" style="font-weight:bold">CONTENT</h1>
                <p class="wow fadeInUp" data-wow-duration="2.5s">interesting and warmest content that we present to you</p>
                <p><a class="btn btn-primary btn-md wow fadeInUp" data-wow-duration = "2.7s" style="background:red;border:none " href="content.php" role="button">< Back to Content Page</a></p>
            </div>
        </div>
    </section>
    
    <!-- section -->
    <div id="isi">

    </div>
    <!-- end section -->


  <!-- footer -->
  <?php include("footer.php"); ?> 
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

</body>
</html>
<?php include("script.php");?>
<script>
    var konten= document.getElementsByClassName("konten");
    for(i=0;i<konten.length;i++){
        konten[i].addEventListener("click", function (){
            var path = "conten_stuff.php?idkonten="+this.getAttribute('idkonten');
            window.location.href= path
        });
    }
    var path = "<?=$path?>";
    $("#isi").load(path);
</script>