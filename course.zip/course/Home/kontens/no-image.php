<?php 
require_once("../../configuration.php");
$idkonten = $_GET['idkn'];
$query = "SELECT * FROM KONTEN WHERE ID_KONTEN = '$idkonten'";  
$res = mysqli_query($conn,$query);
$judul = "";
$gambar = "";
$isi = "";

foreach($res as $key=>$data){
    $gambar = $data['GAMBAR_KONTEN'];
    $judul = $data['NAMA_KONTEN'];
    $isi = $data['ISI_KONTEN'];
}

$gambar = "../Master/".$gambar;


?>
<section>
    <div class="container" style="margin-bottom:5vh">
        <div class="row ">
            <div class="col-6 text-center wow fadeInUp" data-wow-duration="2.5s"><img src="<?=$gambar?>" alt="" class="img-fluid"></div>
            
       
            <div class="col-6 wow fadeInUp" data-wow-duration="2.5s" >
                <h1><?=$judul?></h1>
                <hr style="border:2px solid red">
                <p><?=$isi?></p>
            </div>
        </div>
    </div>
</section>
<?php 
require_once("../../configuration.php");
$idkonten = $_GET['idkn'];
$query = "SELECT * FROM KONTEN WHERE ID_KONTEN = '$idkonten'";  
$res = mysqli_query($conn,$query);
$judul = "";
$gambar = "";
$isi = "";

foreach($res as $key=>$data){
    $gambar = $data['GAMBAR_KONTEN'];
    $judul = $data['NAMA_KONTEN'];
    $isi = $data['ISI_KONTEN'];
}

$gambar = "../Master/".$gambar;


?>
<section>
    <div class="container" style="margin-bottom:5vh">
        <div class="row text-center">
            <div class="col-12 text-center wow fadeInUp" data-wow-duration="2.5s"><h1><?=$judul?></h1></div>
            
        </div>
        <hr style="border:2px solid orange">
        <div class="row">
            <div class="col-12 text-center wow fadeInUp" data-wow-duration="2.5s">
                <p><?=$isi?></p>
            </div>
        </div>
    </div>
</section>