<?php require_once("../configuration.php");
    $id= $_GET['id'];
    $numbers = 1;
    $tmpid = "";
    $flag =0;
    $pos = strpos($id, "@");
    if($pos== true){
        $tmd = explode("@",$id);
        $id = $tmd[0];
        $flag = 1;
    }
    $query = "SELECT * FROM MURID WHERE ID_MURID= '$id'";
    $result= mysqli_query($conn,$query);
    $nama = "";
    $alamat = "";
    $tlp = "";
    $keterangan ="";
    $hari = "";
    $jam = "";
    $tipe ="";
    $header ="";
    $jenjang = "";
    foreach($result as $key=>$data){
        $nama = $data['NAMA_MURID'];
        $tlp = $data['TELEPON'];
        $alamat=$data['ALAMAT'];
        $hari = $data['HARI'];
        $jam = $data['JAM'];
        $keterangan = $data['KETERANGAN'];
        $tipe = $data['JENIS'];
        $jenjang = $data['JENJANG'];
    }
    if($tipe=="K") $header="Class";
        else $header="Privat Teacher";

?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php");?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />

</head>
<style>
@media (max-width: 768px) {
    #btn1{
        margin-top:8vh;
       width:10vw;
        margin-right: 60vw;
    }

    #btn2{
      margin-top:8vh;
      float:left;
      width:10vw;
    }
    .grid{
        display:none;
    }

    .btnWarning{
        font-size:12pt;
    }
    .btnPros{
        font-size:12pt;
    }
}

</style>
<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                <a style="font-size:18pt;" href="dashboard_murid.php"> << Student </a>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Accept</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row  table-full-width table-responsive">
                                        <table class="table">
                                          <thead><th colspan="2">Please check</thead>
                                            <tbody>
                                                <tr>
                                                    <td>Name</td>
                                                    <td> : <?=$nama?></td>
                                                </tr>
                                                <tr>
                                                    <td>Address</td>
                                                    <td> : <?=$alamat?></td>
                                                </tr>
                                                <tr>
                                                    <td>Phone</td>
                                                    <td> : <?=$tlp?></td>
                                                </tr>
                                                <tr>
                                                    <td>About</td>
                                                    <td> : <?=$keterangan?></td>
                                                </tr>
                                                <tr>
                                                    <td>Days</td>
                                                    <td> : <?=$hari?></td>
                                                </tr>
                                                <tr>
                                                    <td>Hours</td>
                                                    <td> : <?=$jam?></td>
                                                </tr>
                                                <tr>
                                                    <td>Type</td>
                                                    <td> : <?php if($tipe=="K") echo "Kelas"; else echo "Privat";?></td>
                                                </tr>
                                                <tr>
                                                    <td>Level</td>
                                                    <td> : <?=$jenjang?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-3 col-sm-6" > Choose <?=$header?> : </div> 
                                             <div id="myBtnContainer" style="padding-left:2vw;">
                                        <?php 
                                            if($tipe == "K"){
                                                $idkelas = [];
                                                $namakelas = [];
                                                $ctr = 0;
                                                $ctrx= 0;
                                                $tmz = [];
                                                $haritmp = explode(",",$hari);
                                                for($i= 0; $i<count($haritmp); $i++){
                                                    $que = "SELECT * FROM KELAS WHERE HARI = UPPER('$haritmp[$i]') AND STATUS = 1";
                                                    $res= mysqli_query($conn,$que);
                                                    foreach($res as $key=>$data){
                                                        $idkelas[$ctr] = $data['ID_KELAS'];
                                                        $namakelas[$ctr] = $data['ALAMAT_KELAS']." - hari:  ".$data['HARI']." , Jam: ".$data['JAM'];
                                                        $ctr++;
                                                    }
                                                }
                                                
                                                if($flag==1){
                                                    $quwer = "SELECT * FROM JADWAL WHERE ID_MURID = '$id' AND STATUS = 1";
                                                    $rs =mysqli_query($conn,$quwer);
                                                    foreach ($rs as $key=>$data){
                                                        $tmz[$ctrx] = $data['ID_PENGAJAR'];
                                                        $ctrx++;
                                                    }
                                                }

                                        
                                           
                                        ?>

                                        
                                            <?php  for($i=0;$i<$ctr; $i++){ 
                                                if($flag == 1){
                                                    $check = false;
                                                    for($j=0;$j<$ctrx;$j++){
                                                        if($tmz[$j]== $idkelas[$i]){
                                                            $check = true;
                                                        }
                                                    }

                                                    if($check== true){
                                                        ?>
                                                        <button class="btn actives" value="<?=$idkelas[$i]?>"><?=$namakelas[$i]?></button>
                                                        <?php
                                                    }else{
                                                        ?>
                                                         <button class="btn " value="<?=$idkelas[$i]?>"><?=$namakelas[$i]?></button>
            
                                                        <?php
                                                     }
                                                    
                                                }
                                                else if($flag==0 ){
                                                   if($i==0){

                                                   ?>
                                           <button class="btn actives" value="<?=$idkelas[$i]?>"><?=$namakelas[$i]?></button>

                                                    <?php
                                                }else{
                                                    ?>

                                            <button class="btn " value="<?=$idkelas[$i]?>"><?=$namakelas[$i]?></button>

                                                <?php
                                                  }
                                                ?>
                                            <?php }
                                            }   ?>
                                       

                                     <?php } else {
                                            $querys = "SELECT * FROM PENGAJAR WHERE STATUS = 1";
                                            $res = mysqli_query($conn,$querys);
                                            $ctr = 0;
                                            $tmid = "";
                                            if($flag == 1){
                                                $qw = "SELECT * FROM JADWAL WHERE ID_MURID = '$id' AND STATUS = 1";
                                                $rs = mysqli_query($conn,$qw);
                                                foreach($rs as $key=>$data){
                                                    $tmid = $data['ID_PENGAJAR'];
                                                }
                                            }
                                            foreach($res as $Key=>$data){

                                                if($tmid  == $data["ID_PENGAJAR"]){
                                            ?>
                                                <button class="btn actives" value="<?=$data["ID_PENGAJAR"]?>"><?=$data["NAMA_PENGAJAR"]?></button>

                                            <?php
                                                }
                                                else if($ctr==0 && $flag != 1){
                                                    ?>
                                         <button class="btn actives" value="<?=$data["ID_PENGAJAR"]?>"><?=$data["NAMA_PENGAJAR"]?></button>

                                    <?php
                                                }else{
                                                    ?>
                                         <button class="btn " value="<?=$data["ID_PENGAJAR"]?>"><?=$data["NAMA_PENGAJAR"]?></button>

                                    <?php
                                                
                                                }
                                                $ctr++;
                                            }
                                         ?>  
                                     <?php }?>
                                         </div>
                                    </div>  
                                    <hr class="grid">
                                    <div class ="row" style="margin-top:-5vh; padding-top:5%;">
                                           
                                       <?php if ($flag==0){
                                                echo "<div class='col-md-6' id='btn1'><input type='button' onclick='controller(0)' class='btnWarning pull-left' value='Delete' ></div>";
                                                echo "<div class='col-md-6' id = 'btn2'><input type='button'  onclick='controller(1)' class='btnPros pull-right' value='Save'></div>";
                                            }else {
                                                echo "<div class='col-md-6' id='btn1'><input type='button' onclick='controller(-1)' class='btnWarning pull-left' value='Delete' ></div>";
                                                echo "<div class='col-md-6' id = 'btn2'><input type='button'  onclick='controller(2)' class='btnPros pull-right' value='Save'></div>";
                                            } 
                                       
                                       
                                       ?>
                                    </div> 
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>



                   
                    
                </div>
            </div>
            <!-- end content1 -->
            
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>

<script>
   
    var id = "<?=$id?>";
    var tipe = "<?=$tipe?>";
    var hari = "<?=$hari?>";
    var jam = "<?=$jam?>";
    var btnContainer = document.getElementById("myBtnContainer");
   var btns = btnContainer.getElementsByClassName("btn");
    var tipe  = "<?=$tipe?>";
   for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
           if(tipe == "K"){
                
                this.classList.toggle("actives");
           } else{
                var current = btnContainer.getElementsByClassName(" actives");
                current[0].className = current[0].className.replace(" actives", "");
                this.className += " actives";
           }
        });
    }

    function controller(i){
            var idx = btnContainer.getElementsByClassName(" actives");
            var bol = true;
            var jx = i;
            if(idx.length<1 && i>0) bol = false;
            if(bol==true){
                var con = confirm("Apakah anda Yakin ?");
                if(con==true) {
                    var tmpid = "";
                    if(tipe == "K"){
                        for(i=0; i<idx.length-1; i++){
                           tmpid = tmpid+idx[i].value+",";
                        }
                        tmpid = tmpid+idx[idx.length-1].value;
                    }else{
                        tmpid = idx[0].value;
                    }
                    $.ajax({
                        method: "post",
                        url: "master_murid/controller.php",
                        data: {
                            id:id,//id dari murid
                            tmpid:tmpid, //id dari pengajar atau kelas
                            tipe:tipe, //tipe kelas atau privat
                            hari : hari, //hari 
                            jam :jam , //jamnya
                            controll :jx
                        },
                        success: function (data) {
                            if(data=="success"){
                                window.location.href = "dashboard_murid.php";
                            }
                        }
                    });
                }           
            }else{
                notif('top','center');
            }
    }



    function notif (from,align) {
        color = 4;

        $.notify({
            icon: "nc-icon nc-bell-55",
            message: "Mohon dipilih dahulu kelasnya !"

        }, {
            type: type[color],
            timer: 8000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    

</script>