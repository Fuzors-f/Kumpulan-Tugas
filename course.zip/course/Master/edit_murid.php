<?php require_once("../configuration.php");
    $id= $_GET['id'];
    $tmpid = "";
    $flag =0;
    $numbers = 1;
    $pos = strpos($id, "@");
    if($pos== true){
        $tmd = explode("@",$id);
        $id = $tmd[0];
        $flag = 1;
    }
    $query = "SELECT * FROM MURID WHERE ID_MURID= '$id'";
    $result= mysqli_query($conn,$query);
    $nama = "";
    $alamat = "";
    $tlp = "";
    $keterangan ="";
    $hari = "";
    $jam = "";
    $tipe ="";
    $header ="";
    $jenjang = "";
    $status = -1;
    foreach($result as $key=>$data){
        $nama = $data['NAMA_MURID'];
        $tlp = $data['TELEPON'];
        $alamat=$data['ALAMAT'];
        $hari = $data['HARI'];
        $jam = $data['JAM'];
        $keterangan = $data['KETERANGAN'];
        $tipe = $data['JENIS'];
        $jenjang = $data["JENJANG"];
        $status = $data['STATUS'];
    }
   

?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php"); ?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />

</head>
<style>
/*the container must be positioned relative:*/
.custom-select {
  position: relative;
  font-family: Arial;
}

.custom-select:hover{
    cursor:pointer;
}

.custom-select select {
  display: none; /*hide original SELECT element:*/
}

.select-selected {
  background-color: DodgerBlue;
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
}

/*style items (options):*/
.select-items {
  position: absolute;
  background-color: DodgerBlue;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}

/*hide the items when the select box is closed:*/
.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}
</style>
<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                <a style="font-size:18pt;" href="dashboard_murid.php"> << Student </a>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Edit Student</h4>
                                </div>
                                <div class="card-body">
                                   
                                        <div class="row">
                                            <div class="col-md-3 px-1">
                                                <div class="form-group">
                                                    <label>Name</label>
                                                    <input type="text" class="form-control" id="nama" placeholder="Name" value="<?=$nama?>">
                                                </div>
                                            </div>
                                            <div class="col-md-4 pl-1">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Phone</label>
                                                    <input type="number" id="phone" class="form-control" placeholder="08128373999" value =<?=$tlp?>>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 pr-1">
                                                <div class="form-group">
                                                    <label>Hour<span style="padding-left:1vw;font-size:8pt;font-style:italic;">(jika lebih dari satu  maka beri ',' sebagai pemisah, jika tidak dianggap jam sama)</span> </label>
                                                    <input type="text" id="jam" class="form-control" placeholder="18:00,19:00" value="<?=$jam?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6 pl-1">
                                                <div class="form-group">
                                                    <label>Days <span style="padding-left:1vw;font-size:8pt;font-style:italic;">(jika lebih dari satu hari maka beri ',' sebagai pemisah)</span></label>
                                                    <input type="text" id="hari" class="form-control" placeholder="SENIN,SELASA,.." value="<?=$hari?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Address</label>
                                                    <input type="text" id="alamat" class="form-control" placeholder="Home Address" value="<?=$alamat?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 pr-1">
                                                <div class="form-group">
                                                    <label>Type</label>
                                                    <div id="myBtnContainer">
                                                    <?php 
                                                        
                                                        if($tipe =="P"){
                                                            
                                                           echo "<button class='btn actives' onclick='changetype(1)'> Private</button>";   
                                                        }else{
                                                            echo "<button class='btn'  onclick='changetype(1)'> Private</button>";   
                                                        }

                                                        if($tipe =="K"){
                                                            echo "<button class='btn actives' onclick='changetype(2)'> Class</button>";   
                                                        }else{
                                                             echo "<button class='btn' onclick='changetype(2)'> Class</button>";   
                                                        }
                                                    
                                                    ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 px-1">
                                                <div class="form-group">
                                                    <label>Level</label>
                                                    <div  >
                                                        <select class="custom-select" style="width:200px;" id="selectlev">
                                                            <?php 
                                                                $selection = array("TK","SD","SMP","SMA");
                                                                for($i=0;$i<count($selection);$i++){
                                                                    if($jenjang == $selection[$i]){
                                                                        echo "<option value='$selection[$i]' selected>".$selection[$i]."</option>";
                                                                    }else{
                                                                        echo "<option value='$selection[$i]'>".$selection[$i]."</option>";
                                                                    }
                                                                }
                                                            
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>About</label>
                                                    <input type="textarea" id="about" rows="4" cols="80" class="form-control" placeholder="Here can be your description" value="<?=$keterangan?>">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-info btn-fill pull-right" onclick="submits()">Update Profile</button>
                                        <div class="clearfix"></div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>



                   
                    
                </div>
            </div>
            <!-- end content1 -->
            
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>

<script>
   
    var id = "<?=$id?>";
    var tipe = "<?=$tipe?>";
    var hari = "<?=$hari?>";
    var status = parseInt("<?=$status?>");
    var jam = "<?=$jam?>";
    var btnContainer = document.getElementById("myBtnContainer");
    var btns = btnContainer.getElementsByClassName("btn");
    var tipe  = "<?=$tipe?>";
    var flag = parseInt("<?=$flag?>");
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
            var current = btnContainer.getElementsByClassName("actives");
            current[0].className = current[0].className.replace(" actives", "");
            this.className += " actives";
        });
    }


    function notif (from,align,pesan) {
        color = 4;

        $.notify({
            icon: "nc-icon nc-bell-55",
            message: pesan

        }, {
            type: type[color],
            timer: 8000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    
    function changetype(type){
        if(type==1){
            tipe = "P";
        }else{
            tipe = "K";
        }
    }

    function submits(){
        var phone = document.getElementById("phone").value;
        var nama = document.getElementById("nama").value;
        var alamat = document.getElementById("alamat").value;
        var about = document.getElementById("about").value;
        var e = document.getElementById("selectlev");
        var jenjang = e.options[e.selectedIndex].value;
        var hari = document.getElementById("hari").value;
        var jam = document.getElementById("jam").value;
        
        if(phone != ""){
            if(nama != ""){
                if(alamat != ""){
                    if(about != ""){
                        if(hari != ""){
                            if(jam != ""){
                               if(phone.length <=13){
                                $.ajax({
                                    method: "post",
                                    url: "master_murid/update.php",
                                    data: {
                                        id:id,//id dari murid
                                        nama:nama, //nama
                                        alamat:alamat, //alamat
                                        hari : hari, //hari 
                                        jam :jam , //jamnya
                                        tipe:tipe,
                                        phone :phone,
                                        about:about,
                                        jenjang : jenjang,
                                        status :status
                                    },
                                    success: function (data) {
                                        if(data=="success1"){
                                                var path  = "accept_murid.php?id="+id;
                                                window.location.href = path;
                                        }else{
                                                
                                                var path  = "accept_murid.php?id="+id+"@";
                                                window.location.href = path;
                                        }
                                        
                                    }
                                });
                               }else{
                                notif('top','center',"Format no telepon salah atau lebih!");
                               }
                            }else{
                                notif('top','center', "Jam Les tidak boleh kosong!");
                            }
                        }else{
                            notif('top','center',"Hari Les tidak boleh kosong!");
                        }
                    }else{
                        notif('top','center',"Mohon di isi terlebih dahulu About/Keterangan les !");
                    }
                }else{
                    notif('top','center',"Alamat tidak boleh kosong!");
                }
            }else{
                notif('top','center', "Nama tidak boleh kosong!");
            }
        }else{
            notif('top','center',"No telepon tidak boleh kosong!");
        }




    }


    var x, i, j, l, ll, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
l = x.length;
for (i = 0; i < l; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  ll = selElmnt.length;
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < ll; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h, sl, yl;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        sl = s.length;
        h = this.parentNode.previousSibling;
        for (i = 0; i < sl; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            yl = y.length;
            for (k = 0; k < yl; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, xl, yl, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  xl = x.length;
  yl = y.length;
  for (i = 0; i < yl; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < xl; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);
</script>