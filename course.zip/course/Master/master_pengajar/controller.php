<?php
require_once("../../configuration.php");
$id = $_REQUEST['id'];
$ctr = $_REQUEST['ctr'];

if($ctr==1){
    $query = "UPDATE PENGAJAR SET STATUS =1 WHERE ID_PENGAJAR = '$id'";
    mysqli_query($conn,$query);
} else if($ctr==2){
    $flag = false;
    $query1 = "SELECT * FROM JADWAL WHERE ID_PENGAJAR = '$id' AND STATUS = 1";
    $rs1 = mysqli_query($conn,$query1);
    $count = mysqli_num_rows($rs1);
    if($count>0) $flag = true;
    $query2 = "SELECT * FROM KELAS_PENGAJAR WHERE ID_PENGAJAR = '$id' AND STATUS=1";
    $rs2 = mysqli_query($conn,$query2);
    $count2 = mysqli_num_rows($rs2);
    if($count2>0) $flag = true;
    if($flag == true){
        echo "gagal";
    }else{
        $query3 = "UPDATE PENGAJAR SET STATUS =0 WHERE ID_PENGAJAR = '$id'";
        mysqli_query($conn,$query3);
        echo "success";
    }
   
} else if($ctr==3){
    $email = $_REQUEST['email'];
    $pasw = $_REQUEST['pasw'];
    $line = $_REQUEST['line'];
    $instagram = $_REQUEST['instagram'];
    $nama = $_REQUEST['nama'];
    $moto = $_REQUEST['moto'];
    $phone = $_REQUEST['phone'];

    $query = "UPDATE `pengajar` SET `NAMA_PENGAJAR`='$nama',`EMAIL`='$email',`PASSWORD`='$pasw',`TELEPON`='$phone',`LINE`='$line',`INSTAGRAM`='$instagram',`MOTTO`='$moto' WHERE ID_PENGAJAR='$id'";
    $rs = mysqli_query($conn,$query);
    if($rs == true){
        echo "success";
    }
}
?>