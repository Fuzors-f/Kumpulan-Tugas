<?php 
	require_once("../../mailer2/class.phpmailer.php");
	require_once("../../configuration.php");


	$id = $_REQUEST['id'];
	$query = "SELECT * FROM PENGAJAR WHERE ID_PENGAJAR = '$id'";
	$var = mysqli_query($conn,$query);
	$nama = "";
	$email = "";
	foreach($var as $key=>$data){
		$nama = $data['NAMA_PENGAJAR'];
		$email = $data['EMAIL'];
	}
	//-----------------EMAIL-----------------
		
		$mail             = new PHPMailer();
		$address 		  = $email;					
	
		$mail->Subject    = "Accepted";

		$body			  = "Selamat bergabung dengan Orion Course,".$nama.". Akun anda dapat dibuka dan dapat digunakan sebagai absen. Kami harapkan anda selalu berkreasi dan bekerja keras bersama kami. Hormat kami, Team Orion course";

		$mail->IsSMTP(); // telling the class to use SMTP
		$mail->Host       = "mail.google.com"; // SMTP server
		$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
												// 1 = errors and messages
												// 2 = messages only
		$mail->SMTPAuth   = true;                  // enable SMTP authentication
		$mail->SMTPSecure = "tls";                 // sets the prefix to the servier
		$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
		$mail->Port       = 587;                   // set the SMTP port for the GMAIL server
		$mail->Username   = "course.orion@gmail.com";  // GMAIL username mu
		$mail->Password   = "orion552";     // GMAIL password mu

		$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

		$mail->MsgHTML($body);

		$mail->AddAddress($address, "Kepada Anda");

		//$mail->AddAttachment("result/".$file);      // attachment
		//$mail->Send();

		if($mail->Send()) {  
			echo "berhasil";
		}else {
			echo "gagal";
		}
	//--------------END EMAIL----------------
			
	
	 
	  

?>