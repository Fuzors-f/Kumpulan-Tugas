<?php require_once("../../configuration.php");
$idteacher = $_GET['userid'];
$queryspengajar = "SELECT * FROM PENGAJAR WHERE ID_PENGAJAR = '$idteacher'";
$hasil = mysqli_query($conn,$queryspengajar);
$nama_pengajar = "";
$motto_pengajar = "";
$instagram = "";
$line = "";
$phone = "";
$gambar = "";
$status_pengajar = "";

foreach($hasil as $key=>$data){
    $line = $data['LINE'];
    $instagram = $data['INSTAGRAM'];
    $status_pengajar = $data['STATUS'];
    $phone =$data['TELEPON'];
    $motto_pengajar = $data['MOTTO'];
    $nama_pengajar = $data['NAMA_PENGAJAR'];
    $gambar = $data['FOTO'];
}




?>


<div class="col-md-4">
    <div class="card card-user">
        <div class="card-image">
            <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="...">
        </div>
        <div class="card-body">
            <div class="author">
                <a style="font-size:14pt; font-weight:bold">
                  <?php if($gambar != ""){
                       echo  "<img class='avatar border-gray' src='".$gambar."' alt='...'>";
                    }else{
                        echo "<img class='avatar border-gray' src='assets/img/faces/face-0.jpg' alt='...'>";
                    }
                  ?>
                    <h5 class="title"><?=$nama_pengajar?></h5>
                </a>
                <hr>
               
            </div>
            <p class="description text-center">
                Motto : 
                <br> <span style="font-style:italic"><?php
                if($motto_pengajar != "")
                echo "`".$motto_pengajar."`"?></span>
            </p>
            <br>
            <hr>
            <p class='description' style="text-align:left">
                    Contact : 
                    <br>
                    <?php 
                        if($instagram != ""){
                            $linkr = "https://www.instagram.com/".$instagram;
                            echo "
                                    <img src='assets/img/instagram.webp' style='width:25px;height:25px'> :<a href='".$linkr."'>@".$instagram."</a>
                            <br>";
                        }
                        if($line != ""){
                            echo "
                                <img src='assets/img/line-me.png' style='width:18px;height:18px'> : <a href='#' disabled >"." ".$line."</a>
                            <br>";
                        }
                        if($phone != ""){
                            echo "
                                <img src='assets/img/phone.webp' style='width:15px;height:15px'> :<a href='#' disabled >"." ".$phone."</a>
                            <br>";
                        }
                    ?>
               </p>
        </div>
        <hr>
        <div class="button-container mr-auto ml-auto ">
            <button onclick="edits('<?=$idteacher?>')" class="btnPros" style="width:auto;height:auto; fpont-size:8pt;">
                Edit
            </button>
            <button onclick="deletes('<?=$idteacher?>')" class="btnWarning" style="width:auto;height:auto; fpont-size:8pt;">
                Delete
            </button>
            <?php 
            if(intval($status_pengajar) == 2){
                echo "<button onclick=\"accepts('{$idteacher}')\" class='btnPros' style='width:auto;height:auto; fpont-size:8pt;'>
                   Accept
                </button>";
            }
           ?>
        </div>
    </div>
</div>