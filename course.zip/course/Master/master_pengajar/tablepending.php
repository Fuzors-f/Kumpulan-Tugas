<?php require_once("../../configuration.php");?>

<table class="table table-hover table-striped">
    <?php 
       $query = "SELECT * FROM PENGAJAR WHERE STATUS = 2";
        $config = mysqli_query($conn,$query);
    ?>
        <thead>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Phone</th>
            <th>View Information</th>
        </thead>
        <tbody>
        <?php foreach($config as $key=>$data){
?>
     <tr>
        <td><?=$data["NAMA_PENGAJAR"] ?></td>
        <td><?=$data["EMAIL"] ?></td>
        <td><?=$data["PASSWORD"] ?></td>
        <td><?=$data["TELEPON"] ?></td>
        <td><button onclick="modalopen('<?=$data['ID_PENGAJAR'] ?>')" class="imgpress">View More</button></td>
    </tr>
<?php
        } ?>
        </tbody>
    </table>

    <script>

       
    </script>