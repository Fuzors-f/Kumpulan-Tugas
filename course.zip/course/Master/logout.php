<?php

require_once("../configuration.php");
unset($_SESSION['loginmaster']);
header("location:index.php");
?>
