<?php require_once("../../configuration.php");?>

<table class="table table-hover table-striped">
    <?php 
       $query = "SELECT * FROM TESTIMONI WHERE STATUS = 0";
        $config = mysqli_query($conn,$query);
    ?>
        <thead>
            <th>Name</th>
            <th>Content</th>
            <th>Content Image</th>
            <th>Action</th>
        </thead>
        <tbody>
        <?php foreach($config as $key=>$data){
?>
     <tr>
        <td><?=$data["NAMA_TESTIMONI"] ?></td>
        <td><?=$data["ISI_TESTIMONI"] ?></td>
        <td><button onclick="modalopen('<?=$data['GAMBAR_TESTIMONI'] ?>')" class="imgpress"><?=$data["GAMBAR_TESTIMONI"] ?></button></td>
        <td><input  type="button" id="btnedit" onclick="recovers('<?=$data['ID_TESTIMONI']?>')" class="btnedit" value="Recover"> </td>
    </tr>
<?php
        } ?>
        </tbody>
    </table>

    <script>

       
    </script>