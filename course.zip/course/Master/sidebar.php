<div class="sidebar" data-image="assets/img/sidebar-5.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="sidebar-wrapper">
                <div class="logo">
                    <a href="#" class="simple-text">
                        Orion Course Team
                    </a>
                </div>
                <ul class="nav">
                <?php if($numbers == 0) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_absent.php">
                            <i class="nc-icon nc-paper-2"></i>
                            <p>Absent</p>
                        </a>
                    </li>
                    <?php if($numbers == 1) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_murid.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Student List</p>
                        </a>
                    </li>
                    <?php if($numbers == 2) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_konten.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Content List</p>
                        </a>
                    </li>
                    <?php if($numbers == 3) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_testimoni.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Testimony List</p>
                        </a>
                    </li>
                    <?php if($numbers == 4) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_pengajar.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Teacher List</p>
                        </a>
                    </li>
                    <?php if($numbers == 6) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_kelas.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Class List</p>
                        </a>
                    </li>
                     <?php if($numbers == 5) echo "<li class='nav-item active'>"; else echo "<li>"; ?>
                        <a class="nav-link" href="dashboard_schedule.php">
                            <i class="nc-icon nc-circle-09"></i>
                            <p>Teacher Schedule</p>
                        </a>
                    </li>
                   
                    <li class="nav-item active active-pro">
                        <a class="nav-link active" href="logout.php">
                        <i class="nc-icon nc-simple-remove"></i>
                            <p>Log Out</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>