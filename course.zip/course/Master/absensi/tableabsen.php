<?php require_once("../../configuration.php");?>
<?php 

$id = $_GET['id'];
$tanggal = $_GET['month'];
$tmp = explode("-",$tanggal);
// $bulan = intval($tmp[1]);
// $tahun = intval($tmp[0]);

$ctr =0;
$querys = "SELECT * FROM ABSEN WHERE ID_PENGAJAR = '$id'  AND MONTH(TANGGAL) = '$tmp[1]' AND YEAR(TANGGAL) = '$tmp[0]'  ORDER BY ID_KELAS, TANGGAL DESC";
$config = mysqli_query($conn,$querys);
$ctrkelas =0;
$ctrprivat = 0;
echo mysqli_error($conn);
?>
<table class="table table-hover table-striped">
 
        <thead>
            <th>Student Name/Class</th>
            <th>Address</th>
            <th>Date</th>
            <th>Hour</th>
            <th>Info </th>
        </thead>
        <tbody>
<?php 
    foreach($config as $key=>$data){
        $nama = "";
        $alamat = "";
        $idtmp = $data['ID_KELAS'];
        if(substr($idtmp,0,2)=="MU"){
            $querys2 = "SELECT * FROM MURID WHERE ID_MURID = '$idtmp'";
            $rs = mysqli_query($conn,$querys2);
            foreach($rs as $Ky=>$dt){
                $nama = $dt['NAMA_MURID'];
                $alamat = $dt['ALAMAT'];
            }
            $ctrprivat++;
        }else{
            $querys2 = "SELECT * FROM KELAS WHERE ID_KELAS = '$idtmp'";
            $rs = mysqli_query($conn,$querys2);
            foreach($rs as $Ky=>$dt){
                $nama = $dt['ID_KELAS'];
                $alamat = $dt['ALAMAT_KELAS'];
            }
            $ctrkelas;
        }
?>
     <tr>
        <td><?=$nama?></td>
        <td><?=$alamat ?></td>
        <td><?=date("l,d-M-y", strtotime($data["TANGGAL"])) ?></td>
        <td><?=$data['JAM']?></td>
        <td><?=$data["KETERANGAN"] ?></td>

    </tr>
<?php
        } ?>
        </tbody>
    </table>
        <hr>
    <div class='col-md-12 stats'>
        <p> Total Les Privat : <span style="padding-right:3vw"><?=$ctrprivat?></span>   Total Kelas : </span><span><?=$ctrkelas?></span></p>
     
    </div>
    <script>

       
    </script>