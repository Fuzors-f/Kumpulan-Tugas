<?php  require_once("../configuration.php");
    $numbers = 6;
    $alamat = "";
    $hari = "";
    $jam = "";
    $id = "null";
    $flag  = true;
    $idguru = "";
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $flag = false;
        $query = "SELECT * FROM KELAS WHERE ID_KELAS = '$id'";
        $res = mysqli_query($conn,$query);
        foreach($res as $Key=>$data){
            $alamat = $data['ALAMAT_KELAS'];
            $hari = $data['HARI'];
            $jam = $data['JAM'];
        }

        $query2 ="SELECT * FROM KELAS_PENGAJAR WHERE ID_KELAS = '$id' AND STATUS = 1";
        $res2 = mysqli_query($conn,$query2);
        if(mysqli_num_rows($res2)>0){
            foreach($res2 as $key=>$data){
                $idguru = $data['ID_PENGAJAR'];
            }
        }
        


    }



    $header = "Insert ";
    if($flag == false){
        $header = "Update ";
    }
?>

<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php"); ?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />

</head>

<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                <a style="font-size:18pt;" href="dashboard_kelas.php"> << Class </a>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title"><?=$header?> CLASS</h4>
                                </div>
                                <div class="card-body">
                                   
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Address</label>
                                                    <input type="text" class="form-control" id="alamat" placeholder="Address" value="<?=$alamat?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Day (hanya masukan 1 hari saja ex: SENIN, dengan format caps)</label>
                                                    <input type="text" class="form-control" id="hari" placeholder="SENIN" value="<?=$hari?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Hour (hanya masukan 1 jam saja ex: 18:00)</label>
                                                    <input type="text" class="form-control" id="jam" placeholder="18:00" value="<?=$jam?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                               <div class="col-md-3 col-sm-6" > Choose Teacher : </div> 
                                               <div class="col-md-12">
                                                    <div id="myBtnContainer" style="margin-top:2vh;">
                                                        <?php
                                                            $query = "SELECT * FROM PENGAJAR WHERE STATUS = 1";
                                                            $idtmp =[];
                                                            $namaguru =[];
                                                            $ctr =0;
                                                            $result = mysqli_query($conn,$query);
                                                            foreach($result as $key=>$data){
                                                                $namaguru[$ctr] = $data['NAMA_PENGAJAR'];
                                                                $idtmp[$ctr] = $data['ID_PENGAJAR'];
                                                                $ctr++;
                                                            }

                                                            for($i=0;$i<$ctr;$i++){
                                                                if($idguru!=""){
                                                                    if($idguru ==$idtmp[$i]){
                                                                        ?>
                                                                        <button class="btn actives" value="<?=$idtmp[$i]?>"><?=$namaguru[$i]?></button>
                                                                        <?php
                                                                    }else{
                                                                        ?>
                                                                        <button class="btn " value="<?=$idtmp[$i]?>"><?=$namaguru[$i]?></button>
                                                                        <?php
                                                                    }
                                                                }else{
                                                                    if($i==0){
                                                                        ?>
                                                                        <button class="btn actives" value="<?=$idtmp[$i]?>"><?=$namaguru[$i]?></button>
                                                                        <?php
                                                                    }else{
                                                                        ?>
                                                                        <button class="btn " value="<?=$idtmp[$i]?>"><?=$namaguru[$i]?></button>
                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        
                                                        
                                                        ?>
                                                    </div>
                                                </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class='col-md-12' id = 'btn2' style="margin-top:4vh;"><input type='button'  onclick='submited()' class='btnPros pull-right' value='Submit'></div>
                                        </div>
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>



                   
                    
                </div>
            </div>
            <!-- end content1 -->
            
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>
<style>
@media (max-width: 768px) {
    

    #btn2{
      margin-top:8vh;
    }

    .btnPros{
        font-size:12pt;
        width:100%;
        border-radius:5px;
    }
}
</style>
<script>

     var id = "<?=$id?>";
    $(document).ready(function (){
        
    });

    var btnContainer = document.getElementById("myBtnContainer");
   var btns = btnContainer.getElementsByClassName("btn");
   for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
            var current = btnContainer.getElementsByClassName(" actives");
            current[0].className = current[0].className.replace(" actives", "");
            this.className += " actives";
        });
    }
   

    function submited(){
        var pengajar = "";
        var guru = btnContainer.getElementsByClassName(" actives");
        var hari = document.getElementById("hari").value;
        var jam = document.getElementById("jam").value;
        var alamat = document.getElementById("alamat").value;
       var pengajar = guru[0].value;
       
       
       if(hari != ""){
            if(jam != ""){
                if(alamat !=""){
                    if(id=="null"){
                        $.ajax({
                            method: "post",
                            url: "master_kelas/controller.php",
                            data: {
                                ctr:1, //insert
                                hari :hari,
                                alamat :alamat,
                                jam :jam,
                                pengajar :pengajar
                            },
                            success: function (data) {
                                if(data=="success"){
                                    window.location.href = "dashboard_kelas.php";
                                }
                            }
                        });
                    }else{
                        $.ajax({
                            method: "post",
                            url: "master_kelas/controller.php",
                            data: {
                                ctr:2, //insert
                                hari :hari,
                                alamat :alamat,
                                jam :jam,
                                pengajar :pengajar,
                                id : id
                            },
                            success: function (data) {
                                if(data=="success"){
                                    window.location.href = "dashboard_kelas.php";
                                }
                            }
                        });
                    }
                }else{
                    notif("top","center","mohon di isi alamatnya dahulu");
                }
            }else{
                notif("top","center","mohon di isi jamnya dahulu");
            }
       }else{
           notif("top","center","mohon di isi harinya dahulu");
       }
    }

    function notif (from,align,pesan) {
        color = 4;

        $.notify({
            icon: "nc-icon nc-bell-55",
            message: pesan

        }, {
            type: type[color],
            timer: 8000,
            placement: {
                from: from,
                align: align
            }
        });
    }
</script>
