<footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul class="footer-menu">
                            <li>
                                <a href="../Home/">
                                    Home Orion Course
                                </a>
                            </li>
                            
                        </ul>
                        <p class="copyright text-center">
                            Orion Course || template by ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            <a href="http://www.creative-tim.com">Creative Tim</a>
                        </p>
                    </nav>
                </div>
            </footer>