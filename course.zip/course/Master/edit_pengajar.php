<?php require_once("../configuration.php");
    $id= $_GET['id'];
    $numbers = 4;
    $query = "SELECT * FROM PENGAJAR WHERE ID_PENGAJAR= '$id'";
    $result= mysqli_query($conn,$query);
    $nama = "";
    $moto = "";
    $password = "";
    $foto = "";
    $instagram = "";
    $phone = "";
    $email = "";
    $line = "";

    foreach($result as $key=>$data){
        $nama = $data['NAMA_PENGAJAR'];
        $email = $data['EMAIL'];
        $password=$data['PASSWORD'];
        $phone = $data['TELEPON'];
        $line = $data['LINE'];
        $instagram = $data['INSTAGRAM'];
        $foto = $data['FOTO'];
        $moto = $data["MOTTO"];
        
    }
   

?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php"); ?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />

</head>
<style>
/*the container must be positioned relative:*/
.custom-select {
  position: relative;
  font-family: Arial;
}

.custom-select:hover{
    cursor:pointer;
}

.custom-select select {
  display: none; /*hide original SELECT element:*/
}

.select-selected {
  background-color: DodgerBlue;
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
}

/*style items (options):*/
.select-items {
  position: absolute;
  background-color: DodgerBlue;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}

/*hide the items when the select box is closed:*/
.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}
</style>
<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                <a style="font-size:18pt;" href="dashboard_pengajar.php"> << Teacher </a>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Edit Teacher</h4>
                                </div>
                                <div class="card-body">
                                   
                                        <div class="row">
                                            <div class="col-md-3 px-1">
                                                <div class="form-group">
                                                    <label>Name</label>
                                                    <input type="text" class="form-control" id="nama" placeholder="Name" value="<?=$nama?>">
                                                </div>
                                            </div>
                                            <div class="col-md-4 pl-1">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Phone</label>
                                                    <input type="number" id="phone" class="form-control" placeholder="08128373999" value =<?=$phone?>>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 pr-1">
                                                <div class="form-group">
                                                    <label>Line<span style="padding-left:1vw;font-size:8pt;font-style:italic;">(Boleh dikosongi)</span> </label>
                                                    <input type="text" id="line" class="form-control" placeholder="jack_frost" value="<?=$line?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6 pl-1">
                                                <div class="form-group">
                                                    <label>Instagram <span style="padding-left:1vw;font-size:8pt;font-style:italic;">(Boleh di kosongi. isi tanpa menggunkan '@')</span></label>
                                                    <input type="text" id="instagram" class="form-control" placeholder="jackfrost" value="<?=$instagram?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="email" id="email" class="form-control" placeholder="jackfrost@yuhuu.com" value="<?=$email?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Password</label>
                                                    <input type="password" id="pasw" class="form-control"  value="<?=$password?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Motto <span style="padding-left:1vw;font-size:8pt;font-style:italic;">(Boleh di kosongi)</span></label>
                                                    <input type="textarea" id="moto" rows="4" cols="80" class="form-control" placeholder="Keep Strong My friend !" value="<?=$moto?>">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-info btn-fill pull-right" onclick="submits()">Update Profile</button>
                                        <div class="clearfix"></div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>



                   
                    
                </div>
            </div>
            <!-- end content1 -->
            
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>

<script>
   
    var id = "<?=$id?>";
   


    function notif (from,align,pesan) {
        color = 4;

        $.notify({
            icon: "nc-icon nc-bell-55",
            message: pesan

        }, {
            type: type[color],
            timer: 8000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    
    

    function submits(){
        var email = document.getElementById("email").value;
        var pasw = document.getElementById("pasw").value;
        var moto = document.getElementById("moto").value;
        var phone = document.getElementById("phone").value;
        var nama = document.getElementById("nama").value;
        var instagram = document.getElementById("instagram").value;
        var line = document.getElementById("line").value;

        if(phone !=""){
            if(pasw != ""){
                if(email != ""){
                    if(nama != ""){
                        $.ajax({
                            method: "post",
                            url: "master_pengajar/controller.php",
                            data: {
                                id:id,
                                ctr:3, // update
                                email :email,
                                pasw : pasw,
                                phone : phone,
                                line :line,
                                instagram : instagram,
                                moto : moto,
                                nama : nama
                            },
                            success: function (data) {
                                if(data=="success"){
                                    var path = "upload_gambar_pengajar.php?id="+id;
                                    window.location.href = path;
                                }
                            }
                        });
                    }else{
                        notif('top','center',"Nama tidak boleh kosong!");
                    }
                }else{
                    notif('top','center',"Email tidak boleh kosong!");
                }
            }else{
                notif('top','center',"password tidak boleh kosong!");
            }
        }else{
            notif('top','center',"No telepon tidak boleh kosong!");
        }



    }


  
</script>