<?php
    require_once("../../configuration.php");
    $id = $_REQUEST['id']; //id pengajar;
    $hari = $_REQUEST['hari'];
    $idket = $_REQUEST['idket']; //id kelas atau murid;
    $tipe = $_REQUEST['tipe'];

    if($tipe =="KL"){
        $query = "UPDATE KELAS_PENGAJAR SET STATUS = 0 WHERE ID_PENGAJAR = '$id' AND ID_KELAS = '$idket'";
        $res = mysqli_query($conn,$query);
        if($res == true){
            echo "success";
        }
    }else{
        $query = "UPDATE JADWAL SET STATUS = 0 WHERE ID_PENGAJAR = '$id' AND ID_MURID = '$idket' AND HARI = '$hari'";
        $res = mysqli_query($conn,$query);
        if($res == true){
            echo "success";
        } 
    }

?>