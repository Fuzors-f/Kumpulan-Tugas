<?php
require_once("../../configuration.php");
$id = $_GET['idguru']; //id pengajar;
$hari = $_GET['hari'];
$idket = $_GET['idket']; //id kelas atau murid;
$tipe = $_GET['tipe'];

$nama = "";
$alamat = "";

if($tipe =="KL"){
    $query = "SELECT * FROM KELAS WHERE ID_KELAS = '$idket' AND STATUS = 1";
    $res = mysqli_query($conn,$query);
    foreach($res as $key=>$data){
        $nama = "kelas";
        $alamat = $data['ALAMAT_KELAS'];
    }
}else {
    $query = "SELECT * FROM MURID WHERE ID_MURID= '$idket' AND STATUS = 1";
    $res = mysqli_query($conn,$query);
    foreach($res as $key=>$data){
        $nama = $data['NAMA_MURID']." - PRIVAT";
        $alamat = $data['ALAMAT'];
    }
}

?>
 <div class="content">
    <div class="container-fluid">
        <h1 style='font-size:20pt;font-weight:bold; text-align:left'>Keterangan</h1>
        <br>
        <div class="row">
             <div class="col-md-12">
                <h4 class="card-title"><?=$nama?></h4>
            </div>
        </div>
        <div class="row">
             <div class="col-md-12">
                <h4 class="card-title">Alamat :<?=$alamat?></h4>
            </div>
        </div>
        <div class="row" style="margin-top:10vh"><p>Action</p>
             <div class="col-md-12" style="margin-top:2vh;">
                <button class="btnWarning" id="btnz" onclick="hapus()">Hapus</button>
            </div>
        </div>

    </div>
</div>
<style>
#btnz{
    width:5vw;height:4vh; font-size:10pt;
}
@media only screen and (max-width: 600px) {
 #btnz {
    width:100%;
  }
}
</style>

<script>

    function hapus(){
        var id= "<?=$id?>";
        var idket = "<?=$idket?>";
        var hari = "<?=$hari?>";
        var tipe = "<?=$tipe?>";
        $.ajax({
            method: "post",
            url: "penjadwalan/delete.php",
            data: {
                id:id,
                idket :idket,
                hari :hari,
               tipe : tipe
            },
            success: function (data) {
                if(data=="success") location.reload(); 
            }
        });
    }
</script>