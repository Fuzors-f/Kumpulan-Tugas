<?php 
    require_once("../../configuration.php");
    $tmpid =$_REQUEST['tmpid'];
    $hari = $_REQUEST['hari'];
    $id = $_REQUEST['id'];
    $tipe =$_REQUEST['tipe'];
    $jam = $_REQUEST['jam'];
    $control  = $_REQUEST['controll'];

    if($control == 0){
        $query = "UPDATE MURID SET STATUS = 0 WHERE ID_MURID = '$id'";
        mysqli_query($conn,$query);
        echo "success";
    }else if ($control == 1){
        $tmphari = explode(",",$hari);
        $tmpjam  = explode(",",$jam);
        if (count($tmphari)== count($tmpjam)){
            if($tipe == "P"){
                $cek = true;
                for($i=0; $i<count($tmphari); $i++){
                    $query = "INSERT INTO JADWAL VALUES('$tmpid','$id','$tmphari[$i]','$tmpjam[$i]',1)";
                    $res = mysqli_query($conn,$query);
                    if($res == false){
                        $cek = false;
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }else if($tipe == "K"){
                $tmpidkelas = explode(",",$tmpid);
                $cek = true;
                for($i=0;$i<count($tmphari);$i++){
                    for($j=0;$j<count($tmpidkelas); $j++){
                       $cek2 = true;
                       $qw = "SELECT * FROM KELAS WHERE ID_KELAS = '$tmpidkelas[$j]' AND STATUS = 1";
                       $result = mysqli_query($conn,$qw);
                       foreach($result as $key =>$data){
                           if($tmphari[$i] != $data['HARI']){
                               $cek2 = false;
                           }
                       }
                       if($cek2 == true){
                        $query = "INSERT INTO JADWAL VALUES('$tmpidkelas[$j]','$id','$tmphari[$i]','$tmpjam[$i]',1)";
                        $res = mysqli_query($conn,$query);
                        if($res == false) $cek = false;
                       }
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }
        }else {
            if($tipe == "P"){
                $cek = true;
                for($i=0; $i<count($tmphari); $i++){
                    $query = "INSERT INTO JADWAL VALUES('$tmpid','$id','$tmphari[$i]','$tmpjam[0]',1)";
                    $res = mysqli_query($conn,$query);
                    if($res == false){
                        $cek = false;
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }else if($tipe == "K"){
                $tmpidkelas = explode(",",$tmpid);
                $cek = true;
                for($i=0;$i<count($tmphari);$i++){
                    for($j=0;$j<count($tmpidkelas); $j++){
                       $cek2 = true;
                       $qw = "SELECT * FROM KELAS WHERE ID_KELAS = '$tmpidkelas[$j]' AND STATUS = 1";
                       $result = mysqli_query($conn,$qw);
                       foreach($result as $key =>$data){
                           if($tmphari[$i] != $data['HARI']){
                               $cek2 = false;
                           }
                       }
                       if($cek2 == true){
                        $query = "INSERT INTO JADWAL VALUES('$tmpidkelas[$j]','$id','$tmphari[$i]','$tmpjam[0]',1)";
                        $res = mysqli_query($conn,$query);
                        if($res == false) $cek = false;
                       }
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }
        }
    }else if ($control == 2){
        $quey = "UPDATE JADWAL SET STATUS = 0 WHERE ID_MURID = '$id'";
        $cek = mysqli_query($conn,$quey);
        $tmphari = explode(",",$hari);
        $tmpjam  = explode(",",$jam);
        if (count($tmphari)== count($tmpjam)){
            if($tipe == "P"){
                $cek = true;
                for($i=0; $i<count($tmphari); $i++){
                    $query = "INSERT INTO JADWAL VALUES('$tmpid','$id','$tmphari[$i]','$tmpjam[$i]',1)";
                    $res = mysqli_query($conn,$query);
                    if($res == false){
                        $cek = false;
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }else if($tipe == "K"){
                $tmpidkelas = explode(",",$tmpid);
                $cek = true;
                for($i=0;$i<count($tmphari);$i++){
                    for($j=0;$j<count($tmpidkelas); $j++){
                       $cek2 = true;
                       $qw = "SELECT * FROM KELAS WHERE ID_KELAS = '$tmpidkelas[$j]' AND STATUS = 1";
                       $result = mysqli_query($conn,$qw);
                       foreach($result as $key =>$data){
                           if($tmphari[$i] != $data['HARI']){
                               $cek2 = false;
                           }
                       }
                       if($cek2 == true){
                        $query = "INSERT INTO JADWAL VALUES('$tmpidkelas[$j]','$id','$tmphari[$i]','$tmpjam[$i]',1)";
                        $res = mysqli_query($conn,$query);
                        if($res == false) $cek = false;
                       }
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }
        }else {
            if($tipe == "P"){
                $cek = true;
                for($i=0; $i<count($tmphari); $i++){
                    $query = "INSERT INTO JADWAL VALUES('$tmpid','$id','$tmphari[$i]','$tmpjam[0]',1)";
                    $res = mysqli_query($conn,$query);
                    if($res == false){
                        $cek = false;
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }else if($tipe == "K"){
                $tmpidkelas = explode(",",$tmpid);
                $cek = true;
                for($i=0;$i<count($tmphari);$i++){
                    for($j=0;$j<count($tmpidkelas); $j++){
                       $cek2 = true;
                       $qw = "SELECT * FROM KELAS WHERE ID_KELAS = '$tmpidkelas[$j]' AND STATUS = 1";
                       $result = mysqli_query($conn,$qw);
                       foreach($result as $key =>$data){
                           if($tmphari[$i] != $data['HARI']){
                               $cek2 = false;
                           }
                       }
                       if($cek2 == true){
                        $query = "INSERT INTO JADWAL VALUES('$tmpidkelas[$j]','$id','$tmphari[$i]','$tmpjam[0]',1)";
                        $res = mysqli_query($conn,$query);
                        if($res == false) $cek = false;
                       }
                    }
                }
                if($cek == true){
                    $querys = "UPDATE MURID SET STATUS = 1 WHERE ID_MURID = '$id'";
                    $rs = mysqli_query($conn,$querys);
                    if($rs == true) echo "success";
                }
            }
        }
    }else if ($control == -1){
        $query = "UPDATE JADWAL SET STATUS = 0 WHERE ID_MURID = '$id'";
        mysqli_query($conn,$query);
        $query2 = "UPDATE MURID SET STATUS = 0 WHERE ID_MURID = '$id'";
        $rs = mysqli_query($conn,$query2);
        if($rs == true) echo "success";

    }
?>