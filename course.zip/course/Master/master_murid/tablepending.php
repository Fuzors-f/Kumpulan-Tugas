<?php require_once("../../configuration.php");?>

<table class="table table-hover table-striped">
    <?php 
        $tipe =$_GET['tipe'];
        $query = "";
        if($tipe=="all"){
            $query = "SELECT * FROM MURID WHERE STATUS =2 ORDER by TANGGAL_DAFTAR desc";
        }else{
            $query = "SELECT * FROM MURID WHERE STATUS =2  AND JENIS = '$tipe' ORDER by TANGGAL_DAFTAR desc";
        }
        $config = mysqli_query($conn,$query);
    ?>
        <thead>
            <th>Name</th>
            <th>Address</th>
            <th>Phone</th>
            <th>Registration Date</th>
            <th>Type</th>
            <th>Level</th>
            <th>Information</th>
            <th colspan="2">Action</th>
        </thead>
        <tbody>
        <?php foreach($config as $key=>$data){
?>
     <tr>
        <td><?=$data["NAMA_MURID"] ?></td>
        <td><?=$data["ALAMAT"] ?></td>
        <td><?=$data["TELEPON"] ?></td>
        <td><?=$data["TANGGAL_DAFTAR"] ?></td>
        <td><?php
            if($data["JENIS"]=="K"){
                echo "Kelas";
            }else{
                echo "Privat";
            }
        ?></td>
        <td><?=$data['JENJANG'] ?></td>
        <td><?=$data['KETERANGAN'] ?></td>
        <td><input  type="button" id="btnedit" onclick="edits('<?=$data['ID_MURID']?>')" class="btnedit" value="Edit"> </td>
        <td><input type="button"  id="btnAcc"  onclick="acceptance('<?=$data['ID_MURID']?>')" class="btnAcc" value="Accept"></td>
    </tr>
<?php
        } ?>
        </tbody>
    </table>

    <script>

       
    </script>