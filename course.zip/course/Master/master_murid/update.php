<?php 
require_once("../../configuration.php");
$id =$_REQUEST['id'];
$nama = $_REQUEST['nama'];
$phone = $_REQUEST['phone'];
$alamat = $_REQUEST['alamat'];
$hari = $_REQUEST['hari'];
$jam = $_REQUEST['jam'];
$about = $_REQUEST['about'];
$jenjang = $_REQUEST['jenjang'];
$tipe = $_REQUEST['tipe'];
$status = $_REQUEST['status'];
$flag = false;
$query = "SELECT * FROM MURID WHERE ID_MURID = '$id'";
$res = mysqli_query($conn,$query);
foreach($res as $Key=>$data){
    if($tipe != $data['JENIS']){
        $query2 = "UPDATE JADWAL SET STATUS = 0 WHERE ID_MURID = '$id'";
        mysqli_query($conn,$query2);
        $flag = true;
    }
}

$query3 = "UPDATE `murid` SET `NAMA_MURID`='$nama',`TELEPON`='$phone',`ALAMAT`='$alamat',`KETERANGAN`='$about',`JENIS`='$tipe',`HARI`='$hari',`JAM`='$jam',`JENJANG`='$jenjang',`STATUS`=$status WHERE ID_MURID = '$id'";
$result = mysqli_query($conn,$query3);
if($result == true){
    echo "success".$flag;
}



?>