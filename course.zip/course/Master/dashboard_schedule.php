<?php require_once("../configuration.php"); 
    $numbers = 5;
?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php"); ?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />
</head>

<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                    <h2 style="font-size:18pt;"> Schedule </h2>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <!-- row -->
                    <div class="row" >
                        <div class="col-md-12">
                           <div class="card strpied-tabled-with-hover">
                                <div class="card-header ">
                                     <h4 class="card-title" >Check Teacher Schedule</h4>
                                </div>
                                <div class="card-body  " >
                                     <div id="myBtnContainer">
                                           <?php
                                                $query = "SELECT * FROM PENGAJAR WHERE STATUS = 1";
                                                $rs = mysqli_query($conn,$query);
                                                foreach($rs as $key=>$data){
                                            ?>
                                                 <button class="btn " onclick="filterselection('<?=$data['ID_PENGAJAR']?>')"> <?=$data['NAMA_PENGAJAR']?></button>
                                            <?php
                                                }
                                           ?>
                                    </div>
                                   <div class="table-full-width table-responsive" id="tbPenjadwalan" ></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                   
                </div>
            </div>
            <!-- end content1 -->
            
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>
<script>
    
    $(document).ready(function(){
      

    })
   var btnContainer = document.getElementById("myBtnContainer");
   var btns = btnContainer.getElementsByClassName("btn");
  var flag1 = true;
    var i;

   
    
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
            if(flag1==true){
                this.className += " actives";
                flag1 = false;
            }else{
                var current = btnContainer.getElementsByClassName("actives");
                current[0].className = current[0].className.replace(" actives", "");
                this.className += " actives";
            }
        });
    }

    function filterselection(id){
        var path = "penjadwalan/tablejadwal.php?id="+id;
        $("#tbPenjadwalan").load(path);
    }
   
</script>