<?php require_once("../configuration.php"); 
    $numbers = 4;

?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php");?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />
</head>
<style>
    .btnInsert{
        display: block;
        width: 100%;
        border: none;
        background-color: #03254c;
        color:white;
        padding: 14px 28px;
        font-size: 16px;
        cursor: pointer;
        text-align: center;
        margin-top:4vh;
        transition:0.5s;
    }
    .btnInsert:hover{
        background-color:#187bcd;
    }




   .imgpress{
        color: black;
        transition :0.5s;
        background-color:transparent;
        border-radius:7%;
        border:0.4px solid gray;
    }
    
   .imgpress:hover{
        color:white;
        cursor:pointer;
        background-color:#878787;
        text-decoration:italic;
    }


    /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  padding-left:45%;
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}


/* Add Animation */
.modal{  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal{
      padding-left:0;
  }
}
</style>
<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                    <h2 style="font-size:18pt;"> Teacher </h2>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <!-- row -->
                    <div class="row" style="height:auto;">
                        <div class="col-md-12">
                           <div class="card strpied-tabled-with-hover">
                                <div class="card-header accordion">
                                     <h4 class="card-title" >Pending Teacher</h4>
                                </div>
                                <div class="card-body  contentaccordion" >
                                   <div class="table-full-width table-responsive" id="tbPengajarPending"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- row -->
                    <div class="row" style="height:auto;">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header accordion">
                                     <h4 class="card-title" >Accepted Teacher</h4>
                                </div>
                                <div class="card-body contentaccordion">
                                   <div class="table-full-width table-responsive" id="tbPengajarAccept" ></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
            </div>
            <!-- end content1 -->
            
             <!-- The Modal -->
             <div id="myModal" class="modal">
                <span class="close">&times;</span>
                <div class="container-fluid">
                    <div class="row" id="mdl">
                        
                    </div>
                </div>
                <div id="caption"></div>
            </div>
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>
<script>
    $(document).ready(function(){
        var path2 = "master_pengajar/tableaccept.php";
        var path = "master_pengajar/tablepending.php";
        $("#tbPengajarPending").load(path);
        $("#tbPengajarAccept").load(path2);
    })
   var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("act");
            var panel =  this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            } 
        });
    }

    
    var modal = document.getElementById("myModal");

    // Get the image and insert it inside the modal 
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    
    function modalopen(source){
        var path = "master_pengajar/modalbox.php?userid="+source;
        $("#mdl").load(path);
        modal.style.display = "block";
    }

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() { 
        modal.style.display = "none";
    } 
    
   

//    function opentab(){
//     var destination = "https://www.instagram.com/fendysugiartog/"; 
//     if( navigator.userAgent.match(/Android/i) ) {
//     // use Android's redirect
//     document.location = destination;   
//     }   
//     else {
//     // use iOS redirect
//     window.location.replace( destination );
//     }
//    }


   function accepts(id){
        $.ajax({
            method: "post",
            url: "master_pengajar/email.php",
            data: {
                id:id
            },
            success: function (data) {
                alert(data);
                if(data=="berhasil"){
                    $.ajax({
                        method: "post",
                        url: "master_pengajar/controller.php",
                        data: {
                            id:id,
                            ctr:1 // accept
                        },
                        success: function (data) {
                            modal.style.display = "none";
                            $("#tbPengajarPending").load("master_pengajar/tablepending.php");
                            $("#tbPengajarAccept").load("master_pengajar/tableaccept.php");

                        }
                    });
                }
            }
        });
   }

   function deletes(id){
       var con = confirm('Apakah anda yakin ?');
       if(con==true){
        $.ajax({
            method: "post",
            url: "master_pengajar/controller.php",
            data: {
                id:id,
                ctr:2 // delete
            },
            success: function (data) {
                if(data=="success"){
                    modal.style.display = "none";
                    $("#tbPengajarPending").load("master_pengajar/tablepending.php");
                    $("#tbPengajarAccept").load("master_pengajar/tableaccept.php");
                }else{
                    notif('top','center','Guru ini masih memiliki murid yang aktif atau kelas yang aktif. Mohon kosongkan jadwal terlebih dahulu !');
                }
            }
        });
       }
       
   }

   function edits(id){
       var path = "edit_pengajar.php?id="+id;
       window.location.href = path;
   }


   function notif (from,align,pesan) {
        color = 4;

        $.notify({
            icon: "nc-icon nc-bell-55",
            message: pesan

        }, {
            type: type[color],
            timer: 8000,
            placement: {
                from: from,
                align: align
            }
        });
    }
</script>