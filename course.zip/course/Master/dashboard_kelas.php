<?php require_once("../configuration.php"); 
    $numbers = 6;
?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php");?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />
</head>
<style>
    .btnInsert{
        display: block;
        width: 100%;
        border: none;
        background-color: #03254c;
        color:white;
        padding: 14px 28px;
        font-size: 16px;
        cursor: pointer;
        text-align: center;
        margin-top:4vh;
        transition:0.5s;
    }
    .btnInsert:hover{
        background-color:#187bcd;
    }

    #btnhap{
        width:5vw;
        height:4vh;
    }


   .imgpress{
        color: black;
        transition :0.5s;
        border:0.2px solid gray;
        background-color:transparent;
        border-radius:5%;
    }
    
   .imgpress:hover{
        color:white;
        cursor:pointer;
        background-color:#878787;
    }


    /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
  #btnhap{
      width:80px;
      height:30px;
  }
}
</style>
<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                    <h2 style="font-size:18pt;">Class <span style="font-size:8pt;font-style:italic;padding-left:2vw;">*satu kelas hanya untuk satu hari</span></h2>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="button" class="btnInsert" onclick="insertnewkelas()" value="Insert New Class">
                        </div>
                    </div>
            </div>
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <!-- row -->
                    <div class="row" style="height:auto;">
                        <div class="col-md-12">
                           <div class="card strpied-tabled-with-hover">
                                <div class="card-header accordion">
                                     <h4 class="card-title" >Class</h4>
                                </div>
                                
                                <div class="card-body  contentaccordion" >
                                    <div id="myBtnContainer">
                                                <button class="btn actives" onclick="sorts('all')"> Show all</button>
                                                <button class="btn" onclick="sorts('SENIN')"> Senin</button>
                                                <button class="btn" onclick="sorts('SELASA')"> Selasa</button>
                                                <button class="btn" onclick="sorts('RABU')"> Rabu</button>
                                                <button class="btn" onclick="sorts('KAMIS')"> Kamis</button>
                                                <button class="btn" onclick="sorts('JUMAT')"> Jumat</button>
                                                <button class="btn" onclick="sorts('SABTU')"> Sabtu</button>
                                                <button class="btn" onclick="sorts('MINGGU')"> Minggu</button>

                                    </div>
                                   <div class="table-full-width table-responsive" id="tbKelas"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                   
                    
                </div>
            </div>
            <!-- end content1 -->
            
            <!-- The Modal -->
            <div id="myModal" class="modal">
                <span class="close">&times;</span>
                <div class="modal-content" id="mdl"></div>
                <div id="caption"></div>
            </div>
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>
<script>
   var current = "all";
    $(document).ready(function(){
        var path = "master_kelas/tablekelas.php?sort="+current;
        $("#tbKelas").load(path);        

    })
   var acc = document.getElementsByClassName("accordion");
   var btnContainer = document.getElementById("myBtnContainer");
   var btns = btnContainer.getElementsByClassName("btn");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("act");
            var panel =  this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            } 
        });
    }

    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
            var current = btnContainer.getElementsByClassName("actives");
            current[0].className = current[0].className.replace(" actives", "");
            this.className += " actives";
        });
    }

    function insertnewkelas(){
        window.location.href = "insert_edit_kelas.php";
    }

    function edits(id){
        var path = "insert_edit_kelas.php?id="+id;
        window.location.href = path;
    }

    function deletes(id){
        $.ajax({
            method: "post",
            url : "master_kelas/controller.php",
            data :{
                ctr:4,
                id:id
            }, 
            success:function(data){
                if(data=="success"){
                    modal.style.display = "none";
                    var path = "master_kelas/tablekelas.php?sort="+current;
                    $("#tbKelas").load(path);  
                }else{
                    notif('top','center', 'masih terdapat murid, mohon di kosongi terlebih dahulu !');
                }
            }
        });
    }

    function deletesmurid(idkelas,idmurid){
        $.ajax({
            method: "post",
            url: "master_kelas/controller.php",
            data: {
                ctr:3, //delete murid
                idkelas : idkelas,
                idmurid :idmurid
            },
            success: function (data) {
                if(data=="success"){
                    modal.style.display = "none";
                    var path = "master_kelas/tablekelas.php?sort="+current;
                    $("#tbKelas").load(path);                  
                }
            }
        });
    }
    
    function sorts(hari){
        current = hari;
        var path = "master_kelas/tablekelas.php?sort="+current;
        $("#tbKelas").load(path); 
    }

  // Get the modal
  var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal 
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
 
function modalopen(source){
    var path = "master_kelas/modalbox.php?idkel="+source;
    $("#mdl").load(path);
    captionText.innerHTML = source;
    modal.style.display = "block";

}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
} 

    function notif (from,align,pesan) {
        color = 4;

        $.notify({
            icon: "nc-icon nc-bell-55",
            message: pesan

        }, {
            type: type[color],
            timer: 8000,
            placement: {
                from: from,
                align: align
            }
        });
    }

</script>