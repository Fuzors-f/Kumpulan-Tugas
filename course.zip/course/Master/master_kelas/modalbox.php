<?php 
    require_once("../../configuration.php");
    $idkel = $_GET['idkel'];
    $queryss = "SELECT * FROM KELAS WHERE ID_KELAS = '$idkel'";
    $rez = mysqli_query($conn,$queryss);
    $alamatkelas = "";
    foreach($rez as $key=>$data){
        $alamatkelas= $data["ALAMAT_KELAS"];
    }
    $guru = "";
    $queryss2 = "SELECT * FROM KELAS_PENGAJAR WHERE ID_KELAS = '$idkel' AND STATUS = 1";
    $rez2 = mysqli_query($conn,$queryss2);
    foreach($rez2 as $key=>$data){
        $id_guru = $data['ID_PENGAJAR'];
        $que = "SELECT * FROM PENGAJAR WHERE ID_PENGAJAR = '$id_guru'";
        $rest = mysqli_query($conn,$que);
        foreach($rest as $ky=>$dt){
            $guru = $dt['NAMA_PENGAJAR'];
        }
    }
    $idmurid = [];
    $namamurid = [];
    $counter = 0;
    $queryss3 = "SELECT * FROM JADWAL WHERE ID_PENGAJAR = '$idkel' AND STATUS = 1";
    $qyr= mysqli_query($conn,$queryss3);
    foreach($qyr as $key=>$data){
        $idmurid[$counter] = $data['ID_MURID'];
        $queryss4 = "SELECT * FROM MURID WHERE ID_MURID = '$idmurid[$counter]' AND STATUS = 1";
        $rz = mysqli_query($conn,$queryss4);
        foreach($rz as $ky=>$dt){
            $namamurid[$counter] = $dt['NAMA_MURID'];
        }
        $counter++;
    }
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h4 class="card-title" >Pengajar:  <span style="padding-left:1vw"><?=$guru?></span></h4>
            <hr>
            <div class="table-full-width table-responsive" id="tbKelas">
                <table class="table table-hover table-striped" >
                    <thead>
                        <th>Nama Murid</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php
                            for($i=0;$i<$counter;$i++){
                        ?>
                            <tr>
                                <td><?=$namamurid[$i]?></td>
                                <td><button onclick="deletesmurid('<?=$idkel ?>','<?=$idmurid[$i] ?>')" class="btnWarning" id="btnhap">Hapus</button></td>
                            </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12"><button class="btnWarning" style="width:100%; border-radius:2%;" onclick="deletes('<?=$idkel ?>')">Delete</button></div>
        <div class="col-md-12" style="margin-top:2vh;margin-bottom:2vh;"><button class="btnPros" style="width:100%;border-radius:2%;"  onclick="edits('<?=$idkel ?>')">Edit</button></div>
    </div>
</div>
