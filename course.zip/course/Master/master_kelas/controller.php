<?php
    require_once("../../configuration.php");
    $ctr = $_REQUEST['ctr'];
    if($ctr==1){
        $alamat = $_REQUEST['alamat'];
        $hari = $_REQUEST['hari'];
        $jam = $_REQUEST['jam'];
        $query= "SELECT LPAD(COUNT(*)+1,3,0) AS JUMLAH FROM KELAS";
        $res = mysqli_query($conn,$query);
        $pengajar = $_REQUEST['pengajar'];
        $tmp  = "";
        foreach($res as $key=>$data){
          $tmp = "KL".$data['JUMLAH'];
        }
        $query2 = "INSERT INTO KELAS VALUES('$tmp','$alamat','$hari','$jam',1)"; 
        $res2 = mysqli_query($conn,$query2);
        if($res2==true){
           $query3 = "INSERT INTO KELAS_PENGAJAR VALUES('$tmp','$pengajar',1)";
           $res3 = mysqli_query($conn,$query3);
           if($res3==true) echo "success";
        }

    } else if($ctr==2){
        $alamat = $_REQUEST['alamat'];
        $hari = $_REQUEST['hari'];
        $jam = $_REQUEST['jam'];
        $id = $_REQUEST['id'];
        $pengajar= $_REQUEST['pengajar'];
        $query = "UPDATE KELAS SET ALAMAT_KELAS ='$alamat', HARI = '$hari', JAM = '$jam' WHERE ID_KELAS = '$id' "; 
        $res = mysqli_query($conn,$query);

        $queryz = "SELECT * FROM KELAS_PENGAJAR WHERE ID_KELAS ='$id'";
        $rv = mysqli_query($conn,$queryz);
        $jum = 0;
        $jum = mysqli_num_rows($rv);
        if($jum>0){
            if($res==true){
                $query2 ="UPDATE KELAS_PENGAJAR SET ID_PENGAJAR = '$pengajar' WHERE ID_KELAS = '$id' AND STATUS = 1";
                $res2 = mysqli_query($conn,$query2);
                if($res2==true) echo "success";
            }
        }else{
            if($res==true){
                $query2 ="INSERT INTO KELAS_PENGAJAR VALUES('$id','$pengajar',1)";
                $res2 = mysqli_query($conn,$query2);
                if($res2==true) echo "success";
            } 
        }   
        
    } else if($ctr==3){
        $idmurid = $_REQUEST['idmurid'];
        $idkelas = $_REQUEST['idkelas'];
        $query = "UPDATE JADWAL SET STATUS = 0 WHERE ID_PENGAJAR = '$idkelas' AND ID_MURID = '$idmurid'";
        $res = mysqli_query($conn,$query);
        echo "success";
    } else if($ctr==4){
        $id = $_REQUEST['id'];
        $query = "SELECT * FROM JADWAL WHERE ID_PENGAJAR = '$id' AND STATUS = 1";
        $jv = mysqli_query($conn,$query);
        $jum = mysqli_num_rows($jv);
        if($jum==0){
            $query2 = "UPDATE KELAS SET STATUS =0 WHERE ID_KELAS = '$id'";
            mysqli_query($conn,$query2);
            $query3 = "UPDATE KELAS_PENGAJAR SET STATUS = 0 WHERE ID_KELAS = '$id'";
            mysqli_query($conn,$query3);
            echo "success";
        }else{
            echo "gagal";
        }
    }





?>