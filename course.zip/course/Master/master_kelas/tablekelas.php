<?php require_once("../../configuration.php");?>

<table class="table table-hover table-striped">
    <?php 

        $sort = $_GET['sort'];
        $query = "";
        if($sort =="all"){
            $query = "SELECT * FROM KELAS WHERE STATUS = 1 ORDER BY ALAMAT_KELAS";
        }else{
            $query = "SELECT * FROM KELAS WHERE STATUS = 1 AND HARI = '$sort' ORDER BY ALAMAT_KELAS";

        }
        $config = mysqli_query($conn,$query);
    ?>
        <thead>
            <th>Id</th>
            <th>Address</th>
            <th>Hour</th>
            <th>Day</th>
            <th>View Information</th>
        </thead>
        <tbody>
        <?php foreach($config as $key=>$data){
?>
     <tr>
        <td><?=$data["ID_KELAS"] ?></td>
        <td><?=$data["ALAMAT_KELAS"] ?></td>
        <td><?=$data["HARI"] ?></td>
        <td><?=$data["JAM"] ?></td>
        <td><button onclick="modalopen('<?=$data['ID_KELAS'] ?>')" class="imgpress">View More</button></td>
    </tr>
<?php
        } ?>
        </tbody>
    </table>

    <script>

       
    </script>