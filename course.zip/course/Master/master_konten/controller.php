<?php
    require_once("../../configuration.php");
    $id = $_REQUEST['id'];
    $ctr = $_REQUEST['ctr'];
    if($ctr <3){
        $nama = $_REQUEST['nama'];
        $isi = $_REQUEST['isi'];
    }
    
    
    if($ctr ==0){
        $query= "SELECT LPAD(COUNT(*)+1,3,0) AS JUMLAH FROM KONTEN";
        $res = mysqli_query($conn,$query);
        $tmp  = "";
        foreach($res as $key=>$data){
          $tmp = "KO".$data['JUMLAH'];
        }
        $query2 ="INSERT INTO `konten` VALUES ('$tmp','$nama','$isi','',1)";
        $res2 = mysqli_query($conn,$query2);
        if($res==true){
            echo $tmp;
        }
    }else if($ctr==1){
        $query = "UPDATE KONTEN SET ISI_KONTEN='$isi',NAMA_KONTEN ='$nama' WHERE ID_KONTEN='$id'";
        if($conn->query($query) == true){
            echo $id;
        }
    }else if($ctr==2){
        $query = "UPDATE KONTEN SET STATUS =0 WHERE ID_KONTEN='$id'";
        if($conn->query($query) == true){
            echo "deleted";
        }
    }else{
        $query = "UPDATE KONTEN SET STATUS =1 WHERE ID_KONTEN='$id'";
        mysqli_query($conn,$query);
    }



?>