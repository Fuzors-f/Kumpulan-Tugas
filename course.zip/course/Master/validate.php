<?php 
require_once("../configuration.php");

    $pasw = $_REQUEST['pass'];
    $user = $_REQUEST['username'];
    if($pasw == "admin" && $user=="admin"){
        $_SESSION['loginmaster'] = 1;
        header("location: dashboard_absent.php");
    }else{
        header("location: index.php");
    }

?>