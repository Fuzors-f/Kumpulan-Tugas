<?php require_once("../configuration.php"); 
    $numbers = 1;

?>
<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <?php include("title.php"); ?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link href="assets/css/button.css" rel="stylesheet" />
</head>

<body>
    <div class="wrapper">
        <?php include("sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                    <h2 style="font-size:18pt;"> Student </h2>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <!-- COntent 1 -->
            <div class="content">
                <div class="container-fluid">
                    <!-- row -->
                    <div class="row" style="height:auto;">
                        <div class="col-md-12">
                           <div class="card strpied-tabled-with-hover">
                                <div class="card-header accordion">
                                     <h4 class="card-title" >Pending Student</h4>
                                </div>
                                <div class="card-body  contentaccordion" >
                                     <div id="myBtnContainer">
                                            <button class="btn actives" onclick="filterselection('all')"> Show all</button>
                                            <button class="btn" onclick="filterselection('K')"> Class</button>
                                            <button class="btn" onclick="filterselection('P')"> Private</button>
                                    </div>
                                   <div class="table-full-width table-responsive" id="tbMuridPending"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- row -->
                    <div class="row" style="height:auto;">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header accordion">
                                     <h4 class="card-title" >Accepted Student</h4>
                                </div>
                                <div class="card-body contentaccordion">
                                    <div id="myBtnContainer2">
                                                <button class="btn actives" onclick="filterselection2('all')"> Show all</button>
                                                <button class="btn" onclick="filterselection2('K')"> Class</button>
                                                <button class="btn " onclick="filterselection2('P')"> Private</button>
                                    </div>
                                   <div class="table-full-width table-responsive" id="tbMuridAccept" ></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
            </div>
            <!-- end content1 -->
            
            
            <?php include("footer.php"); ?>
        </div>
    </div>

</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

</html>
<script>
    var current= "all";
    var current2 = "all";
    $(document).ready(function(){
        var path2 = "master_murid/tableaccept.php?tipe="+current2;
        var path = "master_murid/tablepending.php?tipe="+current;
        $("#tbMuridPending").load(path);

        $("#tbMuridAccept").load(path2);

    })
   var acc = document.getElementsByClassName("accordion");
   var btnContainer = document.getElementById("myBtnContainer");
   var btns = btnContainer.getElementsByClassName("btn");
   var btnContainer2 = document.getElementById("myBtnContainer2");
   var btns2 = btnContainer2.getElementsByClassName("btn");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("act");
            var panel =  this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            } 
        });
    }

    
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
            var current = btnContainer.getElementsByClassName("actives");
            current[0].className = current[0].className.replace(" actives", "");
            this.className += " actives";
        });
    }

    for (var i = 0; i < btns2.length; i++) {
        btns2[i].addEventListener("click", function(){
            var current =btnContainer2.getElementsByClassName("actives");
            current[0].className = current[0].className.replace(" actives", "");
            this.className += " actives";
        });
    }
    function filterselection(a){
       current= a;
        filterpending();
    }

    function filterselection2(a){
       current2= a;
        filteraccept();
    }

    function filterpending(){
        var path = "master_murid/tablepending.php?tipe="+current;
        $("#tbMuridPending").load(path);
    }

    function filteraccept(){
        var path = "master_murid/tableaccept.php?tipe="+current2;
        $("#tbMuridAccept").load(path);
    }

    function acceptance(id){
        var path = "accept_murid.php?id="+id;
        window.location.href = path;
    }
   
    function edits(id){
        var path = "edit_murid.php?id="+id;
        window.location.href = path;
    }
   
</script>