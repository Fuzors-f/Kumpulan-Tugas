<?php  require_once("../configuration.php");
    if(isset($_SESSION["loginmaster"])){
        header("location:dashboard_absent.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/iconz.png">
    <link rel="icon" type="image/png" href="assets/img/iconz.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Orion Course - Master</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    
<!--===============================================================================================-->	
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets_v2/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets_v2/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets_v2/css/util.css">
	<link rel="stylesheet" type="text/css" href="assets_v2/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('assets_v2/images/bg-01.jpg');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action = "validate.php" method ="post">
					<span class="login100-form-logo">
						<img src="assets/img/iconz.png" style="height:100px;width:100px;">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Log in Master
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="pass" placeholder="Password" id="pass">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
						<input class="input-checkbox100" id="ckb1" type="checkbox" name="showpass" onclick="shows()">
						<label class="label-checkbox100" for="ckb1">
							Show Password
						</label>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit">
							Login
						</button>
					</div>

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="assets_v2/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="assets_v2/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="assets_v2/vendor/bootstrap/js/popper.js"></script>
	<script src="assets_v2/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="assets_v2/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="assets_v2/vendor/daterangepicker/moment.min.js"></script>
	<script src="assets_v2/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="assets_v2/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="assets_v2/js/main.js"></script>

</body>
</html>

<script>
	function shows() {
		var x = document.getElementById("pass");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}
</script>