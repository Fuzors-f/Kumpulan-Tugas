<?php 
	header("location: Home/index.php");
?>